﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Location;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Security;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.Tasks;
using Esri.ArcGISRuntime.UI;
using Esri.ArcGISRuntime.UI.Controls;
using UIKit;
using Esri.ArcGISRuntime.ARToolkit;
using ARKit;

namespace ARToolkit.SampleApp.Samples
{

    [SampleInfo(DisplayName = "Manually calibrated Full-scale AR", Description = "Uses the device's GPS for initial, then manually calibrate to the real world")]
    public partial class ManualCalibrationController : UIViewController
    {
        ARSceneView ARView;

        public ManualCalibrationController() : base()
        {
        }
        public ManualCalibrationController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidDisappear(bool animated)
        {
            ARView.StopTrackingAsync();
            base.ViewDidDisappear(animated);
        }

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            // Create a new AR Scene View, set its scene, and provide the coordinates for laying it out
            ARView = new ARSceneView() { TranslatesAutoresizingMaskIntoConstraints = false };
            UIToolbar toolbar = new UIToolbar()
            {
                TranslatesAutoresizingMaskIntoConstraints = false,
                Items = new[]
                {
                    new UIBarButtonItem("Up", UIBarButtonItemStyle.Plain, (s,e) => MoveVertical(1d)),
                    new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
                    new UIBarButtonItem("Snap", UIBarButtonItemStyle.Plain, (s,e) => SnapToSurface(ARView.Camera?.Location)),
                    new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
                    new UIBarButtonItem("Down", UIBarButtonItemStyle.Plain, (s,e) => MoveVertical(-1d))
                }
            };
            ARView.RenderPlanes = true;
            View.AddSubviews(ARView, toolbar);

            NSLayoutConstraint.ActivateConstraints(new[]
            {
                ARView.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor),
                ARView.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor),
                ARView.TopAnchor.ConstraintEqualTo(View.TopAnchor),
                ARView.BottomAnchor.ConstraintEqualTo(View.BottomAnchor),
                toolbar.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor),
                toolbar.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor),
                toolbar.BottomAnchor.ConstraintEqualTo(View.SafeAreaLayoutGuide.BottomAnchor)
            });

            var p = System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData);
            var scene = new Scene(Basemap.CreateImagery());
            scene.Basemap.BaseLayers[0].Opacity = .5;
            scene.BaseSurface = new Surface();
            scene.BaseSurface.BackgroundGrid.IsVisible = false;
            scene.BaseSurface.ElevationSources.Add(new ArcGISTiledElevationSource(new Uri("https://elevation3d.arcgis.com/arcgis/rest/services/WorldElevation3D/Terrain3D/ImageServer")));
            scene.BaseSurface.NavigationConstraint = NavigationConstraint.None;
            //ARView.TranslationFactor = 1;

            ARView.SpaceEffect = SpaceEffect.None;
            ARView.AtmosphereEffect = AtmosphereEffect.None;

            scene.OperationalLayers.Add(new FeatureLayer(new Uri("https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/new_data/FeatureServer/1")));
            scene.OperationalLayers.Add(new FeatureLayer(new Uri("https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/new_data/FeatureServer/4")));

            await scene.LoadAsync();
            ARView.Scene = scene;
            ARView.LocationDataSource = new SystemLocationDataSource();
            _ = ARView.StartTrackingAsync(ARLocationTrackingMode.Initial);
        }

        private void MoveVertical(double offset)
        {
            var l = ARView.OriginCamera.Location;
            ARView.OriginCamera = ARView.OriginCamera.MoveTo(new MapPoint(l.X, l.Y, l.Z + offset, l.SpatialReference));
        }

        private async void SnapToSurface(MapPoint location)
        {
            if (location == null) return;
            if (ARView?.Scene?.Basemap?.LoadStatus == Esri.ArcGISRuntime.LoadStatus.Loaded)
            {
                try
                {
                    double deviceElevationAboveTerrain = 1.5;
                    // Perform hittest at center of screen against detected surfaces to estimate device elevation above terrain
                    var mp = ARView.ARScreenToLocation(new CoreGraphics.CGPoint(ARView.Frame.Width * .5, ARView.Frame.Height * .5));
                    if (mp != null)
                        deviceElevationAboveTerrain = ARView.Camera.Location.Z - mp.Z;

                    double elevation = await ARView?.Scene.BaseSurface.GetElevationAsync(location);
                    location = new MapPoint(location.X, location.Y, elevation + deviceElevationAboveTerrain, location.SpatialReference);
                    ARView.OriginCamera = ARView.OriginCamera.MoveTo(location);
                    ARView.ResetTracking();
                }
                catch (System.Exception ex)
                {
                    //Failed to snap location to terrain
                }
            }
        }
    }
}