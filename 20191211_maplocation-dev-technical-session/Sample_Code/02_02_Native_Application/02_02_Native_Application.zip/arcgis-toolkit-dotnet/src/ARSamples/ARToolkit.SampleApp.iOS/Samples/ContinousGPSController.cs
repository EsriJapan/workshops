﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Location;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Security;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.Tasks;
using Esri.ArcGISRuntime.UI;
using Esri.ArcGISRuntime.UI.Controls;
using UIKit;
using Esri.ArcGISRuntime.ARToolkit;
using ARKit;

namespace ARToolkit.SampleApp.Samples
{

    [SampleInfo(DisplayName = "Continuous GPS Full-scale AR", Description = "Uses the device's GPS to continously snap the origin to your current location. Best results are achieved with a very high-accuracy GPS, and a good compass alignment.")]
    public partial class ContinousGPSController : UIViewController
    {
        ARSceneView ARView;
        
        public ContinousGPSController() : base()
        {
        }

        public ContinousGPSController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidDisappear(bool animated)
        {
            ARView.StopTrackingAsync();
            base.ViewDidDisappear(animated);
        }

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            // Create a new AR Scene View, set its scene, and provide the coordinates for laying it out
            ARView = new ARSceneView() { TranslatesAutoresizingMaskIntoConstraints = false };
            UIToolbar toolbar = new UIToolbar()
            {
                TranslatesAutoresizingMaskIntoConstraints = false,
                Items = new[]
                 {
                    new UIBarButtonItem("Up", UIBarButtonItemStyle.Plain, (s,e) => MoveVertical(1d)),
                    new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
                    new UIBarButtonItem("Down", UIBarButtonItemStyle.Plain, (s,e) => MoveVertical(-1d))
                }
            };

            View.AddSubviews(ARView, toolbar);

            NSLayoutConstraint.ActivateConstraints(new[]
            {
                ARView.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor),
                ARView.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor),
                ARView.TopAnchor.ConstraintEqualTo(View.TopAnchor),
                ARView.BottomAnchor.ConstraintEqualTo(View.BottomAnchor),
                toolbar.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor),
                toolbar.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor),
                toolbar.BottomAnchor.ConstraintEqualTo(View.SafeAreaLayoutGuide.BottomAnchor)
            });

            var p = System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData);
            var scene = new Scene(Basemap.CreateImagery());
            scene.Basemap.BaseLayers[0].Opacity = .5;
            scene.BaseSurface = new Surface();
            scene.BaseSurface.BackgroundGrid.IsVisible = false;
            scene.BaseSurface.ElevationSources.Add(new ArcGISTiledElevationSource(new Uri("https://elevation3d.arcgis.com/arcgis/rest/services/WorldElevation3D/Terrain3D/ImageServer")));
            //scene.BaseSurface.NavigationConstraint = NavigationConstraint.None;

            ARView.SpaceEffect = SpaceEffect.None;
            ARView.AtmosphereEffect = AtmosphereEffect.None;
            //ARView.TranslationFactor = 1;

            await scene.LoadAsync();
            ARView.Scene = scene;
            ARView.LocationDataSource = new SystemLocationDataSource();
            await ARView.StartTrackingAsync(ARLocationTrackingMode.Continuous);
        }

        private void MoveVertical(double offset)
        {
            ARView.SetInitialTransformation(ARView.InitialTransformation + TransformationMatrix.Create(0, 0, 0, 1, 0, -offset, 0));
        }
    }
}