﻿using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Location;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ARToolkit.SampleApp.Forms.Samples
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
    [SampleInfo(DisplayName = "Continuous GPS Full-scale AR", Description = "Uses the device's GPS to continously snap the origin to your current location. Best results are achieved with a very high-accuracy GPS, and a good compass alignment.")]
    public partial class ContinuousGPSSample : ContentPage
	{
        private Scene Scene;

        public ContinuousGPSSample()
		{
            InitializeComponent();
            var t = typeof(Esri.ArcGISRuntime.Location.LocationDataSource).Assembly.GetType("Esri.ArcGISRuntime.Location.SystemLocationDataSource");
            var locationDataSource = (LocationDataSource)Activator.CreateInstance(t);
            ARView.LocationDataSource = locationDataSource;
        }

        private async void Init()
        {
            try
            {
                Scene = new Scene(Basemap.CreateStreets());
                Scene.Basemap.BaseLayers[0].Opacity = .75;
                Scene.BaseSurface = new Surface();
                Scene.BaseSurface.BackgroundGrid.IsVisible = false;
                Scene.BaseSurface.ElevationSources.Add(new ArcGISTiledElevationSource(new Uri("https://elevation3d.arcgis.com/arcgis/rest/services/WorldElevation3D/Terrain3D/ImageServer")));

                var sample_layer = new FeatureLayer(new Uri("フィーチャサービスのURL"));

                Scene.OperationalLayers.Add(sample_layer);

                var overlay = new GraphicsOverlay();
                overlay.SceneProperties.SurfacePlacement = SurfacePlacement.RelativeToScene;
                await Scene.LoadAsync();
                ARView.Scene = Scene;
                ARView.GraphicsOverlays.Add(overlay);

                Scene.BaseSurface.NavigationConstraint = NavigationConstraint.None;
                ARView.SpaceEffect = SpaceEffect.None;
                ARView.AtmosphereEffect = AtmosphereEffect.None;

                Scene.Basemap.BaseLayers[0].IsVisible = !Scene.Basemap.BaseLayers[0].IsVisible;

                await ARView.StartTrackingAsync(Esri.ArcGISRuntime.ARToolkit.ARLocationTrackingMode.Continuous);

            }
            catch (System.Exception ex)
            {
                await DisplayAlert("Failed to load scene", ex.Message, "OK");
                await Navigation.PopAsync();
            }
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            Init();
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            ARView.StopTrackingAsync();
        }

        private void UpButton_Click(object sender, EventArgs e)
        {
            var offset = 1d;
            ARView.SetInitialTransformation(ARView.InitialTransformation + TransformationMatrix.Create(0, 0, 0, 1, 0, -offset, 0));

        }

        private void DownButton_Click(object sender, EventArgs e)
        {
            var offset = -1d;
            ARView.SetInitialTransformation(ARView.InitialTransformation + TransformationMatrix.Create(0, 0, 0, 1, 0, -offset, 0));

        }

        private void ToggleBasemap_Click(object sender, EventArgs e)
        {
            Scene.Basemap.BaseLayers[0].IsVisible = !Scene.Basemap.BaseLayers[0].IsVisible;
        }
    }
}