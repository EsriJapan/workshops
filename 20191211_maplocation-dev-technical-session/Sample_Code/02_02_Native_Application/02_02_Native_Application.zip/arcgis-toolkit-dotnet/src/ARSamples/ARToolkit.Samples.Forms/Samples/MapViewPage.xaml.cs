﻿using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.UI;
using System;
using System.Diagnostics;
using System.Linq;
using Xamarin.Forms;

namespace ARToolkit.Samples.Forms.Samples
{
    public partial class MapViewPage : ContentPage
    {

        // String array to store the different device location options.
        private string[] _navigationTypes =
        {
            "On",
            "Re-Center",
            "Navigation",
            "Compass"
        };

        public MapViewPage()
        {
            InitializeComponent();
            Initialize();
        }

        private void Initialize()
        {
            // Create new Map with basemap.
            Map myMap = new Map(Basemap.CreateStreetsVector());

            var sample_layer = new FeatureLayer(new Uri("フィーチャサービスのURL"));

            //scene_line_layer.SceneProperties.SurfacePlacement = SurfacePlacement.RelativeToScene;
            myMap.OperationalLayers.Add(sample_layer);

            // Assign the map to the MapView.
            MyMapView.Map = myMap;
            //MyMapView.LocationDisplay.AutoPanMode = LocationDisplayAutoPanMode.Navigation;
        }

        private void OnMapClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new ARToolkit.SampleApp.Forms.Samples.ContinuousGPSSample());
        }

        private void OnStopClicked(object sender, EventArgs e)
        {
            MyMapView.LocationDisplay.IsEnabled = false;
        }

        private async void OnStartClicked(object sender, EventArgs e)
        {
            // Show sheet and get title from the selection.
            string selectedMode =
                await ((Page)Parent).DisplayActionSheet("Select navigation mode", "Cancel", null, _navigationTypes);

            // If selected cancel do nothing.
            if (selectedMode == "Cancel") return;

            // Get index that is used to get the selected url.
            int selectedIndex = _navigationTypes.ToList().IndexOf(selectedMode);

            switch (selectedIndex)
            {
                case 0:
                    // Starts location display with auto pan mode set to Off.
                    MyMapView.LocationDisplay.AutoPanMode = LocationDisplayAutoPanMode.Off;
                    break;

                case 1:
                    // Starts location display with auto pan mode set to Re-center.
                    MyMapView.LocationDisplay.AutoPanMode = LocationDisplayAutoPanMode.Recenter;
                    break;

                case 2:
                    // Starts location display with auto pan mode set to Navigation.
                    MyMapView.LocationDisplay.AutoPanMode = LocationDisplayAutoPanMode.Navigation;
                    break;

                case 3:
                    // Starts location display with auto pan mode set to Compass Navigation.
                    MyMapView.LocationDisplay.AutoPanMode = LocationDisplayAutoPanMode.CompassNavigation;
                    break;
            }

            try
            {
                // Permission request only needed on Android.
#if XAMARIN_ANDROID
                // See implementation in MainActivity.cs in the Android platform project.
                MainActivity.Instance.AskForLocationPermission(MyMapView);
#else
                await MyMapView.LocationDisplay.DataSource.StartAsync();
                MyMapView.LocationDisplay.IsEnabled = true;
#endif
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
                await Application.Current.MainPage.DisplayAlert("Couldn't start location", ex.Message, "OK");
            }
        }

    }
}
