define({
  "_widgetLabel": "Contrôleur d’en-tête",
  "signin": "Connexion",
  "signout": "Déconnexion",
  "about": "A propos",
  "signInTo": "Se connecter à",
  "cantSignOutTip": "Cette fonction est N/D en mode d’aperçu.",
  "more": "plus"
});