define({
  "_themeLabel": "Inklapbaar thema",
  "_layout_default": "Standaardlay-out",
  "_layout_layout1": "Lay-out 1"
});