require([
    "esri/layers/FeatureLayer", 
    "esri/widgets/FeatureForm", 
    "esri/widgets/FeatureForm/FieldConfig", 
    "esri/widgets/FeatureForm/FieldGroupConfig", 
    "esri/Graphic", 
    "esri/geometry/Point", 
    "esri/views/MapView", 
    "esri/Map",
    "esri/widgets/Locate"
  ], function(FeatureLayer, FeatureForm, FieldConfig, FieldGroupConfig, Graphic, Point, MapView, Map, Locate) {

    // フィーチャレイヤーの作成
    var featureLayer = new FeatureLayer({
        portalItem: {
            id: "fbb54b7143cb40858c584db12d1c30b2"
        },
        outFields: ["*"]
    });

    var defaultParam = {
        addFeatures: [
            new Graphic({
                geometry: new Point({
                    x: 0,
                    y: 0
                }),
                attributes: {
                }
            })
        ]
    };

    var view = new MapView({
        container: "mapDiv",
        map: new Map({ basemap: "topo" })
    });

    var locate = new Locate({
        view: view
    });

    view.ui.add(locate, {
        position: "top-left"
    });

    // FeatureForm ウィジェットの作成
    var form = new FeatureForm({
        container: "featureFormDiv",
        groupDisplay: "sequential",
        layer: featureLayer,
        fieldConfig: createFieldConfig()
    });



    function createFieldConfig() {
        return [createTreeInfoGroup(), createUserInfoGroup()];
    }

    function createTreeInfoGroup() {
        return new FieldGroupConfig({
            label: "街路樹の情報",
            description: "樹木の情報について入力してください。",
            fieldConfig: [
                new FieldConfig({
                    name: "Common_Name",
                    label: "樹木名を入力してください" ,
                    required: true
                }),
                new FieldConfig({
                    name: "Condition",
                    label: "樹木の成長状況をリストから選択してください。" ,
                    required: true
                }),
                new FieldConfig({
                    name: "DBH",
                    label: "胸高直径（胸の高さの木の直径）を計測して入力してください。"
                })
            ],

        });
    }

    function createUserInfoGroup() {
        var reportUser = new FieldConfig({
            name: "Collected_By",
            label: "調査者の名前を入力してください。",
            required: true
        });
        var reportDate = new FieldConfig({
            name: "Collected_Date",
            label: "調査日を入力してください。"
        });
        var reportNote = new FieldConfig({
            name: "Notes",
            label: "何かに補足事項がある場合は入力してください。"
        });
        var userInfoGroup = new FieldGroupConfig({
            label: "その他の情報",
            description: "その他の情報を入力してください。",
            fieldConfig: [reportUser, reportDate, reportNote]
        });
        return userInfoGroup;
    }



    // FeatureForm のイベント処理
    var editFeature;
    form.on("submit", function () {
        // ジオメトリの存在をチェック
        if (locate.graphic.geometry === null) {
            document.getElementById("err").className = "material-icons customError visible";
            return;
        }　else {
            document.getElementById("err").className = "material-icons customError hidden";
        }
        if (editFeature) {
            // 編集フィーチャにジオメトリを設定
            editFeature.geometry = locate.graphic.geometry;

            // 編集フィーチャにFeatureForm の属性を設定
            var updated_1 = form.getValues();
            Object.keys(updated_1).forEach(function (name) {
                editFeature.attributes[name] = updated_1[name];
            });
            // サーバーに編集を適用するためのパラメータの作成
            var edits = {
                updateFeatures: [editFeature]
            };
            applyAttributeUpdates(edits);
        }
    });


    createNewFeature(defaultParam);
    
    // 情報を送信ボタンのクリックイベント
    document.getElementById("addEntry").onclick = function () {
        form.submit();
    };

    // フィーチャを検索して FeatureForm と編集対象のフィーチャを設定
    function selectFeature(objectId) {
        // フィーチャサービスから検索
        featureLayer
            .queryFeatures({
            objectIds: [objectId],
            outFields: ["*"],
            returnGeometry: false
        })
            .then(function (results) {
            if (results.features.length > 0) {
                form.feature = editFeature = results.features[0];
            }
        });
    }

    // FeatureLayer.applyEdits() を使用してフィーチャサービスに編集内容を更新
    function applyAttributeUpdates(params) {
        document.getElementById("addEntry").style.cursor = "progress";
        featureLayer
            .applyEdits(params)
            .then(function (editsResult) {
            // 新規に作成したフィーチャのOBJECTIDを取得してフィーチャを選択（ハイライト表示）
            if (editsResult.updateFeatureResults.length > 0) {
                createNewFeature(defaultParam);
            }
            document.getElementById("addEntry").style.cursor = "pointer";
            // 編集完了のバナーを表示
            document.getElementById("bannerDiv").className = "successBanner visible";
            // バナーを3秒後に非表示
            setTimeout(function () {
                document.getElementById("bannerDiv").className = "successBanner hidden";
            }, 3000);
        })
            .catch(function (error) {
            console.log("===============================================");
            console.error("[ applyEdits ] FAILURE: ", error.code, error.name, error.message);
            console.log("error = ", error);
            document.getElementById("addEntry").style.cursor = "pointer";
        });
    }

    // ダミー用のフィーチャを作成
    function createNewFeature(params) {
        featureLayer.applyEdits(params).then(function (result) {
            if (result.addFeatureResults.length === 1) {
                selectFeature(result.addFeatureResults[0].objectId);
            }
        });
    }
});
