# coding: utf-8
import os, datetime, csv
import arcpy
from arcgis.gis import GIS
from arcgis.features import GeoAccessor

# GDB 格納先
gdb = r"対象のGDBのディレクトリ"

# ワークスペース設定
arcpy.env.workspace = gdb

# フィーチャクラス名
feature_class = "売上"

# CSVファイル用に年月日を設定
dt_now = datetime.datetime.now()

# CSVデータ格納先
directory_for_csv = r"対象のCSVのディレクトリ"

# CSVファイル名を作成（例：20191217_売上.csv）
file_name = str(dt_now.year) + str(dt_now.month) + str(dt_now.day) + "_売上.csv"

##########################
#         メイン         #
##########################

def main():
    # 「売上」フィーチャクラスの全レコードをデリートしてCSVのデータをインサート
    if arcpy.Exists(feature_class):
        insert_point()

    # WebGISにアップロード
    upload_to_web()


##########################
#    売上データ取込      #
##########################

def insert_point():

    # 既存のデータをデリート
    arcpy.DeleteFeatures_management(feature_class)

    csv_file = os.path.join(directory_for_csv, file_name)

    # CSVファイルをオープン
    with open(csv_file, 'r', encoding='SHIFT-JIS') as csvfile:

        reader = csv.reader(csvfile)
        header = next(reader)

        for row in reader:

            # CSVファイルを読み込んでポイント作成
            with arcpy.da.InsertCursor(feature_class,
                                       ["SHAPE@",
                                        "店舗ID",
                                        "年月日",
                                        "店舗名",
                                        "区",
                                        "店長",
                                        "売上",
                                        "緯度",
                                        "経度"]) as pointCursor:

                points = arcpy.Array()
                points.add(arcpy.Point(row[6],row[7]))

                for point in points:

                    pointrow = [point, int(row[0]), row[1],  row[2], row[3],
                                row[4], row[5], float(row[6]), float(row[7])]

                    pointCursor.insertRow(pointrow)

#######################################
# ジオデータベースをWebにアップロード #
#######################################

def upload_to_web():

    gis = GIS("url", "ユーザー", "パスワード")

    item = gis.content.search("ダッシュボードのアイテムID")

    # 既にサービスにアップロードされている場合
    if len(item) > 0:
        # アイテムのレイヤーを取得
        lyr = item[0].layers[0]

        # spatially enabled dataframe に変換
        sedf = GeoAccessor.from_layer(lyr)

        # featuresetに変換
        del_fset = sedf.spatial.to_featureset()

        # データを削除
        lyr.edit_features(deletes = del_fset)

        # 更新されたFGDBからspatially enabled dataframe作成
        add_sedf = GeoAccessor.from_featureclass(os.path.join(gdb,feature_class))

        # featuresetに変換
        add_fset = add_sedf.spatial.to_featureset()

        # データを追加
        lyr.edit_features(adds = add_fset)

if __name__ == '__main__':
    main()
