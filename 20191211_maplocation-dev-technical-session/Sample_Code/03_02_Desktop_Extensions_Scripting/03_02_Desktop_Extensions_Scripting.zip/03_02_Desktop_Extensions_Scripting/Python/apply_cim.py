import arcpy

# 開いているプロジェクトと「店舗マップ」マップを取得
p = arcpy.mp.ArcGISProject("current")
m = p.listMaps("店舗マップ")[0]

# 売上レイヤーを取得
lyr = m.listLayers("売上")[0]

# シンボルを取得
sym = lyr.symbology

# 等級別レンダラーの設定
sym.updateRenderer("GraduatedColorsRenderer")
sym.renderer.classificationField = "売上"

# 上限値設定
classBreakValues = [2000000,3000000,5000000]
sym.renderer.breakCount = len(classBreakValues)
count = 0

for brk in sym.renderer.classBreaks:
    brk.upperBound = classBreakValues[count]
    count += 1

sym.renderer.colorRamp = p.listColorRamps("フル スペクトル (明るい)")[0]
lyr.symbology = sym

# レイヤーの CIM を取得
cim_lyr = lyr.getDefinition('V2')

# レイヤーの CIM を取得
for cim in cim_lyr.renderer.breaks:
    cim_symbol = cim.symbol.symbol.symbolLayers[0]
    marker_graphics = cim_symbol.markerGraphics[0]
    graphic = marker_graphics.symbol.symbolLayers[1]

    # 上限値が2000000円以下の場合は赤
    if cim.upperBound <= 2000000:

        cim.label = "低調"
        cim_symbol.size = 5
        graphic.color.values = [255,0,0,255]

    # 上限値が3000000円以下の場合は黄色
    elif cim.upperBound <= 3000000:

        cim.label = "普通"
        cim_symbol.size = 10
        graphic.color.values = [255,255,0,255]

    # 上限値が5000000円以下の場合は青
    elif cim.upperBound <= 50000000:

        cim.label = "好調"
        cim_symbol.size = 20
        graphic.color.values = [0,0,255,255]

# 適用
lyr.setDefinition(cim_lyr)