﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;

namespace ConfigurationSample
{

    internal class CoordinatePicker : Button
    {
        protected override void OnClick()
        {
            var cmd = FrameworkApplication.GetPlugInWrapper("CoordinateSystemAddin_ShowDialogButton") as ICommand;
            if (cmd.CanExecute(null))
                // マップツール起動
                cmd.Execute(null);
        }
    }



}
