import arcpy
import pythonaddins

class ButtonClass1(object):
    """Implementation for Addin_solution_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pythonaddins.GPToolDialog(r'C:\data\ArcMap\Toolbox.tbx','Print')
