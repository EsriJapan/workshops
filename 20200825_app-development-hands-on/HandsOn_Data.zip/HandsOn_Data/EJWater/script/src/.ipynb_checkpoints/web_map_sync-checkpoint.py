# -*- coding: utf-8 -*-

try:
    import arcpy
    has_arcpy = True
except ImportError:
    has_arcpy = False
if not has_arcpy:
    raise Exception("このクラスは arcpy が必要です。ArcGIS Pro の Python 環境で実行してください。")

import os, sys
import tempfile
import uuid
from arcgis.gis import GIS
from lib.config import Config
from lib.web_gis_connector import WebGISConnector
from lib.logging import Logging

class WebMapSync:
    """ローカルの FGDB と フィーチャ サービスの同期を行うクラス。実行には arcpy が必要です。"""
    def __init__(self, prj_path, prj_file, sd_id):        
        self.logging = Logging("FGDBとフィーチャ サービスの同期を開始")
        self.prj_path = prj_path
        self.prj_file = prj_file
        self.sd_id = sd_id
        Config.read_config()

    def to_feature_service(self):
        """ローカルの FGDB を元にフィーチャ サービスを更新します"""

        # 共有設定
        # shrOrg = True
        # shrEveryone = False
        # shrGroups = ""
        
        # SD ファイルのパス
        ### todo: 必要に応じて一時ファイルにする
        sddraft = os.path.join(self.prj_path, "WebUpdate.sddraft")
        sd = os.path.join(self.prj_path, "WebUpdate.sd")
        
        # SD ドラフトの作成とステージング
        print("SD ファイルを作成しています…")
        arcpy.env.overwriteOutput = True
        prj = arcpy.mp.ArcGISProject(os.path.join(prj_path, prj_file))
        mp = prj.listMaps()[0]
        arcpy.mp.CreateWebLayerSDDraft(mp,
                                       sddraft,
                                       "test",
                                       "MY_HOSTED_SERVICES",
                                       "FEATURE_ACCESS","", True, True)
        arcpy.StageService_server(sddraft, sd)
        print("ポータル [{0}] に [{1}] として接続します".format(portal, user))
        
        gis = WebGISConnector.python_api_connect()

        # ポータル内の SD ファイルを更新
        print("ポータル内の SD ファイルを検索します")
        try:
            sd_item = gis.content.get(self.sd_id)
        except:
            print("アイテムが見つからなかったかアクセスできなかった可能性があります。")
            
        print("SD ファイル: {0}, ID: {1} が見つかりました。上書き・更新します。".format(sd_item.title, sd_item.id))
        sd_item.update(data=sd)
        print("SD ファイルを上書きしてサービスを更新します。")
        fs = sd_item.publish(overwrite=True)
        
#         if shrOrg or shrEveryone or shrGroups:
#             print(“Setting sharing options…”)
#             fs.share(org=shrOrg, everyone=shrEveryone, groups=shrGroups)
        
        print("アップデートが終了しました。フィーチャ サービス: {0} – ID: {1}".format(fs.title, fs.id))
    

    ################################
    #### FSをFGDBに書き込むメソッド作成 ####
    ################################
    def to_fgdb():
        # フィーチャサービスを取得 → to_featureclass使う？
        # 型が変わりそう＋アップデートの方が変化分をすべて把握する必要なし
        pass

    ################################
    #### ただのテスト用：後で消す####
    ################################
    def test_publish_sd():
        # 変数設定
        prj_path = Config.get_prj_path() # プロジェクト フォルダーのパス
        prj_file = Config.get_prj_file() # プロジェクト ファイル名

        # ArcGIS Online にサイン イン
        con = WebGISConnector.web_gis_connector()
        con.arcpy_connect()
        
        # プロジェクト ファイルのオブジェクト取得
        aprx = arcpy.mp.ArcGISProject(os.path.join(prj_path, prj_file))

        # マップとレイヤーを取得
        map = aprx.listMaps()[0]
        
        # 作成するサービス定義ドラフトファイル、サービス定義ファイルのファイル名を設定
        sddraft = os.path.join(prj_path, "WebUpdate.sddraft")
        sd = os.path.join(prj_path, "WebUpdate.sd")
        
        # sdドラフトの作成とステージング
        print("SD ファイルを作成しています…")
        arcpy.env.overwriteOutput = True
        prj = arcpy.mp.ArcGISProject(os.path.join(prj_path, prj_file))
        mp = prj.listMaps()[0]
        arcpy.mp.CreateWebLayerSDDraft(mp,
                                       sddraft,
                                       sd_fs_name,
                                       ‘MY_HOSTED_SERVICES’,
                                       ‘FEATURE_ACCESS’,”, True, True)
        arcpy.StageService_server(sddraft, sd)
                
        # ArcGIS Online にアップロード（サービス定義のアップロード ツールを使用）
        arcpy.UploadServiceDefinition_server(sd_output, "HOSTING_SERVER")