import sys
import arcpy
# from data_setter import DataSetter
# from data_importer import DataImporter
from lib.config import Config

def main():

    Config.read_config()
    arcpy.env.workspace = Config.get_fgdb_path()

    # # コマンドライン引数なしの場合は何もしない
    # if len(sys.argv) == 1:
    #     pass

    # else:
    #     if sys.argv[1] == 1:
    #         s = DataSetter()
    #         s.uncompress_zip()

if __name__ == '__main__':
    main()