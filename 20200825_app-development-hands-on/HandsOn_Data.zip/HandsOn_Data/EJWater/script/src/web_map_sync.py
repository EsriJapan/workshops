# -*- coding: utf-8 -*-

try:
    import arcpy
    has_arcpy = True
except ImportError:
    has_arcpy = False
if not has_arcpy:
    raise Exception("このクラスは arcpy が必要です。ArcGIS Pro の Python 環境で実行してください。")

import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from arcgis.gis import GIS
from lib.config import Config
from lib.logging import Logging

class FeatureServiceSync:
    """ローカルの FGDB と フィーチャ サービスの同期を行うクラス。実行には arcpy が必要です。"""
    def __init__(self):        
        self.logging = Logging("FGDBとフィーチャ サービスの同期を開始")
        
        # GISに接続
        Config.read_config()
        self.gis = GIS(Config.get_portal_url(),
                       Config.get_username(),
                       Config.get_password())
        
        # 各処理共通で使う変数
        self.prj_path = Config.get_prj_path()
        self.prj_file = Config.get_prj_file()
        self.fgdb = Config.get_fgdb()
        self.sd_id = Config.get_sd_id()
        self.map_id = Config.get_web_map_id()

    def update_fservice(self):
        prj_path = os.path.join(self.prj_path,
                                self.prj_file)
        
        sd_item = self.gis.content.get(self.sd_id)
        map_item = self.gis.content.get(self.map_id)

        # Temp のコンテンツを作成するためのパス
        temp = sys.path[0]
        sddraft = os.path.join(temp, "WebUpdate.sddraft")
        sd = os.path.join(temp, "WebUpdate.sd")

        # SD ファイル作成
        self.logging.info("SD ファイルを作成します")
        
        arcpy.env.overwriteOutput = True
        prj = arcpy.mp.ArcGISProject(prj_path)
        mp = prj.listMaps()[0]
        arcpy.mp.CreateWebLayerSDDraft(mp, sddraft, sd_item.title, "MY_HOSTED_SERVICES", "FEATURE_ACCESS", "", True, True)
        arcpy.StageService_server(sddraft, sd)

        # ポータルの SD ファイルを上書き更新して再公開
        sd_item.update(data=sd)
        self.logging.info("フィーチャ サービスを上書きしています")
        fs = sd_item.publish(overwrite=True)

        self.logging.info("フィーチャ サービスの更新が完了しました")