import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from lib.logging import Logging
from preplan import offlineAreaManager

def main():
    """プレプラン作成のメイン関数"""
    args = sys.argv
    logging = Logging("メイン関数実行")
    try:
        category = args[1]
    except IndexError as e:
        logging.error("カテゴリー変数を確認してください")
    
    if category == "1":
        zukaku_name = args[2]
        zukaku_numbers = args[3]
        offlineArea_name = args[4]
        o = offlineAreaManager()
        o.create_offline_area(zukaku_name, zukaku_numbers, offlineArea_name, category)
        return
    
    if category == "2":
        zukaku_name = args[2]
        o = offlineAreaManager()
        o.extract_index_number(zukaku_name, category)
        return
        
    if category == "3":
        zukaku_name = args[2]
        offlineArea_name = args[3]
        o = offlineAreaManager()
        o.delete_offline_area(zukaku_name, offlineArea_name, category)
        return
    
    logging.error("カテゴリー変数を確認してください")

if __name__ == '__main__':
    main()