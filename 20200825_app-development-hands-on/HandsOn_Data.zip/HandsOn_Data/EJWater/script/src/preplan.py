# -*- coding: utf-8 -*-

try:
    import arcpy
    has_arcpy = True
except ImportError:
    has_arcpy = False
if not has_arcpy:
    raise Exception("このクラスは arcpy が必要です。ArcGIS Pro の Python 環境で実行してください。")

import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

import tempfile
import uuid
from arcgis.gis import GIS
from arcgis.mapping import WebMap
from arcgis.features import GeoAccessor, FeatureLayer
from arcgis.geometry import Point, Polygon
from lib.config import Config
from lib.logging import Logging

class offlineAreaManager:
    """オフライン エリアの作成、削除等を行うクラス"""
    def __init__(self):
        self.logging = Logging("オフライン エリア管理")
        
        # GISに接続
        Config.read_config()
        self.gis = GIS(Config.get_portal_url(),
                       Config.get_username(),
                       Config.get_password())
        
        # Web Map の ID を取得
        Config.read_config()
        self.web_map_id = Config.get_web_map_id()
        
        # 各処理共通で使う変数
        self.web_map_item = self.gis.content.get(self.web_map_id)
        self.web_map = WebMap(self.web_map_item)
        self.offline_list = self.web_map.offline_areas.list()
        
    def create_offline_area(self, zukaku_name, zukaku_numbers, offlineArea_name, category):
        """作成する範囲の図郭番号を元にオフライン エリアを作成します。"""
        # 作成しようとしているオフライン エリア名が既存と重複している場合は -2 を返却
        for offline_area in self.offline_list:
            if offline_area.title == offlineArea_name:
                print(-2)
                self.logging.debug("オフライン エリア名が既存のものと重複しています")
                return
        
        # フィーチャ サービスから対象の図郭レイヤーを取得し SEDF に変換
        try:
            lyr_url = Config.config_dic[zukaku_name]
            target_lyr = [FeatureLayer(lyr_url)]
        except KeyError as e:
            self.logging.warn("指定した図郭名と対応するレイヤーの URL が設定ファイルに記載されていない可能性があります。\
                               フィーチャ サービス内の全レイヤーから図郭名に対応したレイヤーを探すため、実行速度が低下する可能性があります。")
            fs = self.gis.content.get(Config.get_fs_id())
            target_lyr = [lyr for lyr in fs.layers if lyr.properties["name"] == zukaku_name]

        try:
            target_lyr[0]
        except IndexError as e:
            print(-1)
            self.logging.error("指定した図郭名のレイヤーがフィーチャ サービスに含まれていない可能性があります。")
            return
        
        # 対象の図郭のエクステントを取得しオフライン エリア作成
        zukaku_list = zukaku_numbers.split(",")
        query_list = []
        for zukaku in zukaku_list:
            query = "図郭番号 = '{}'".format(zukaku)
            query_list.append(query)
        sql = " OR ".join(query_list) # "図郭番号 = 'xxx' OR 図郭番号 = 'xxx'" のような sql 文を作成
        
        fset = target_lyr[0].query(where = sql, return_extent_only=True, out_sr=102100)
        extent = fset["extent"]
        
        if extent == None:
            print(-1)
            self.logging.error("指定した図各番号からエクステントを取得出来ませんでした。図郭番号が正しいか確認してください。")
            return            

        try:
            item_prop = {"title": offlineArea_name,
                         "snippet": "{}のオフライン エリアです".format(offlineArea_name),
                         "tags": ["offline area", zukaku_name]}
            a = self.web_map.offline_areas.create(area=extent,
                                                  item_properties=item_prop,
                                                  min_scale=2000,
                                                  max_scale=250,
                                                  refresh_schedule="Daily")
            # a.create_thumbnail() # todo: F/Sであればサムネイルが作れるが、offline のパッケージでは別の方法が要る
            
            print(1)
            self.logging.info("オフライン エリアを作成しました")
        except Exception as e:
            print(-1)
            self.logging.error(e.args)

    def delete_offline_area(self, zukaku_name, offlineArea_name, category):
        # 作成済みオフライン エリアのタグに zukaku_name が含まれ、タイトルが offlineArea_name と同じアイテムを抽出
        zukaku_name_list = [offline_area for offline_area in self.offline_list if zukaku_name in offline_area.tags]
        extracted_list = [offline_area for offline_area in zukaku_name_list if offlineArea_name == offline_area.title]
        
        try:
            extracted_list[0]
        except IndexError as e:
            print(-2)
            self.logging.error("指定された名前のオフライン エリアが見つからなかった可能性があります")
            return
        
        try:
            extracted_list[0].delete()
            print(0)
            self.logging.info("指定した名前のオフライン エリアが削除されました")
            return
        except Exception as e:
            print(-1)
            self.logging.error(e)

    def extract_index_number(self, zukaku_name, category):
        """図郭名 (図郭レイヤー名) に基づいて、作成されたオフライン エリア及びその中に含まれている図郭番号を返却します。
        オフライン エリア作成時にタグ付けされた図郭名を使ってフィーチャ サービスの内のレイヤーを特定します"""
        # オフラインエリアのジオメトリを使って、重心が重複する図郭を抽出する
        # 重心を使う理由は、オフライン作成時の微妙なズレが影響して、各図郭のジオメトリとオフラインエリアのジオメトリがぴったり重ならないため
                
        extracted_list = [offline_area for offline_area in self.offline_list if zukaku_name in offline_area.tags]
        try:
            extracted_list[0]
        except IndexError as e:
            self.logging.error("指定した図郭名から作成されたオフライン エリアが見つかりませんでした")
            
        try:
            lyr_url = Config.config_dic[zukaku_name]
            lyr = [FeatureLayer(lyr_url)]
        except KeyError as e:
            self.logging.warn("指定した図郭名と対応するレイヤーの URL が設定ファイルに記載されていない可能性があります。\
                               フィーチャ サービス内の全レイヤーから図郭名に対応したレイヤーを探すため、実行速度が低下する可能性があります。")
            # タグの中の図郭名を使ってフィーチャ サービスから該当する図郭レイヤーを取得する
            fs = self.gis.content.get(Config.get_fs_id())
            lyr = [lyr for lyr in fs.layers if lyr.properties.name == zukaku_name]
            
        try:
            lyr[0]
        except IndexError as e:
            self.logging.error("指定されたオフライン エリアのタグにフィーチャ サービス内のレイヤー名が含まれていませんでした。\
                                作成したオフライン エリアが異なるフィーチャ サービスから作成されている可能性があります")
            return
        
        # オフライン エリア毎に作成元の図郭レイヤーから図郭番号を取得する
        final_result = []
        for offline_area in extracted_list:
            # 該当する図郭レイヤーから Spatially Enabled DataFrame (sedf) を作成し、各図郭 (行) の重心を取得する
            sedf = GeoAccessor.from_layer(lyr[0])
            new_sedf = sedf.assign(centroid_xy = sedf["SHAPE"].geom.centroid) # 新しい列 (centroid_xy) を作成し重心のタプルを加える
            centroid_geom = []
            for row in range(len(new_sedf)):
                point = Point({"x": new_sedf["centroid_xy"][row][0],
                               "y": new_sedf["centroid_xy"][row][1],
                               "spatialReference": new_sedf.spatial.sr}) # 各行の重心の Point を作成
                centroid_geom.append(point)
            new_sedf["centroid"] = centroid_geom
            new_sedf.spatial.set_geometry(col="centroid") # sedf のジオメトリを作成した Point に変更

            # 重複する重心をフィルターするためのオフライン エリアのポリゴン
            ext = offline_area.properties["extent"]
            new_sedf.spatial.sr = ext["spatialReference"] # sedf の空間参照をオフライン エリアのものと合わせる
            ext_poly = Polygon({"rings": [[[ext["xmin"], ext["ymin"]],
                                           [ext["xmin"], ext["ymax"]],
                                           [ext["xmax"], ext["ymax"]],
                                           [ext["xmax"], ext["ymin"]],
                                           [ext["xmin"], ext["ymin"]]]],
                                "spatialReference": ext["spatialReference"]})
            zukaku_num_array = new_sedf.spatial.select(ext_poly)["図郭番号"]
            zukaku_num_str = ",".join(zukaku_num_array)
            result = offline_area.title + "," + zukaku_num_str
            final_result.append(result)
        
        print(",,".join(final_result))