# coding:utf-8
import os
import time
from pathlib import Path
from logging import Formatter, handlers, StreamHandler, getLogger, DEBUG

class Logging:
    def __init__(self, function_name, name = __name__):
        self.logger = getLogger(name)
        self.logger.setLevel(DEBUG)
        self.function_name = function_name
        formatter = Formatter("[%(asctime)s] [%(process)d] [%(name)s] [%(levelname)s] %(message)s")

        handler = StreamHandler()
        handler.setLevel(DEBUG)
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

        handler = handlers.RotatingFileHandler(filename = self._make_log_name(),
                                               maxBytes = 100000000,
                                               backupCount = 3)
        handler.setLevel(DEBUG)
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

    def _make_log_name(self):

        log_dir = Path(__file__).parent
        log_dir /= '../logs'
        time_str = time.strftime("%Y%m%d%H%M%S")

        return os.path.join(log_dir, self.function_name + "_" + time_str + ".log")

    def debug(self, msg):
        self.logger.debug(msg)

    def info(self, msg):
        self.logger.info(msg)

    def warn(self, msg):
        self.logger.warning(msg)

    def error(self, msg):
        self.logger.error(msg)

    def critical(self, msg):
        self.logger.critical(msg)

if __name__ == '__main__':
    a = Logging("aaa")
    print(a._make_log_name())
