# coding:utf-8
import os
import configparser
from pathlib import Path

class Config:

    config_dic = {}

    def __init__(self):
        pass
    
    @classmethod
    def get_updated_time(cls):
        """更新時間"""
        return Config.config_dic["updated_time"]

    @classmethod
    def get_prj_path(cls):
        """Project フォルダーのパス"""
        return Config.config_dic["prj_path"]
    
    @classmethod
    def get_fgdb_path(cls):
        """gdbが配置されるパス"""
        return Config.config_dic["fgdb_path"]

    @classmethod
    def get_prj_file(cls):
        """Project ファイルのパス"""
        return Config.config_dic["prj_file"]
    
    @classmethod
    def get_fgdb(cls):
        """FGDB"""
        return Config.config_dic["fgdb"]

    @classmethod
    def get_rousui_fc(cls):
        """漏水フィーチャ クラスの名前"""
        return Config.config_dic["rousui_fc"]
    
    @classmethod
    def get_portal_url(cls):
        """ポータルのURL"""
        return Config.config_dic["portal_url"]
    
    @classmethod
    def get_username(cls):
        """ポータルのユーザー名"""
        return Config.config_dic["user_name"]
    
    @classmethod
    def get_password(cls):
        """ポータルのパスワード"""
        return Config.config_dic["password"]

    @classmethod
    def get_web_map_id(cls):
        """Web Map のアイテム ID"""
        return Config.config_dic["web_map_id"]

    @classmethod
    def get_fs_id(cls):
        """フィーチャ サービスのアイテム ID"""
        return Config.config_dic["fs_id"]

    @classmethod
    def get_sd_id(cls):
        """SD ファイルのアイテム ID"""
        return Config.config_dic["sd_file_id"]
    
    @classmethod
    def get_rousui_lyr_url(cls):
        """漏水レイヤーの URL"""
        return Config.config_dic["rousui_lyr_url"]

    @classmethod
    def read_config(cls):
        """設定ファイルの内容を読み込む。読み込んだ内容は config_dic プロパティで参照可能"""

        config = configparser.ConfigParser()

        path = Path(__file__).parent
        path /= '../config'
        config_dir = os.path.join(path, "config.ini")
        config.read(config_dir)

        config.optionxform = str

        #config_dic = {}
        for section in config.sections(): #iniファイルの中身をディクショナリに格納
            for key in config.options(section):
                Config.config_dic[key] = config.get(section, key)

if __name__ == '__main__':
    c = Config()
    print(c.featureclass_name)