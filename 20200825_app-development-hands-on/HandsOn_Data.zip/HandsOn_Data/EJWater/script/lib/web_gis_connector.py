# -*- coding: utf-8 -*-

import arcpy
from arcgis.gis import GIS
from lib.config import Config

class WebGISConnector:
    """設定ファイルに記載された情報をもとに arcpy もしくは ArcGIS API for Python を使って Web GIS に接続するクラス"""
    
    def __init__(self):
        self.confg = Config.read_config()
        
    @classmethod
    def arcpy_connect(self):
        """arcpy を使ってサインイン"""
        return arcpy.SignInToPortal(Config.get_portal_url(),
                                    Config.get_username(),
                                    Config.get_password())
    
    @classmethod
    def python_api_connect(self):
        """ArcGIS API for Python を使ってサインイン"""
        return GIS(Config.get_portal_url(),
                   Config.get_username(),
                   Config.get_password())