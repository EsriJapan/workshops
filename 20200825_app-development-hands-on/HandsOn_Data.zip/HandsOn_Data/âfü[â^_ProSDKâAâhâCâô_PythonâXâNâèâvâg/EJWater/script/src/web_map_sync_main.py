# -*- coding: utf-8 -*-
import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from web_map_sync import FeatureServiceSync

def web_map_sync_main():
    s = FeatureServiceSync()
    s.update_fservice()

if __name__ == '__main__':
    web_map_sync_main()