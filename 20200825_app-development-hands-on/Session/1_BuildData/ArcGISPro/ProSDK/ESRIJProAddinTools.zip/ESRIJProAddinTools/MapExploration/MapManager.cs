﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Raster;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESRIJ.ArcGISPro
{
    /// <summary>
    /// マップ操作系メイン処理
    /// </summary>
    public class MapManager : BaseMapActivity
    {
        private string GdbPath = MapModule.PathSettings["GDB"];

        public void RotateMap()
        {
            var mapView = MapView.Active;
            if (mapView == null)
                return;

            var angle = MapModule.MapAngle.Text;
            if (!Utils.TryParse<double>(angle, out double i))
            {
                MessageBox.Show("角度が不正です",
                                "エラー",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Error,
                                System.Windows.MessageBoxResult.Yes);

                return;
            }

            if (Utils.NumberOfCharacters(angle) > 8)
            {
                MessageBox.Show("桁数が大きすぎます",
                                "エラー",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Error,
                                System.Windows.MessageBoxResult.Yes);

                return;
            }

            //カメラを取得
            var camera = mapView.Camera;

            //var angle = MapModule.MapAngle.Text;
            if (angle == null || angle == "")
                return;

            if (mapView.ViewingMode == MapViewingMode.Map)
            {
                
                //カメラのヨーを設定
                camera.Heading = double.Parse(angle);
                MapView.Active.ZoomToAsync(camera, TimeSpan.Zero);
            }
            else if (mapView.ViewingMode == MapViewingMode.SceneGlobal || mapView.ViewingMode == MapViewingMode.SceneLocal)
            {
                camera.Heading = double.Parse(angle);

                //設定したポジションにズーム
                MapView.Active.ZoomToAsync(camera, TimeSpan.Zero);
            }
        }

        public void Move2DesignatedLocation()
        {
            var mapView = MapView.Active;
            if (mapView == null)
                return;

            QueuedTask.Run(() =>
            {
                SetCamera(MapModule.CameraSettings["X"], MapModule.CameraSettings["Y"], MapModule.CameraSettings["Scale"]);
            });
        }

        public void SetTownCombo()
        {
            if (MapModule.TownCombo == null)
                return;

            GetTown();
        }

        public void Move2Town(string townName)
        {
            var mapView = MapView.Active;
            if (mapView == null)
                return;

            var standalonTable = MapView.Active.Map.StandaloneTables.FirstOrDefault();
            if (standalonTable == null)
            {
                MessageBox.Show("テーブルがありません",
                                "警告",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Error,
                                System.Windows.MessageBoxResult.Yes);

                return;
            }
                

            QueryFilter queryFilter = new QueryFilter
            {
                WhereClause = "大字町丁目名 =" + "'" + townName + "'",
            };

            QueuedTask.Run(() =>
            {
                try
                {
                    var gdb = new FileGeodatabaseConnectionPath(new Uri(GdbPath));
                    using (Geodatabase geodatabase = new Geodatabase(gdb))
                    {
                        using (Table table = geodatabase.OpenDataset<Table>(standalonTable.Name))
                        {
                            using (var rowCursor = table.Search(queryFilter))
                            {
                                rowCursor.MoveNext();
                                using (var row = rowCursor.Current)
                                {
                                    var camera = mapView.Camera;
                                    Task<MapPoint> mapPoint = Utils.Latlon2XY(Convert.ToDouble(row["経度"]), Convert.ToDouble(row["緯度"]));

                                    SetCamera(mapPoint.Result.X, mapPoint.Result.Y, 1000);
                                }
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("町名検索に失敗しました",
                                    "エラー",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Error,
                                    System.Windows.MessageBoxResult.Yes);
                }

                
            });
        }

        public void GetTown()
        {
            var mapView = MapView.Active;
            if (mapView == null)
                return;

            var standalonTable = MapView.Active.Map.StandaloneTables.FirstOrDefault();
            if (standalonTable == null)
                return;

            List<string> townList = new List<string>();

            QueuedTask.Run(() =>
            {
                try
                {
                    var gdb = new FileGeodatabaseConnectionPath(new Uri(GdbPath));
                    using (Geodatabase geodatabase = new Geodatabase(gdb))
                    {
                        using (Table table = geodatabase.OpenDataset<Table>(standalonTable.Name))
                        {
                            using (var rowCursor = table.Search(null))
                            {
                                while (rowCursor.MoveNext())
                                {
                                    using (var row = rowCursor.Current)
                                    {
                                        townList.Add(row["大字町丁目名"].ToString());
                                    }
                                }

                                townList.Sort();

                                foreach (var town in townList)
                                {
                                    MapModule.TownCombo.AddItem(new ComboBoxItem(town));
                                }
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("町名の取得に失敗しました",
                                    "エラー",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Error,
                                    System.Windows.MessageBoxResult.Yes);
                }
            });           
        }

        public void DisplayElevation(Geometry geometry)
        {
            try
            {
                RemoveFromMapOverlay();

                var rasterLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<RasterLayer>().FirstOrDefault();
                if (rasterLayer == null)
                {
                    MessageBox.Show("標高データがマップにありません",
                                    "警告",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Error,
                                    System.Windows.MessageBoxResult.Yes);

                    return;
                }
                    

                using (Geodatabase gdb = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(GdbPath))))
                {
                    using (RasterDataset gdbRasterDataset = gdb.OpenDataset<RasterDataset>(rasterLayer.Name))
                    {
                        Raster raster = gdbRasterDataset.CreateFullRaster();
                        var rasterValues = raster.MapToPixel(geometry.Extent.XMax, geometry.Extent.YMax);

                        var pixelValue = raster.GetPixelValue(0, rasterValues.Item1, rasterValues.Item2);

                        var textGraphic = new CIMTextGraphic();

                        if (pixelValue == null)
                        {
                            textGraphic.Text = "No Data";
                        }
                        else
                        {
                            textGraphic.Text = pixelValue.ToString();
                        }

                        textGraphic.Shape = geometry;

                        CIMTextSymbol textsymbol = SymbolFactory.Instance.ConstructTextSymbol(20);
                        textsymbol.SetColor(MapConstants.RED);
                        textsymbol.VerticalAlignment = VerticalAlignment.Bottom;
                        textsymbol.HorizontalAlignment = HorizontalAlignment.Left;

                        CIMSymbolReference symbolRef = new CIMSymbolReference();
                        symbolRef.Symbol = textsymbol;
                        textGraphic.Symbol = symbolRef;

                        overlayObject = MapView.Active.AddOverlay(textGraphic);
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("標高の取得に失敗しました。",
                                "エラー",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Error,
                                System.Windows.MessageBoxResult.Yes);
            }
        }
    }
}
