﻿using ArcGIS.Desktop.Framework.Events;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESRIJ.ArcGISPro
{
    public class MapModule: BaseModule
    {
        public static MapManager MapManager;
        public static TownCombo TownCombo { get; set; }
        public static MapAngle MapAngle { get; set; }

        /// <summary>
        /// 初期化
        /// </summary>
        public void Initialize()
        {
            ActiveMapViewChangedEvent.Subscribe(OnActiveMapViewChanged);

            MapManager = new MapManager();
        }

        /// <summary>
        /// アクティブマップビュー変更時の処理
        /// </summary>
        protected override void OnActiveMapViewChanged(ActiveMapViewChangedEventArgs args)
        {
            MapManager.Reset();

            //MapManager.GetTown();
        }
    }
}
