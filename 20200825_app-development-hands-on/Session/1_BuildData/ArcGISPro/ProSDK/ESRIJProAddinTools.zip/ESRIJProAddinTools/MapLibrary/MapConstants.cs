﻿using ArcGIS.Core.CIM;
using ArcGIS.Desktop.Mapping;
namespace ESRIJ.ArcGISPro
{
    /// <summary>
    /// 固定値
    /// </summary>
    public static class MapConstants
    {
        public static string DAML_MAPTOOL_ZUKAKU = "EJAddinTools_ZukakuSelecter";
        public static string DAML_MAPTOOL_ELEVATION = "EJAddinTools_ElevationIdentifier";
        public static string DAML_CLEAR_SELECTION = "esri_mapping_clearSelectionButton";
        public static string DAML_EXPLORE_TOOL = "esri_mapping_exploreTool";
        public static CIMColor RED = ColorFactory.Instance.RedRGB;
        public static CIMColor BLUE = ColorFactory.Instance.BlueRGB;
        public static string OfflineStateID = "EJAddinTools_State";
        public static string ZukakuNo = "図郭番号";
    }
}
