﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESRIJ.ArcGISPro
{
    /// <summary>
    /// ユーティリティクラス
    /// </summary>
    public static class Utils
    {
        /// <summary>
        /// 文字数カウント
        /// </summary>
        public static int NumberOfCharacters(string str)
        {
            if (str != null)
            {
                return str.Length;
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// 文字列 -> 数値変換
        /// 空文字は０
        /// </summary>
        public static bool TryParse<T>(string str, out T outval)
        {
            outval = default(T);    //0
            if (string.IsNullOrEmpty(str)) return true;

            try
            {
                var conv = TypeDescriptor.GetConverter(typeof(T));
                if (conv == null) return false;
                outval = (T)conv.ConvertFromString(str);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 緯度経度→座標変換
        /// </summary>
        public static Task<MapPoint> Latlon2XY(double longitude, double latitude)
        {
            return QueuedTask.Run(() => {
                var activeMapView = MapView.Active;
                MapPoint zoomToPnt = MapPointBuilder.CreateMapPoint(longitude, latitude, SpatialReferences.WGS84);
                var projectedXY = GeometryEngine.Instance.Project(zoomToPnt, activeMapView.Map.SpatialReference) as MapPoint;
                return projectedXY;
            });
        }

    }
}
