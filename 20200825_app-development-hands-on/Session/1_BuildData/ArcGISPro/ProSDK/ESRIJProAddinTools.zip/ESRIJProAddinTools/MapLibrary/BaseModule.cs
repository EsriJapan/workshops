﻿using ArcGIS.Desktop.Framework.Events;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESRIJ.ArcGISPro
{
    public abstract class BaseModule
    {
        public static Dictionary<string, string> PathSettings;
        public static Dictionary<string, double> CameraSettings;

        protected abstract void OnActiveMapViewChanged(ActiveMapViewChangedEventArgs args);
    }
}
