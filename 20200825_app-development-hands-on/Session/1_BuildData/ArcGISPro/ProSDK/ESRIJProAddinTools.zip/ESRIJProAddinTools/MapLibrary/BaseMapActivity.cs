﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ESRIJ.ArcGISPro
{
    /// <summary>
    /// マップ関連基底クラス
    /// </summary>
    public class BaseMapActivity
    {
        public static List<System.IDisposable> overlayObjects = new List<System.IDisposable>();
        public static IDisposable overlayObject = null;

        /// <summary>
        /// DAMLID指定で任意の処理を起動
        /// </summary>
        public void ActivateTool(string damlId)
        {
            var cmd = FrameworkApplication.GetPlugInWrapper(damlId) as ICommand;
            if (cmd.CanExecute(null))
                cmd.Execute(null);
        }

        /// <summary>
        /// 強調削除（複数）
        /// </summary>
        public void RemoveFromMapOverlays()
        {
            if (overlayObjects != null)
            {
                foreach (var o in overlayObjects)
                {
                    o.Dispose();
                }
            }
        }

        /// <summary>
        /// 強調削除
        /// </summary>
        public void RemoveFromMapOverlay()
        {
            if (overlayObject != null)
            {
                overlayObject.Dispose();
                overlayObject = null;
            }
        }

        /// <summary>
        /// クリア
        /// </summary>
        public virtual void Reset()
        {
            // 強調処理を解除
            RemoveFromMapOverlays();
            RemoveFromMapOverlay();

            // 選択しているアイテムを解除
            ActivateTool(MapConstants.DAML_CLEAR_SELECTION);

            // 選択ツールに切り替える
            FrameworkApplication.SetCurrentToolAsync(MapConstants.DAML_EXPLORE_TOOL);
        }

        /// <summary>
        /// ポリゴン強調処理
        /// </summary>
        public void CreatePolygonGraphic(Polygon polygon, CIMColor color, double width)
        {
            try
            {
                // グラフィック作成
                var polygonGraphic = new CIMPolygonGraphic();
                polygonGraphic.Polygon = polygon;// geometry as Polygon;

                // シンボル作成
                CIMStroke outline = SymbolFactory.Instance.ConstructStroke(color,
                                                                           width,
                                                                           SimpleLineStyle.Solid);

                CIMPolygonSymbol polygonSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(color,
                                                                                               SimpleFillStyle.Null,
                                                                                               outline);
                polygonGraphic.Symbol = polygonSymbol.MakeSymbolReference();

                QueuedTask.Run(() =>
                {
                    // グラフィックをマップビューに追加
                    overlayObjects.Add(MapView.Active.AddOverlay(polygonGraphic));

                });

            }
            catch (Exception)
            {
                throw;
            }

        }


        /// <summary>
        /// ビューポイント変更
        /// </summary>
        public void SetCamera(double x, double y, double scale)
        {
            var camera = new Camera();
            camera.X = x;
            camera.Y = y;
            camera.Scale = scale;

            MapView.Active.ZoomTo(camera, TimeSpan.Zero);
        }

    }
}
