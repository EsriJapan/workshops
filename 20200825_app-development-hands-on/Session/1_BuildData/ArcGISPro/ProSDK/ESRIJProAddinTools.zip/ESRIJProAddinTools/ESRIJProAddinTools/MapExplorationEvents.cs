﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ESRIJ.ArcGISPro
{
    internal class Move2DesignatedLocationButton : Button
    {
        protected override void OnClick()
        {
            MapModule.MapManager.Move2DesignatedLocation();
        }
    }

    internal class RotateMapButton : Button
    {
        protected override void OnClick()
        {
            MapModule.MapManager.RotateMap();
        }
    }

    internal class ReverseMapButton : Button
    {
        protected override void OnClick()
        {
            MapModule.MapAngle.Text = "0";
            MapModule.MapManager.RotateMap();
        }
    }

    internal class ElevationIdentifierButton : Button
    {
        protected override void OnClick()
        {
            MapModule.MapManager.ActivateTool(MapConstants.DAML_MAPTOOL_ELEVATION);
        }
    }

    internal class ElevationClearButton : Button
    {
        protected override void OnClick()
        {
            MapModule.MapManager.Reset();
        }
    }

    internal class TownComboBox : TownCombo
    {
        public TownComboBox()
        {
            if (MapModule.MapManager != null)
            {
                MapModule.TownCombo = this;
                MapModule.MapManager.SetTownCombo();
            }
        }
    }
}
