﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using System.Windows.Input;

namespace ESRIJ.ArcGISPro
{
    internal class ZukakuComboBox : ZukakuCombo
    {
        public ZukakuComboBox()
        {
            if (OfflineModule.OfflineManager != null)
            {
                OfflineModule.ZukakuCombo = this;
                OfflineModule.OfflineManager.SetZukakuCombo();
            }
            
        }       
    }

    internal class ZukakuSelectButton : Button
    {
        protected override void OnClick()
        {
            OfflineModule.OfflineManager.ActivateTool(MapConstants.DAML_CLEAR_SELECTION);
            OfflineModule.OfflineManager.ActivateTool(MapConstants.DAML_MAPTOOL_ZUKAKU);
        }
    }

    internal class ZukakuClearButton : Button
    {
        protected override void OnClick()
        {
            OfflineModule.OfflineManager.Reset();
        }
    }

    internal class CreateOfflineDataButton : Button
    {
        protected override void OnClick()
        {
            OfflineModule.OfflineManager.ShowOfflineDialog();
        }
    }

    internal class OfflineDataComboBox : OfflineDataCombo
    {
        public OfflineDataComboBox()
        {
            // コンボボックスの中身は図郭コンボボックスを選択してからセット
            OfflineModule.OfflineDataCombo = this;
        }
    }

    internal class DeleteOfflineDataButton : Button
    {
        protected override void OnClick()
        {
            OfflineModule.OfflineManager.DeleteOfflineData();
        }
    }

    internal class GetOfflineAreaNameButton : Button
    {
        protected override void OnClick()
        {
            OfflineModule.OfflineDataCombo.ClearCombo();
            OfflineModule.OfflineManager.GetCreatedOfflineData();
        }
    }
}
