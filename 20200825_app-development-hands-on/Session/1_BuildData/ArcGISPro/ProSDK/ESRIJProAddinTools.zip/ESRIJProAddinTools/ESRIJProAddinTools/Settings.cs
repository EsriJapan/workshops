﻿using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Dialogs;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace ESRIJ.ArcGISPro
{
    /// <summary>
    /// 初期設定
    /// </summary>
    public static class Settings
    {
        private static Dictionary<string, string> pathDic;
        private static Dictionary<string, double> cameraDic;

        /// <summary>
        /// 初期化
        /// </summary>
        public static bool Initialize(string configFilePath)
        {
            try
            {
                var exeFileMap = new ExeConfigurationFileMap { ExeConfigFilename = configFilePath };
                var config = System.Configuration.ConfigurationManager.OpenMappedExeConfiguration(exeFileMap, ConfigurationUserLevel.None);

                pathDic = new Dictionary<string, string>()
                {
                    { "GDB", config.AppSettings.Settings["GDB"].Value },
                    { "PythonPath", config.AppSettings.Settings["PythonPath"].Value },
                    { "PythonScriptPath", config.AppSettings.Settings["PythonScriptPath"].Value }
                };

                cameraDic = new Dictionary<string, double>()
                {
                    { "X", Double.Parse(config.AppSettings.Settings["X"].Value) },
                    { "Y", Double.Parse(config.AppSettings.Settings["Y"].Value) },
                    { "Scale", Double.Parse(config.AppSettings.Settings["Scale"].Value) }
                };

                // 参加者の環境チェック用に入れとく
                if (!Directory.Exists(pathDic["GDB"]))
                {
                    MessageBox.Show("configに設定したGDBが存在しません。",
                                    "エラー",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Error,
                                    System.Windows.MessageBoxResult.Yes);

                    return false;
                }

                BaseModule.PathSettings = pathDic;
                BaseModule.CameraSettings = cameraDic;

                return true;
            }
            catch (System.NullReferenceException)
            {
                MessageBox.Show("設定ファイルの値が不正です。",
                                "エラー",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Error,
                                System.Windows.MessageBoxResult.Yes);

                return false;
            }
            catch (Exception)
            {
                MessageBox.Show("設定ファイルの読込に失敗しました。",
                                "エラー",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Error,
                                System.Windows.MessageBoxResult.Yes);

                return false;
            }
        }
    }
}
