﻿using System.ComponentModel;
using System.Windows.Input;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Dialogs;

namespace ESRIJ.ArcGISPro
{
    public class ZukakuDialogViewModel: BaseBind
    {
        #region プロパティ
        
        private ZukakuDialog _zukakuDialog = null;
        private static bool _isOpen = false;

        private string _offlineAreaName { get; set; }
        public string OfflineAreaName
        {
            get { return _offlineAreaName; }
            set
            {
                _offlineAreaName = value;
                OnPropertyChanged(nameof(OfflineAreaName));
            }
        }
        #endregion

        #region 起動時
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public ZukakuDialogViewModel()
        {
            _offlineDataCmd = new RelayCommand(() => OfflineData(), () => true);
            _closeCmd = new RelayCommand(() => CloseOfflineDisplay(), () => true);
        }
        #endregion

        

        #region コマンド
        /// <summary>
        /// オフラインデータ作成処理
        /// </summary>
        private ICommand _offlineDataCmd;
        public ICommand OfflineDataCmd => _offlineDataCmd;
        private void OfflineData()
        {
            var result = MessageBox.Show("オフラインデータを作成しますか？", "確認",
                                         System.Windows.MessageBoxButton.YesNo, 
                                         System.Windows.MessageBoxImage.Information,
                                         System.Windows.MessageBoxResult.Yes);
            
            if (result == System.Windows.MessageBoxResult.Yes)
            {
                _zukakuDialog.Hide();
                OfflineModule.OfflineManager.CreateOfflineData(OfflineAreaName);
                CloseOfflineDisplay();
            }
        }

        /// <summary>
        /// オフラインエリア名指定画面起動
        /// </summary>
        public void OpenZukakuDialog()
        {
            if (_isOpen)
                return;

            _zukakuDialog = new ZukakuDialog();
            _isOpen = true;

            _zukakuDialog.DataContext = this;
            _zukakuDialog.ShowCloseButton = false;
            _zukakuDialog.ShowMinButton = false;
            _zukakuDialog.Owner = FrameworkApplication.Current.MainWindow;
            _zukakuDialog.Closed += (o, e) => { _zukakuDialog = null; };

            // 最大化はさせない
            _zukakuDialog.ShowMaxRestoreButton = false;

            // モードレス
            _zukakuDialog.Show();
        }


        /// <summary>
        /// 画面クローズイベント
        /// </summary>
        private ICommand _closeCmd;
        public ICommand CloseCmd => _closeCmd;
        public void CloseOfflineDisplay()
        {
            if (_isOpen == true)
            {
                _zukakuDialog.Close();
                _zukakuDialog = null;
                _isOpen = false;
                OfflineAreaName = null;
            }
            
        }
        #endregion

        #region プロパティ変更通知
        private void RaisePropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e.PropertyName);
        }
        #endregion
    }
}
