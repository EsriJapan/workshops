﻿using System.Threading.Tasks;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ESRIJ.ArcGISPro
{
    /// <summary>
    /// 図郭選択用マップツール
    /// </summary>
    internal class ZukakuSelecter : MapTool
    {
        public ZukakuSelecter()
        {
            IsSketchTool = true;
            SketchType = SketchGeometryType.Point;
            SketchOutputMode = SketchOutputMode.Map;
        }

        protected override Task OnToolActivateAsync(bool active)
        {
            return base.OnToolActivateAsync(active);
        }

        protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
        {
            return QueuedTask.Run(() =>
            {
                MapView.Active.SelectFeatures(geometry);
                return true;
            });
        }
    }
}
