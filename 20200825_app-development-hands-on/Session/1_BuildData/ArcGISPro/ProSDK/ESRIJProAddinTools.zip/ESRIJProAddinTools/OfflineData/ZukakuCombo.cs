﻿using System.Collections.Generic;
using System.Linq;
using ArcGIS.Core.CIM;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ESRIJ.ArcGISPro
{
    /// <summary>
    /// 図郭コンボボックスクラス
    /// </summary>
    public class ZukakuCombo : ComboBox
    {
        public void ClearCombo()
        {
            this.Clear();
        }

        public void AddItem(ComboBoxItem item)
        {
            Add(item);
        }

        protected override void OnSelectionChange(ComboBoxItem item)
        {
            if (item == null)
                return;

            if (string.IsNullOrEmpty(item.Text))
                return;

            try
            {
                OfflineModule.OfflineManager.DisplayZukakuLayer();
                OfflineModule.OfflineDataCombo.ClearCombo();
                OfflineModule.OfflineManager.Reset();
                //OfflineModule.OfflineManager.SetOfflineDataCombo();
            }
            catch
            {
                MessageBox.Show("図郭の取得に失敗しました。",
                                "エラー",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Error,
                                System.Windows.MessageBoxResult.Yes);
            }
        }
    }
}
