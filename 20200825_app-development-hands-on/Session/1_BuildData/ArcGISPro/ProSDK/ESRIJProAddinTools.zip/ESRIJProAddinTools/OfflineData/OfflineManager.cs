﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using System.Diagnostics;
using ArcGIS.Desktop.Framework.Contracts;

namespace ESRIJ.ArcGISPro
{
    /// <summary>
    /// オフラインデータ作成/削除メイン処理
    /// </summary>
    public class OfflineManager: BaseMapActivity
    {        
        private List<string> zukakuList = new List<string>();

        public Dictionary<string, List<string>> zukakuDeleteDic = new Dictionary<string, List<string>>();
        private IEnumerable<IGrouping<string, FeatureLayer>> zukakuLayers { get; set; }

        /// <summary>
        /// 選択図郭クリア
        /// </summary>
        private void ClearZukaku()
        {
            zukakuList.Clear();
            //zukakuDeleteDic.Clear();
        }

        /// <summary>
        /// オフライン用クリア処理
        /// </summary>
        public override void Reset()
        {
            base.Reset();

            ClearZukaku();

            // オンラインデータ作成画面を閉じる
            OfflineModule.ZukakuDialogViewModel.CloseOfflineDisplay();
        }

        /// <summary>
        /// 図郭コンボボックスのセット
        /// </summary>
        public void SetZukakuCombo()
        {
            var mapView = MapView.Active;
            if (mapView == null) return;

            OfflineModule.ZukakuCombo.ClearCombo();

            //
            // 拡張：レイヤー管理テーブルを作って図郭かどうか判断したい
            //

            // ポリゴンを対象とする
            zukakuLayers = mapView.Map.GetLayersAsFlattenedList()
                                                     .OfType<FeatureLayer>()
                                                     .Where(f => f.ShapeType == esriGeometryType.esriGeometryPolygon)
                                                              //&& f.Name.Contains("図郭") == true)
                                                     .GroupBy(g => g.Name);

            foreach (var zukakuLayer in zukakuLayers) OfflineModule.ZukakuCombo.AddItem(new ComboBoxItem(zukakuLayer.Key));

        }

        /// <summary>
        /// 図郭レイヤー表示/非表示処理
        /// </summary>
        public void DisplayZukakuLayer()
        {
            QueuedTask.Run(() =>
            {
                foreach (var zukakuLayer in zukakuLayers)
                {
                    if (zukakuLayer.Key == OfflineModule.ZukakuCombo.SelectedItem.ToString())
                    {
                        zukakuLayer.FirstOrDefault().SetVisibility(true);
                    }
                    else
                    {
                        zukakuLayer.FirstOrDefault().SetVisibility(false);
                    }
                }
            });
        }

        /// <summary>
        /// オフラインエリア名コンボボックスセット
        /// </summary>
        //public void SetOfflineDataCombo()
        //{
        //    var mapView = MapView.Active;
        //    if (mapView == null) return;

        //    OfflineModule.OfflineDataCombo.ClearCombo();

        //    QueuedTask.Run(() =>
        //    {
        //        GetCreatedOfflineData();
        //    });
            
        //}

        
        /// <summary>
        /// フィーチャ選択時の処理
        /// </summary>
        public void SelectZukaku()
        {
            var mapView = MapView.Active;
            if (mapView == null) 
                return;

            QueuedTask.Run(() =>
            {
                try
                {
                    var selection = mapView.Map.GetSelection();

                    if (selection.Count != 1)
                    {
                        ActivateTool(MapConstants.DAML_CLEAR_SELECTION);
                        return;
                    }

                    var featureLayer = selection.FirstOrDefault().Key as FeatureLayer;
                    var geometryType = featureLayer.GetFeatureClass().GetDefinition().GetShapeType().ToString();

                    if (geometryType == "Polygon")
                    {
                        // 図郭コンボボックスで選択されているレイヤーのフィーチャを選択した時のみ処理する
                        if (featureLayer.Name == OfflineModule.ZukakuCombo.Text)
                        {
                            QueryFilter queryFilter = new QueryFilter
                            {
                                WhereClause = "OID =" + featureLayer.GetSelection().GetObjectIDs().First(),
                            };

                            // 選択したポリゴンの範囲内にあるフィーチャを検索
                            using (var rowCursor = featureLayer.Search(queryFilter))
                            {
                                rowCursor.MoveNext();

                                using (var row = rowCursor.Current)
                                {
                                    var oid = row["図郭番号"].ToString();
                                    if (zukakuList.Contains(oid))
                                    {
                                        return;
                                    }
                                    else
                                    {
                                        Feature feature = row as Feature;
                                        Geometry geo = feature.GetShape();
                                        Polygon polygon = geo as Polygon;
                                        //zukakuPolygon = geo;

                                        zukakuList.Add(oid);
                                        CreatePolygonGraphic(polygon, MapConstants.RED, 5.0);
                                    }
                                }
                            }
                        }
                        else
                        {
                            ActivateTool(MapConstants.DAML_CLEAR_SELECTION);
                        }
                    }
                    else
                    {
                        ActivateTool(MapConstants.DAML_CLEAR_SELECTION);
                    }
                }
                catch (Exception)
                {
                    ClearZukaku();

                    RemoveFromMapOverlays();

                    MessageBox.Show("図郭の選択に失敗しました。",
                                    "エラー",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Error,
                                    System.Windows.MessageBoxResult.Yes);
                }
            });

            
        }
       
        /// <summary>
        /// 図郭番号取得処理
        /// </summary>
        //private string GetZukakuData()
        //{
        //    string zukakuNumbers = "";

        //    try
        //    {
        //        QueuedTask.Run(() =>
        //        {
        //            using (Geodatabase gdb = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(OfflineModule.PathSettings["GDB"]))))
        //            {
        //                using (FeatureClass featureClass = gdb.OpenDataset<FeatureClass>(OfflineModule.ZukakuCombo.Text))
        //                {
        //                    using (var rowCursor = featureClass.Search(null))
        //                    {
        //                        while (rowCursor.MoveNext())
        //                        {
        //                            using (var row = rowCursor.Current)
        //                            {
        //                                if (zukakuNumbers == "")
        //                                {
        //                                    zukakuNumbers = row[MapConstants.ZukakuNo].ToString();
        //                                }
        //                                else
        //                                {
        //                                    zukakuNumbers = zukakuNumbers + "," + row[MapConstants.ZukakuNo].ToString();
        //                                }

        //                            }

        //                        }
        //                    }
        //                }
        //            }
        //        });

        //        return zukakuNumbers;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
            
        //}

        /// <summary>
        /// 図郭強調処理
        /// </summary>
        public void HighlightZukaku()
        {
            QueuedTask.Run(() =>
            {
                try
                {
                    // 属性検索用のWhere句作成
                    string query = "";
                    List<string> zukakuNoList = OfflineModule.OfflineManager.zukakuDeleteDic[OfflineModule.OfflineDataCombo.Text];
                    
                    if (zukakuNoList.Count == 1)
                    {
                        query = MapConstants.ZukakuNo + "=" + "'" + zukakuNoList[0] + "'";
                    }
                    else if (zukakuNoList.Count > 1)
                    {
                        string zukaku = "";
                        foreach (var zukakuNo in zukakuNoList)
                        {
                            zukaku = zukaku + "'";
                            zukaku = zukaku + zukakuNo + "',";
                        }
                        zukaku = zukaku.TrimEnd(',');

                        query = MapConstants.ZukakuNo + " in " + "(" + zukaku + ")";
                    }
                    else
                    {
                        return;
                    }

                    QueryFilter queryFilter = new QueryFilter
                    {
                        WhereClause = query,
                    };

                    // 対象の図郭を強調
                    using (Geodatabase gdb = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(OfflineModule.PathSettings["GDB"]))))
                    {
                        using (FeatureClass featureClass = gdb.OpenDataset<FeatureClass>(OfflineModule.ZukakuCombo.Text))
                        {
                            using (var rowCursor = featureClass.Search(queryFilter))
                            {
                                while (rowCursor.MoveNext())
                                {
                                    using (var row = rowCursor.Current)
                                    {
                                        Feature feature = row as Feature;
                                        Geometry geo = feature.GetShape();
                                        Polygon polygon = geo as Polygon;

                                        CreatePolygonGraphic(polygon, MapConstants.BLUE, 5.0);
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            });
        }

        /// <summary>
        /// Python呼び出し処理
        /// </summary>
        public string ExecutePython(List<string> arguments)
        {
            try
            {
                var process = new Process()
                {
                    StartInfo = new ProcessStartInfo(OfflineModule.PathSettings["PythonPath"])
                    {
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        Arguments = string.Join(" ", arguments),
                    },
                };

                process.Start();

                //python側でprintした内容を取得
                var sr = process.StandardOutput;
                var result = sr.ReadLine();

                process.WaitForExit();
                process.Close();

                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// 作成済みオフラインエリア取得(オフラインエリア名コンボボックス選択時に起動)
        /// </summary>
        //public void GetCreatedOfflineAreas()
        //{
        //    // Pythonスクリプトに渡す引数
        //    var arguments = new List<string>
        //    {
        //        OfflineModule.PathSettings["PythonScriptPath"],
        //        OfflineModule.OfflineDataCombo.Text // オフラインエリア名
        //    };

        //    try
        //    {
        //        QueuedTask.Run(() =>
        //        {
        //            using (var progress = new ProgressDialog("オフラインエリア範囲取得中"))
        //            {
        //                progress.Show();

        //                string results = ExecutePython(arguments);
        //                if (results != null)
        //                {
        //                    if (results.Contains(","))
        //                    {
        //                        string[] resultList = results.Split(',');
        //                        foreach (var result in resultList)
        //                        {
        //                            HighlightZukaku(result);
        //                        }
        //                    }
        //                    else if (!results.Contains(",") && (results != "" || results != null))
        //                    {
        //                        HighlightZukaku(results);
        //                    }
        //                }
                        

        //            }
        //        });
                
        //    }
        //    catch (Exception)
        //    {
        //        MessageBox.Show("作成済みオフラインエリアの取得に失敗しました。",
        //                        "エラー",
        //                        System.Windows.MessageBoxButton.OK,
        //                        System.Windows.MessageBoxImage.Error,
        //                        System.Windows.MessageBoxResult.Yes);
        //    }
        //}


        /// <summary>
        /// 作成済みオフラインデータ名取得処理
        /// </summary>
        public void GetCreatedOfflineData()
        {
            if (OfflineModule.ZukakuCombo.Text == "" || OfflineModule.ZukakuCombo.Text == null)
            {
                MessageBox.Show("対象の図郭レイヤーを選択してください。",
                                "警告",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Warning,
                                System.Windows.MessageBoxResult.Yes);

                return;
            }

            // Pythonスクリプトに渡す引数
            var arguments = new List<string>
            {
                OfflineModule.PathSettings["PythonScriptPath"],
                "2",
                OfflineModule.ZukakuCombo.Text // 図郭フィーチャークラス名
            };

            
            QueuedTask.Run(() =>
            {
                try
                {
                    using (var progress = new ProgressDialog("オフラインエリア取得中"))
                    {
                        progress.Show();

                        string results = ExecutePython(arguments);
                        if (results != null)
                        {
                            // オフライン名1,図郭番号1,図郭番号2,,オフライン名2,図郭番号3,図郭番号4　のような文字列がPythonから渡されるのでそれをディクショナリに格納
                            if (results.Contains(","))
                            {
                                zukakuDeleteDic.Clear();

                                int i = 0;
                                string areaName = "";
                                List<string> zukakuNames = new List<string>();

                                string[] resultList = results.Split(',');

                                if (resultList.Count() > 0)
                                {
                                    foreach (var result in resultList)
                                    {
                                        // 
                                        if (i == 0)
                                        {
                                            areaName = result;
                                            OfflineModule.OfflineDataCombo.AddItem(new ComboBoxItem(result));
                                            i++;

                                            continue;
                                        }

                                        if (result != "")
                                        {
                                            zukakuNames.Add(result);
                                        }
                                        else
                                        {
                                            zukakuDeleteDic.Add(areaName, zukakuNames);

                                            i = 0;
                                            areaName = "";
                                            zukakuNames = new List<string>();
                                        }
                                    }

                                    zukakuDeleteDic.Add(areaName, zukakuNames);
                                }
                            }
                        }
                    };                  
                
                }
                catch (Exception)
                {
                    MessageBox.Show("オフラインエリアの取得に失敗しました。",
                                    "エラー",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Error,
                                    System.Windows.MessageBoxResult.Yes);
                }
            });
        }

        /// <summary>
        /// オフラインデータ作成処理
        /// </summary>
        public void CreateOfflineData(string offlineAreaName)
        {
            // Pythonスクリプトに渡す引数
            var arguments = new List<string>
            {
                OfflineModule.PathSettings["PythonScriptPath"],
                "1",
                OfflineModule.ZukakuCombo.Text,       // 図郭フィーチャークラス名
                String.Join(",", zukakuList),              // 各図郭の図郭番号をカンマ区切りにした文字列
                offlineAreaName                       // 入力するオフラインエリア名                
            };

            QueuedTask.Run(() =>
            {
                try
                {

                    using (var progress = new ProgressDialog("オフラインデータ作成中です"))
                    {
                        progress.Show();

                        var result = ExecutePython(arguments);

                        if (result == "-1")
                        {
                            throw new Exception();
                        }
                        else if (result == "-2")
                        {
                            MessageBox.Show("同名のオフラインエリアが存在します",
                                            "警告",
                                            System.Windows.MessageBoxButton.OK,
                                            System.Windows.MessageBoxImage.Warning,
                                            System.Windows.MessageBoxResult.Yes);

                            return;
                        }
                    }

                    // コンボボックスにアイテムを追加
                    //OfflineModule.OfflineDataCombo.AddItem(new ComboBoxItem(offlineAreaName));

                    Reset();

                    MessageBox.Show("オフラインデータの作成が完了しました。",
                                    "情報",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Information,
                                    System.Windows.MessageBoxResult.Yes);

                }
                catch (Exception)
                {
                    MessageBox.Show("オフラインデータの作成に失敗しました。",
                                    "エラー",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Error,
                                    System.Windows.MessageBoxResult.Yes);
                }
            });
        }


        /// <summary>
        /// オフラインデータ作成画面起動
        /// </summary>
        public void ShowOfflineDialog()
        {
            if (zukakuList.Count == 0)
            {
                MessageBox.Show("図郭を選択してください。",
                                "警告",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Warning,
                                System.Windows.MessageBoxResult.Yes);
                return;
            }

            OfflineModule.ZukakuDialogViewModel.OpenZukakuDialog();
        }

        /// <summary>
        /// オフラインデータ削除処理
        /// </summary>
        public void DeleteOfflineData()
        {
            var areaName = OfflineModule.OfflineDataCombo.Text;

            if (areaName == "" || areaName == null)
            {
                MessageBox.Show("削除するオフラインエリアを選択してください",
                                "警告",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Warning,
                                System.Windows.MessageBoxResult.Yes);

                return;
            }

            var confirmation = MessageBox.Show("オフラインデータを削除しますか？", "確認",
                                               System.Windows.MessageBoxButton.YesNo,
                                               System.Windows.MessageBoxImage.Information,
                                               System.Windows.MessageBoxResult.Yes);

            if (confirmation == System.Windows.MessageBoxResult.No)
                return;

            // Pythonスクリプトに渡す引数
            var arguments = new List<string>
            {
                OfflineModule.PathSettings["PythonScriptPath"],
                "3",
                OfflineModule.ZukakuCombo.Text, // 図郭フィーチャークラス名
                areaName                        // 選択しているオフラインエリア名               
            };

            QueuedTask.Run(() =>
            {
                try
                {
                    using (var progress = new ProgressDialog("オフラインデータ削除中です"))
                    {
                        progress.Show();

                        var result = ExecutePython(arguments);

                        if (result == "-1")
                        {
                            throw new Exception();
                        }
                        else if (result == "-2")
                        {
                            MessageBox.Show("指定したオフラインデータが存在しません",
                                            "警告",
                                            System.Windows.MessageBoxButton.OK,
                                            System.Windows.MessageBoxImage.Warning,
                                            System.Windows.MessageBoxResult.Yes);

                            return;
                        }
                    }

                    // コンボボックスからアイテムを削除
                    OfflineModule.OfflineDataCombo.RemoveItem(OfflineModule.OfflineDataCombo.SelectedIndex);

                    Reset();

                    MessageBox.Show("オフラインデータの削除が完了しました。",
                                    "情報",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Information,
                                    System.Windows.MessageBoxResult.Yes);
                }
                catch (Exception)
                {
                    MessageBox.Show("オフラインデータの削除に失敗しました。",
                                    "エラー",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Error,
                                    System.Windows.MessageBoxResult.Yes);
                }

                
            });

            
        }
    }
}
