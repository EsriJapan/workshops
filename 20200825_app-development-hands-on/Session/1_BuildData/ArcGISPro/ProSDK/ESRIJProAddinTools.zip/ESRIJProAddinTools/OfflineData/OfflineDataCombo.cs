﻿using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Mapping;
using System.Collections.Generic;

namespace ESRIJ.ArcGISPro
{
    /// <summary>
    /// オフラインデータ名コンボボックスクラス
    /// </summary>
    public class OfflineDataCombo : ComboBox
    {
        public void ClearCombo()
        {
            this.Clear();
        }

        public void AddItem(ComboBoxItem item)
        {
            Add(item);
        }

        public void RemoveItem(int index)
        {
            RemoveAt(index);
        }

        protected override void OnSelectionChange(ComboBoxItem item)
        {
            if (item == null)
                return;

            if (string.IsNullOrEmpty(item.Text))
                return;

            try
            {
                OfflineModule.OfflineManager.Reset();

                OfflineModule.OfflineManager.HighlightZukaku();

                
                //OfflineModule.OfflineManager.GetCreatedOfflineAreas();
            }
            catch
            {
                MessageBox.Show("オフラインエリアの取得に失敗しました。",
                                "エラー",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Error,
                                System.Windows.MessageBoxResult.Yes);
            }
        }
    }
}
