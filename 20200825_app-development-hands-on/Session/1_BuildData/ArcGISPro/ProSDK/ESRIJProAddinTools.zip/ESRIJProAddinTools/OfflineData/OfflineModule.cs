﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Dialogs;
using System;
using System.IO;
using System.Linq;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Mapping.Events;
using ArcGIS.Desktop.Framework.Events;
using ArcGIS.Core.Events;
using System.Collections.Generic;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Core.CIM;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;

namespace ESRIJ.ArcGISPro
{
    public class OfflineModule: BaseModule
    {
        public static OfflineManager OfflineManager;
        public static ZukakuDialogViewModel ZukakuDialogViewModel;
        public static ZukakuCombo ZukakuCombo { get; set; }
        public static OfflineDataCombo OfflineDataCombo { get; set; }
        private SubscriptionToken _mapSelectionChangedEvent = null;

        /// <summary>
        /// 初期化
        public void Initialize()
        {
            try
            {
                FrameworkApplication.State.Activate(MapConstants.OfflineStateID);

                ActiveMapViewChangedEvent.Subscribe(OnActiveMapViewChanged);
                LayersAddedEvent.Subscribe(OnLayerChanged);
                LayersRemovedEvent.Subscribe(OnLayerChanged);
                ActiveToolChangedEvent.Subscribe(OnActiveToolChanged);

                OfflineManager = new OfflineManager();
                ZukakuDialogViewModel = new ZukakuDialogViewModel();
            }
            catch (Exception)
            {
                FrameworkApplication.State.Deactivate(MapConstants.OfflineStateID);

                MessageBox.Show("オフライン機能の初期化に失敗しました。",
                                "エラー",
                                System.Windows.MessageBoxButton.OK,
                                System.Windows.MessageBoxImage.Error,
                                System.Windows.MessageBoxResult.Yes);
            }
        }

        /// <summary>
        /// コンテンツウインドウでのレイヤー追加/削除時の処理
        /// </summary>
        private void OnLayerChanged(LayerEventsArgs args)
        {
            if (ZukakuCombo == null)
                return;

            OfflineManager.SetZukakuCombo();

            OfflineDataCombo.ClearCombo();
        }

        /// <summary>
        /// アクティブマップビュー変更時の処理
        /// </summary>
        protected override void OnActiveMapViewChanged(ActiveMapViewChangedEventArgs args)
        {
            OfflineManager.Reset();
        }

        /// <summary>
        /// フィーチャ選択時の処理
        /// </summary>
        private void OnMapSelectionChanged(MapSelectionChangedEventArgs args)
        {
            OfflineManager.SelectZukaku();
        }

        /// <summary>
        /// アクティブなツールが変更された際の処理
        /// </summary>
        private void OnActiveToolChanged(ToolEventArgs args)
        {
            string newTool = args.CurrentID;

            if (_mapSelectionChangedEvent == null)
            {
                if (newTool == MapConstants.DAML_MAPTOOL_ZUKAKU)
                {
                    _mapSelectionChangedEvent = MapSelectionChangedEvent.Subscribe(OnMapSelectionChanged);
                }
            }
            else
            {
                if (newTool != MapConstants.DAML_MAPTOOL_ZUKAKU)
                {
                    MapSelectionChangedEvent.Unsubscribe(_mapSelectionChangedEvent);
                    _mapSelectionChangedEvent = null;
                }
            }
        }
    }
}
