queryTaskSet = () => {
  
    const selectWaterSupplyMapTable = document.getElementById("table-water-supply-map");
    
    // Step5 属性検索ウィジェット（テーブルを選択）
    selectWaterSupplyMapTable.addEventListener("change", (event) => {
      // Todo: Step5 選択したテーブル情報を setFieldsWaterSupplyMap() に指定
      const layerId = event.target.value;
      const layers = map.allLayers.map((layer) => {
        if (layer.layerId == layerId) {
          setFieldsWaterSupplyMap(layer);
        }
      })
    });

    // Step5 属性検索ウィジェット（項目名の設定）
    setFieldsWaterSupplyMap = (layer) => {
      const fieldsWaterSupplyMap = document.getElementById("fields-water-supply-map");
      fieldsWaterSupplyMap.innerHTML = "";
      
      // Todo: Step5 DOM の fieldsWaterSupplyMap に対して属性項目を設定
      // 各レイヤーからフィールド名を取得
      for (let field of layer.fields) {  
        const fieldName = field.name;
        // ドメイン
        if (field.domain) {
          if (field.domain.type === "coded-value") {
            let option = "<option value=''></option>";
            for (let codedValue of field.domain.codedValues) {
              option += "<option value="+ codedValue.code + ">"+ codedValue.name +"</option>";
            }
            fieldsWaterSupplyMap.innerHTML += 
              "<div class='form-group'>" + 
              "<label class='control-label'>" + fieldName + "</label>" + 
              "<select class='form-control' id='" + fieldName + "'>" +
               option +
              "</select>" +
              "</div>";
          }
        // サブタイプ
        } else if (layer.typeIdField === fieldName) {
          let option = "<option value=''></option>";
          for (let type of layer.types) {
            if (type.id && type.name) {
              option += "<option value="+ type.id + ">"+ type.name +"</option>";
            }
          }
          fieldsWaterSupplyMap.innerHTML += 
            "<div class='form-group'>" + 
            "<label class='control-label'>" + fieldName + "</label>" + 
            "<select class='form-control' id='" + fieldName + "'>" +
            option +
            "</select>" +
            "</div>";
        } else {
          fieldsWaterSupplyMap.innerHTML += 
              "<div class='form-group'>" + 
                "<label class='control-label'>" + fieldName + "</label>" +
                "<input type='text' class='form-control' id='" + fieldName + "'>" +
              "</div>";
        }
      }

    }

    // マップのロード後にレイヤーを取得
    map.load()
      .then(() => {
        const promises = map.allLayers.map((layer) => {
          return layer.load();
        });
        return Promise.all(promises.toArray());
      })
      .then((layers) => {
        console.log("all " + layers.length + " layers loaded");
        let setField = true;
        layers = layers.reverse()
        for (let layer of layers) {  
          if (layer.fields) {
            const option = document.createElement("option");
            option.text = layer.title;
            option.value = layer.layerId;
            selectWaterSupplyMapTable.add(option);
            
            if (layer.fields && setField) {
              setField = false;
              setFieldsWaterSupplyMap(layer);
            }
          }
        }
      })
      .catch((error) => {
        console.error(error);
      });
}
