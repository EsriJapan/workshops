let map
let overviewMap;
let mapView;
let overView;

require([
    // ArcGIS
    "esri/Map",
    "esri/WebMap",
    "esri/views/MapView",

    // Widgets
    "esri/widgets/Home",
    "esri/widgets/Compass",
    "esri/widgets/Search",
    "esri/widgets/LayerList",
    "esri/widgets/BasemapToggle",
    "esri/widgets/ScaleBar",
    "esri/widgets/Bookmarks",
    "esri/widgets/Print",

    // geomerty
    "esri/geometry/projection",
    "esri/geometry/SpatialReference",
  ], function(
      Map, WebMap, MapView,
      Home, Compass, Search, LayerList, BasemapToggle, ScaleBar, Bookmarks, Print, projection, SpatialReference
  ) {
    /******************************************************************
     * Step2: 地図メイン部の実装
     *        Web マップの設定
     * 
     ******************************************************************/
    // TODO: Map の作成




    // TODO: View の作成




    /******************************************************************
     * Step4: 概観図の実装
     *        概観図を表示するウィジェットを作成
     * 
     ******************************************************************/
    // TODO: 概観図用の Map と View の作成




    /******************************************************************
     * Step3: 標準ウィジェットの実装
     *        標準ウィジェットを活用したウィジェット作成
     * 
     ******************************************************************/
    
    // Todo : ①検索ウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Search.html
    //   
    // 以下のプロパティを設定
    //   container："searchWidgetDiv"
    //   view: mapView



    // Todo: ②ホームウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Home.html
    // 
    // 以下のプロパティを設定
    //   view: mapView



    
    // Todo: ③コンパスウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Compass.html
    // 
    // 以下のプロパティを設定
    //   view: mapView

    

    
    // Todo: ④ベースマップウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-BasemapToggle.html
    // 
    // 以下のプロパティを設定
    //   view: mapView
    //   secondBasemap: "satellite"

    

    
    // Todo: ⑤スケールバーウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-ScaleBar.html
    // 
    // 以下のプロパティを設定
    //   style: "line"
    //   unit: "metric"
    //   container: "scaleBarDiv"
    //   view: mapView
  


    
    // Todo: ⑥レイヤーリストウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-LayerList.html
    //
    // 以下のプロパティを設定
    //   selectionEnabled: true,
    //   container: "layerListDiv"
    //   view: mapView
    //   listItemCreatedFunction を使用して、ListItem にアクセスして、凡例を表示



    
    // Todo: ⑦印刷ウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Print.html
    // 
    // 以下のプロパティを設定
    //   container: "printDiv"  
    //   view: mapView
    //   printServiceUrl: ArcGIS Online が提供する印刷サービス




    // Todo: ⑧ブックマークウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Bookmarks.html
    // 
    // 以下のプロパティを設定
    //   container: "bookmarksDiv"  
    //   view: mapView
    //   editingEnabled: true
    //   bookmarkCreationOptions: ブックマークの作成時に、スクリーンショットの取得、または現在の地図に基づいた範囲の作成を有効または無効にするために使用できます。


    

    // Todo : チャレンジ　 
    // 追加したブックマークを WebMap に保存します。
    // WebMap に保存することで、次回アプリを起動時にも追加したブックマークが有効となります。




    // Todo: ⑨Coordinates ウィジェット
    // Coordinates ウィジェットは、マウスポイントが指定している座標、現在のスケールを表示するためのウィジェットを作成します。




    overView.when(() => {
      mapView.when(() => {
        // Todo: Step4 概観図を表示（概観図ウィジェット）
        
        // Todo: Step5 属性検索の設定（属性検索ウィジェット）

        // Todo: Step5 検索結果の表示（フィーチャ テーブルウィジェット）

        // ポップアップの設定
        settingPopupTemplate();
      });
    });

  });