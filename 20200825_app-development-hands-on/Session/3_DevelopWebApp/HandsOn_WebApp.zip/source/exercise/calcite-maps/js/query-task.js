queryTaskSet = () => {
  
    const selectWaterSupplyMapTable = document.getElementById("table-water-supply-map");
    
    // Step5 属性検索ウィジェット（テーブルを選択）
    selectWaterSupplyMapTable.addEventListener("change", (event) => {
      // Todo: Step5 選択したテーブル情報を setFieldsWaterSupplyMap() に指定
      


    });

    // Step5 属性検索ウィジェット（項目名の設定）
    setFieldsWaterSupplyMap = (layer) => {
      const fieldsWaterSupplyMap = document.getElementById("fields-water-supply-map");
      fieldsWaterSupplyMap.innerHTML = "";
      // Todo: Step5 DOM の fieldsWaterSupplyMap に対して属性項目を設定


    }

    // マップのロード後にレイヤーを取得
    map.load()
      .then(() => {
        const promises = map.allLayers.map((layer) => {
          return layer.load();
        });
        return Promise.all(promises.toArray());
      })
      .then((layers) => {
        console.log("all " + layers.length + " layers loaded");
        let setField = true;
        layers = layers.reverse()
        for (let layer of layers) {  
          if (layer.fields) {
            const option = document.createElement("option");
            option.text = layer.title;
            option.value = layer.layerId;
            selectWaterSupplyMapTable.add(option);
            
            // 1件目のレイヤーを設定
            if (layer.fields && setField) {
              setField = false;
              setFieldsWaterSupplyMap(layer);
            }
          }
        }
      })
      .catch((error) => {
        console.error(error);
      });
}
