require([
  "esri/geometry/projection",
  "esri/layers/FeatureLayer",
  "esri/widgets/FeatureTable",
], function(
  projection, FeatureLayer, FeatureTable,
) {

    searchFeatureTable = () => {      
        const searchFormWaterSupplyMap = document.getElementById("form-water-supply-map");        
        const zoomToSelectFeatures = document.getElementById("zoom-select-features");
        const highlights = [];
        let layerId = "";
        let waterSupplyMapLayer;

        // Step5 属性検索の実行ボタン押下時の処理
        searchFormWaterSupplyMap.addEventListener("submit", (event) => {
          event.preventDefault();
          queryWaterSupplyMap().then(displayWaterSupplyMapResults);
        });
        
        // Step5 レイヤーのクエリ処理
        queryWaterSupplyMap = () => {
          // Todo: Step5 該当の属性データからレイヤーに対してクエリを行います。

        }

        // Step5 フィーチャ テーブルウィジェットの作成
        displayWaterSupplyMapResults = (results) => {
            // Todo: Step5 検索結果をフィーチャ テーブルウィジェットに表示
         
            // Todo: Step5 フィーチャ テーブルウィジェットでの各レコードを選択
          

        }
      
      // Step5 クリックイベントにおける処理（選択したフィーチャに移動）
      zoomToSelectFeatures.addEventListener("click", (event) => {
        // Todo: Step5 選択したフィーチャに移動


      });

    }

});