require([
  "esri/geometry/projection",
  "esri/layers/FeatureLayer",
  "esri/widgets/FeatureTable",
], function(
  projection, FeatureLayer, FeatureTable,
) {

    searchFeatureTable = () => {      
        const searchFormWaterSupplyMap = document.getElementById("form-water-supply-map");        
        const zoomToSelectFeatures = document.getElementById("zoom-select-features");
        const highlights = [];
        let layerId = "";
        let waterSupplyMapLayer;

        // 属性検索の実行ボタン押下時の処理
        searchFormWaterSupplyMap.addEventListener("submit", (event) => {
          event.preventDefault();
          queryWaterSupplyMap().then(displayWaterSupplyMapResults);
        });
        
        // Step5 レイヤーのクエリ処理
        queryWaterSupplyMap = () => {
          // Todo: Step5 該当の属性データからレイヤーに対してクエリを行います。
          let query, querylayer;
          const layers = map.allLayers.map((layer) => {
            layerId = self.event.target.elements[0].value;
            if (layer.layerId == layerId) {            
              let searchCondition;
              for (let i = 1; i < self.event.target.elements.length; i++) {
                const field = self.event.target.elements[i].id;
                const value = self.event.target.elements[i].value;
                if (value && !searchCondition) {
                  searchCondition = field + "=" + "'" + value + "'";
                } else if (value && searchCondition) {
                  searchCondition += " AND " + field + "=" + "'" + value + "'";
                }
              }
              query = layer.createQuery();
              if (searchCondition) {
                query.where = searchCondition;
              }
              query.returnGeometry = true;
              query.outFields = ["*"];
              querylayer = layer;
              return;
            }
          });
          return querylayer.queryFeatures(query);
        }

        // Step5 フィーチャ テーブルウィジェットの作成
        displayWaterSupplyMapResults = (results) => {
          // Todo: Step5 検索結果をフィーチャ テーブルウィジェットに表示
          const searchResult = document.getElementById("searchResult");
          if (results.features.length > 0) {
            searchResult.style.display = "none";

            const collapseQueryTask = document.getElementById("collapseQueryTask");
            collapseQueryTask.classList.remove("in");
           
            const headingQueryTask = document.getElementById("headingQueryTask");
            const panellabel = headingQueryTask.querySelector(".panel-label");
            panellabel.classList.add("visible-xs-inline-block")
          
            const panelclose = headingQueryTask.querySelector(".panel-close");
            panelclose.classList.add("visible-xs-flex");

          } else {
            searchResult.style.display = "flex";
            return;
          }

          // フィールド名の作成
          const fieldConfigs = [];
          for (let field of results.fields) {
              const fieldName =  {
                name: field.name,
                label: field.alias
              }
              fieldConfigs.push(fieldName);
          }

          // フィーチャ レイヤーの作成
          waterSupplyMapLayer = new FeatureLayer({
            title: results.features[0].layer.title,
            fields: results.fields,       
            objectIdField: "ObjectID",
            source: results.features, 
          });
          
          const featureTableDiv = document.getElementById("featureTableDiv");
          featureTableDiv.innerText = null; 
          featureTableDiv.style.display = "flex";
          const mapViewDiv = document.getElementById("mapViewDiv");
          mapViewDiv.style.height = "60%";

          const actionsDiv = document.getElementById("actions");      
          actionsDiv.style.display = "flex";

          if (highlights.length > 0) {
              for (let highlight of highlights) {
                highlight.highlight.remove();
              }
              highlights.splice(0);
          }
          
          // フィーチャ レイヤーの取得
          let featureLayer;
          for (let item of map.layers.items) {
            if (layerId == item.layerId) {
              featureLayer = item;
            }
          }

          // フィーチャ テーブルウィジェットの作成
          const featureTable = new FeatureTable({
            layer: waterSupplyMapLayer,
            fieldConfigs: fieldConfigs,
            container: featureTableDiv
          });
          
          // Todo: Step5 フィーチャ テーブルウィジェットでの各レコードを選択
          mapView.whenLayerView(featureLayer).then((layerView) => {
              featureTable.on("selection-change", (changes) => {
                  // 選択が解除された場合は、ハイライトされた部分を layerView から削除します。
                  changes.removed.forEach((item) => {
                      const data = highlights.find((data) => {
                          return data.feature === item.feature;
                      });
                      if (data) {
                          highlights.splice(highlights.indexOf(data), 1);
                          data.highlight.remove();
                      }
                  });
                  // 選択された場合は、該当のデータに対して layerView をハイライトします。
                  changes.added.forEach((item) => {
                      const feature = item.feature;
                      highlight = layerView.highlight(item.feature);
                      highlights.push({
                          feature: feature,
                          highlight: highlight
                      });
                  });
              });
          }).catch(function(error) {
            // layerView の作成中にエラーが発生しました。
            console.log(error)
          });
        }
      
      // Step5 クリックイベントにおける処理（選択したフィーチャに移動）
      zoomToSelectFeatures.addEventListener("click", (event) => {
        // Todo: Step5 選択したフィーチャに移動
        // フィーチャーレイヤーからクエリを作成します
        const query = waterSupplyMapLayer.createQuery();
        // ハイライトを繰り返し処理して、フィーチャーの objectID を取得します。
        const featureIds = highlights.map((result) => {
          return result.feature.getAttribute(waterSupplyMapLayer.objectIdField);
        });
        // クエリの objectId を設定します。
        query.objectIds = featureIds;
        // ズームするためジオメトリを必ず返すようにします。
        query.returnGeometry = true;
        // フィーチャ レイヤーで queryFeatures を呼び出し，結果として得られるフィーチャにズームします．
        waterSupplyMapLayer.queryFeatures(query).then((results) => {
            
            const proj = [];
            projection.load()
                .then(() => {
                    // project メソッドを使用して、平面直角座標系の9系からワールドメルカトルに変換しています。
                    for (let feature of results.features) {   
                        const transformation = projection.getTransformation(feature.geometry.spatialReference, mapView.spatialReference);
                        const projgeometry = projection.project(feature.geometry, mapView.spatialReference, transformation);   
                        proj.push(projgeometry);
                    }
                    return Promise.all(proj);
                })
                .then((geo) => {
                  let target;
                  if (geo.length > 1) {
                    target = geo;
                  } else {
                    target = {target: geo, zoom: 19};
                  }
                  // 選択したフィーチャに移動します。
                  mapView.goTo(target).catch((error) => {
                    if (error.name != "AbortError") {
                      console.error(error);
                    }
                  });
                })
                .catch((error) => {
                    console.error(error);
                });
        });
      });

    }

});