let map
let overviewMap;
let mapView;
let overView;

require([
    // ArcGIS
    "esri/Map",
    "esri/WebMap",
    "esri/views/MapView",

    // Widgets
    "esri/widgets/Home",
    "esri/widgets/Compass",
    "esri/widgets/Search",
    "esri/widgets/LayerList",
    "esri/widgets/BasemapToggle",
    "esri/widgets/ScaleBar",
    "esri/widgets/Bookmarks",
    "esri/widgets/Print",

    // geomerty
    "esri/geometry/projection",
    "esri/geometry/SpatialReference",
  ], function(
      Map, WebMap, MapView,
      Home, Compass, Search, LayerList, BasemapToggle, ScaleBar, Bookmarks, Print, projection, SpatialReference
  ) {
    /******************************************************************
     * Step2: 地図メイン部の実装
     *        Web マップの設定
     * 
     ******************************************************************/
     // TODO: Map の作成
     map = new WebMap({
      portalItem: {
        id: "b0d54c23c5ba448c83515462dbfa272f"
      }
     });
     
     // TODO: View の作成
     mapView = new MapView({
       container: "mapViewDiv",
       map: map,
       padding: {
         top: 50,
         bottom: 0
       }
     });

    /******************************************************************
     * Step4: 概観図の実装
     *        概観図を表示するウィジェットを作成
     * 
     ******************************************************************/
    // TODO: 概観図用の Map と View の作成
    // overviewMap（概観図）
    overviewMap = new Map({
      basemap: "topo"
    });

    // overView
    overView = new MapView({
      container: "overViewDiv",
      map: overviewMap,
      constraints: {
        rotationEnabled: false
      }
    });
    
    // UI コンポーネントの初期化（デフォルトのウィジェットとして設定）
    overView.ui.components = [];

    /******************************************************************
     * Step3: 標準ウィジェットの実装
     *        標準ウィジェットを活用したウィジェット作成
     * 
     ******************************************************************/
    
    // Todo : ①検索ウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Search.html
    //   
    // 以下のプロパティを設定
    //   container："searchWidgetDiv"
    //   view: mapView
    const searchWidget = new Search({
      container: "searchWidgetDiv",
      view: mapView
    });

    // Todo: ②ホームウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Home.html
    // 
    // 以下のプロパティを設定
    //   view: mapView
    const home = new Home({
      view: mapView
    });

    // ホームウィジェットをマップに追加して表示
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-views-ui-UI.html#add
    mapView.ui.add(home, "top-left");
    
    // Todo: ③コンパスウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Compass.html
    // 
    // 以下のプロパティを設定
    //   view: mapView
    const compass = new Compass({
      view: mapView
    });

    // コンパスウィジェットをマップに追加して表示
    mapView.ui.add(compass, "top-left");
    
    // Todo: ④ベースマップウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-BasemapToggle.html
    // 
    // 以下のプロパティを設定
    //   view: mapView
    //   secondBasemap: "satellite"
    const basemapToggle = new BasemapToggle({
      view: mapView,
      secondBasemap: "satellite"
    });

    // ベースマップウィジェットをマップに追加して表示
    mapView.ui.add(basemapToggle, "bottom-right");          
    
    // Todo: ⑤スケールバーウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-ScaleBar.html
    // 
    // 以下のプロパティを設定
    //   style: "line"
    //   unit: "metric"
    //   container: "scaleBarDiv"
    //   view: mapView
    const scaleBar = new ScaleBar({
      style: "line",
      unit: "metric",
      container: "scaleBarDiv",
      view: mapView
    });

    // manual を使用することで CSS を使用して任意の位置に配置することができます。
    mapView.ui.add(scaleBar, "manual");
    
    // Todo: ⑥レイヤーリストウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-LayerList.html
    //
    // 以下のプロパティを設定
    //   selectionEnabled: true,
    //   container: "layerListDiv"
    //   view: mapView
    //   listItemCreatedFunction を使用して、ListItem にアクセスして、凡例を表示
    const layerList = new LayerList({
        selectionEnabled: true,
        container: "layerListDiv",
        view: mapView,
        listItemCreatedFunction: function(event) {
            const item = event.item;
            if (item.layer.type != "group") {
              item.panel = {
                content: "legend",
                open: true
              };
            }
        }
    });
    
    // Todo: ⑦印刷ウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Print.html
    // 
    // 以下のプロパティを設定
    //   container: "printDiv"  
    //   view: mapView
    //   printServiceUrl: ArcGIS Online が提供する印刷サービス
    const print = new Print({
      view: mapView,
      container: "printDiv",
      printServiceUrl: "https://utility.arcgisonline.com/arcgis/rest/services/Utilities/PrintingTools/GPServer/Export%20Web%20Map%20Task"
    });
    
    // Todo: ⑧ブックマークウィジェット
    // https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Bookmarks.html
    // 
    // 以下のプロパティを設定
    //   container: "bookmarksDiv"  
    //   view: mapView
    //   editingEnabled: true
    //   bookmarkCreationOptions: ブックマークの作成時に、スクリーンショットの取得、または現在の地図に基づいた範囲の作成を有効または無効にするために使用できます。
    const bookmarks = new Bookmarks({
      view: mapView,
      container: "bookmarksDiv",
      editingEnabled: true,
      bookmarkCreationOptions: {
          takeScreenshot: true,
          captureExtent: true,
          screenshotSettings: {
            width: 100,
            height: 100
          }
      }
    });
    
    // Todo : チャレンジ　 
    // 追加したブックマークを WebMap に保存します。
    // WebMap に保存することで、次回アプリを起動時にも追加したブックマークが有効となります。
    const webmapSave = document.getElementById("WebmapSave");
    webmapSave.addEventListener("click", (event) => {
      map.updateFrom(mapView)
        .then(() => {
          event.target.disabled = true;
          event.target.textContent = "保存中..."
          return map.save();
        })
        .then((portalItem) => {
          alert("お気に入りを保存しました。:" + portalItem.id);
          event.target.disabled = false;
          event.target.textContent = "保存"
        })
        .catch((error) => {
          alert("お気に入りの保存に失敗しました。:" + error);
          event.target.disabled = false;
          event.target.textContent = "保存"
        });
    });

    // Todo: ⑨Coordinates ウィジェット
    // Coordinates ウィジェットは、マウスポイントが指定している座標、現在のスケールを表示するためのウィジェットを作成します。
    const coordsWidget = document.createElement("div");
    coordsWidget.id = "coordsWidget";
    coordsWidget.className = "esri-widget esri-component";
    coordsWidget.style.padding = "7px 15px 5px";

    mapView.ui.add(coordsWidget, "bottom-right");

    mapView.on("pointer-move", (evt) => {
      showCoordinates(mapView.toMap({ x: evt.x, y: evt.y }));
    });

    const outSpatialReference = new SpatialReference({
      wkid: 6677
    });

    const showCoordinates = (pt) => {      
      projection.load().then(() => {
        const projgeometry = projection.project(pt, outSpatialReference);    
        const coords = "X/Y " + projgeometry.x.toFixed(3) + " " + projgeometry.y.toFixed(3) +
            " | 縮尺 1:" + Math.round(mapView.scale * 1) / 1 +
            " | ズーム " + mapView.zoom;
        coordsWidget.innerHTML = coords;
      });
    }

    overView.when(() => {
      mapView.when(() => {
        // Todo: Step4 概観図を表示（概観図ウィジェット）
        overViewMapSet();
        // Todo: Step5 属性検索の設定（属性検索ウィジェット）
        queryTaskSet();
        // Todo: Step5 検索結果の表示（フィーチャ テーブルウィジェット）
        searchFeatureTable();
        // ポップアップの設定
        settingPopupTemplate();
      });
    });

  });