require([
  "esri/Graphic",
  "esri/core/watchUtils"
], function(
    Graphic, watchUtils
) {

    // Todo: Step4 概観図を表示（概観図ウィジェット）
    overViewMapSet = () => {

      // グラフィックの追加
      const extent3Dgraphic = new Graphic({
        geometry: null,
        symbol: {
          type: "simple-fill",
          color: [0, 0, 0, 0.5],
          outline: null
        }
      });
      overView.graphics.add(extent3Dgraphic);
      
      watchUtils.init(mapView, "extent", (extent) => {
        // mapView が更新（地図の表示を変更）した場合は、概観図と同期する
        if (mapView.updating) {
          overView
            .goTo({
              center: mapView.center,
              scale: 
              mapView.scale *
                2 *
                Math.max(
                  mapView.width / overView.width,
                  mapView.height / overView.height
                )
            })
            .catch((error) => {
               // goto-interrupted エラーは無視する
              if (error.name != "view:goto-interrupted") {
                console.error(error);
              }
            });
        }
        extent3Dgraphic.geometry = extent;
      });
      
    }

});