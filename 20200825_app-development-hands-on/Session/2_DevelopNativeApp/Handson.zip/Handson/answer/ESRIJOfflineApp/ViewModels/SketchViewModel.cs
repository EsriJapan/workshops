﻿using ESRIJOfflineApp.Commands;
using ESRIJOfflineApp.Models;
using System.Windows.Input;

namespace ESRIJOfflineApp.ViewModels
{
    public class SketchViewModel : BaseViewModel
    {

        private SketchModel _sketchModel = new SketchModel();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SketchViewModel()
        {
        }
    }
}
