# coding:utf-8

# ArcPy サイト パッケージをインポート 
import arcpy,os

######################################
# ワークスペースの設定
######################################
workPath = r"C:\data"
arcpy.env.workspace = workPath + r"\ArcGIS Pro\arcpy.gdb"

######################################
# パラメーター入力値を受け取る
######################################
csv_table = arcpy.GetParameterAsText(0)
output = arcpy.GetParameterAsText(1)

######################################
# CSV ファイルを読み込む
# ジオプロセシングツールの実行(課題②)
######################################

# ジオプロセシングツールを実行するためのパラメータを作成
out_csv_feature_class = "csv"
x_field = "X"
y_field = "Y"
event_layer = "csv_layer"
current_csv_feature_class = "current"

# CSV ファイルからフィーチャ レイヤーを作成
arcpy.MakeXYEventLayer_management(csv_table, x_field, y_field, event_layer)

# フィーチャレイヤーからフィーチャクラスを作成
arcpy.FeatureClassToFeatureClass_conversion(event_layer, arcpy.env.workspace, out_csv_feature_class)

# CSV ファイルから作成したフィーチャ レイヤーを削除
arcpy.DeleteRows_management(current_csv_feature_class)
arcpy.Append_management(out_csv_feature_class, current_csv_feature_class, "NO_TEST")

#######################################
# 各駅ごとの放置二輪車数を集計(課題③)
#######################################
# current フィーチャクラスから取得するフィールド名のリストを作成
fields = ['over_capacity', 'abandoned_total','parking_total', 'capacity_total']

# フィーチャクラス (current) に対してカーソルを定義
cursor = arcpy.da.UpdateCursor("current", fields)

# 23 区ごとに放置車両の合計値を算出
for row in cursor:
    row[0] = row[1] - (row[2] + row[3])
    cursor.updateRow(row)

# オブジェクトを削除して参照を解放します。
del cursor, row

#######################################
# マップをPDF に出力(課題①)
#######################################
#ファイル名の設定とすでに存在する場合は PDF を削除
pdfPath = r"C:\data\output\report.pdf"
if os.path.exists(pdfPath):
    os.remove(pdfPath)

#プロジェクトファイルから PDF を作成
aprx = arcpy.mp.ArcGISProject(workPath + r"\ArcGIS Pro\arcpy.aprx")

# PDF出力
lyrs = aprx.listMaps()[0]
for lyr in lyrs.listLayers():
    if lyr.name == '放置二輪車数':
        ablyr = lyr
    elif lyr.name == '容量超過':
        cplyr = lyr

# マップシリーズで指定した図郭を PDF に出力
ablyr.visible = True
cplyr.visible = False
aprx.listLayouts()[0].mapSeries.exportToPDF(output + r"\map1.pdf")

ablyr.visible = True
cplyr.visible = True
aprx.listLayouts()[0].mapSeries.exportToPDF(output + r"\map2.pdf")

#ファイルの作成とページの適用
pdfDoc = arcpy.mp.PDFDocumentCreate(pdfPath)
pdfDoc.appendPages(r"C:\data\output\title.pdf")
pdfDoc.appendPages(r"C:\data\output\map1.pdf")
pdfDoc.appendPages(r"C:\data\output\map2.pdf")

#保存と変数の削除
pdfDoc.saveAndClose()
del pdfDoc
del aprx