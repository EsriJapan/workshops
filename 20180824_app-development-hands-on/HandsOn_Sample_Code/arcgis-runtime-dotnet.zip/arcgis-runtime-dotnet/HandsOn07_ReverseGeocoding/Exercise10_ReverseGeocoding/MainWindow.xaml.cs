﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Esri.ArcGISRuntime;
using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Tasks.Geocoding;
using Esri.ArcGISRuntime.UI;
using Esri.ArcGISRuntime.UI.Controls;

namespace Exercise10_ReverseGeocoding
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        #region データソース
        // ArcGIS Online のジオコード サービスの URL
        private string _geocodeServicePath = "https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer";
        #endregion

        private LocatorTask myLocatorTask;


        public MainWindow()
        {
            InitializeComponent();
            InitializeAsync();
        }
 

        /// <summary>
        /// マップの作成
        /// </summary>
        public void InitializeAsync()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            CreateLoatorTask();

        }

        /// <summary>
        /// ロケーター タスクの作成
        /// </summary>
        public async void CreateLoatorTask()
        {
            // ジオコード サービスの URL からロケーター タスクを作成
            myLocatorTask = await LocatorTask.CreateAsync(new Uri(_geocodeServicePath));

            // マップ ビューのタッチ イベントを登録する
            MyMapView.GeoViewTapped += MyMapView_GeoViewTappedAsync;
        }

        /// <summary>
        /// リバース ジオコーディングの実行
        /// </summary>
        private async void MyMapView_GeoViewTappedAsync(object sender, GeoViewInputEventArgs e)
        {
            try
            {
                // クリックした地点の住所を検索（リバース ジオコーディングを実行）
                IReadOnlyList<GeocodeResult> addresses = await myLocatorTask.ReverseGeocodeAsync(e.Location);

                // 検索結果（GeocodeResult オブジェクト）を取得
                GeocodeResult address = addresses.First();

                // GeocodeResult オブジェクトから住所の文字列を取得
                string addressString = address.Attributes["Address"].ToString();

                // 住所の文字列が空でない場合
                if (addressString != "")
                {
                    // コールアウトのタイトル文字列を設定
                    string calloutTitleString = "住所";

                    // コールアウトを表示するポイントを設定
                    MapPoint point = MyMapView.ScreenToLocation(e.Position);

                    // タイトル文字列と詳細文字列（住所）を設定してコールアウトを作成
                    CalloutDefinition callout = new CalloutDefinition(calloutTitleString, addressString);

                    // クリックした地点にコールアウトを表示
                    MyMapView.ShowCalloutAt(point, callout);
                }

            }

            catch (Esri.ArcGISRuntime.Http.ArcGISWebException exception)
            {
                MessageBox.Show("ArcGIS の WebException が発生しました：" + exception.Message.ToString(), "エラー");

            }
        }
    }
}
