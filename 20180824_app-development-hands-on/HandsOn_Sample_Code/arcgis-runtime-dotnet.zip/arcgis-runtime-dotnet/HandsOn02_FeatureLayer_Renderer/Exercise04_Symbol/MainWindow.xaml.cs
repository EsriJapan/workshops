﻿using System;
using System.Drawing;
using System.Windows;
using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.Geometry;

namespace Exercise04_Symbol
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        #region データソース
        // 都道府県界のデータ
        private string _featureLayerPath = "https://<your service url>";
        #endregion

        public MainWindow()
        {
            InitializeComponent();

            Initialize();
        }

        /// <summary>
        /// マップの作成
        /// </summary>
        public async void Initialize()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(BasemapType.Streets, 35.5165, 138.4603, 4);

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            // 中心ポイント
            MapPoint point = new MapPoint(138.4603, 35.5165, SpatialReferences.Wgs84);

            // 中心の座標(_point)とスケール(_scale)を指定してズームする
            await MyMapView.SetViewpointCenterAsync(point, 10000000);

            DisplayLayers();
        }

        /// <summary>
        /// フィーチャ レイヤーの表示
        /// </summary>
        private void DisplayLayers()
        {
            // フィーチャ サービスの URL を指定して、フィーチャ テーブル（ServiceFeatureTable）オブジェクトを作成する
            ServiceFeatureTable serviceFeatureTable = new ServiceFeatureTable(new Uri(_featureLayerPath));

            // フィーチャ テーブルからフィーチャ レイヤー（FeatureLayer）オブジェクトを作成する
            FeatureLayer featureLayer = new FeatureLayer(serviceFeatureTable);

            // 個別値分類レンダラーを作成する
            UniqueValueRenderer renderer = CreateRenderder();

            // フィーチャ レイヤーにレンダラ―を設定する
            featureLayer.Renderer = renderer;

            // マップ オブジェクトの操作レイヤー（OperationalLayers）にフィーチャ レイヤーを追加する
            MyMapView.Map.OperationalLayers.Add(featureLayer);
        }

        /// <summary>
        /// 個別値分類レンダラーの設定
        /// </summary>
        public UniqueValueRenderer CreateRenderder()
        {

            // ポリゴンのアウト ラインのシンボル設定
            SimpleLineSymbol outlineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle.Solid, Color.White, 1);

            // 個別値分類レンダラー（UniqueValueRenderer）の作成
            UniqueValueRenderer uniqueValueRenderer = new UniqueValueRenderer();

            // 分類に使用する属性項目（都道府県名）のフィール名を設定
            uniqueValueRenderer.FieldNames.Add("KEN");

            // 分類を作成（東京都）
            // ポリゴンの塗潰しシンボルを作成
            SimpleFillSymbol tokyoFillSymbol = new SimpleFillSymbol(SimpleFillSymbolStyle.Solid, Color.Red, outlineSymbol);
            // 説明、ラベル、表示シンボル、属性値（"KEN" フィールドの値が "東京都"）のパラメーターを設定して UniqueValue オブジェクトを作成し、UniqueValueRenderer に追加する
            uniqueValueRenderer.UniqueValues.Add(new UniqueValue("都道府県", "東京都", tokyoFillSymbol, "東京都"));

            // 分類を作成（神奈川県）
            SimpleFillSymbol kanagawaFillSymbol = new SimpleFillSymbol(SimpleFillSymbolStyle.Solid, Color.Blue, outlineSymbol);
            uniqueValueRenderer.UniqueValues.Add(new UniqueValue("都道府県", "神奈川県", kanagawaFillSymbol, "神奈川県"));

            // 分類を作成（その他の県）
            SimpleFillSymbol defaultFillSymbol = new SimpleFillSymbol(SimpleFillSymbolStyle.Solid, Color.Gray, outlineSymbol);
            uniqueValueRenderer.DefaultSymbol = defaultFillSymbol;

            return uniqueValueRenderer;

        }

    }
}
