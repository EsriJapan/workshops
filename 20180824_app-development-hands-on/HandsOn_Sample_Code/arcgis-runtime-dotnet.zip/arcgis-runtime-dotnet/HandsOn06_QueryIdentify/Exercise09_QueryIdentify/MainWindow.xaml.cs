﻿using Esri.ArcGISRuntime;
using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.UI.Controls;
using System;
using System.Windows;



namespace Exercise09_QueryIdentify
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        #region データソース
        // 都道府県界のデータ
        private string _featureLayerPath = "https://<your service url>";
        #endregion

        FeatureLayer myFeatureLayer;


        public MainWindow()
        {
            InitializeComponent();


            Initialize();
        }

        /// <summary>
        /// マップの作成
        /// </summary>
        public void Initialize()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            DisplayLayers();
        }

        /// <summary>
        /// フィーチャ レイヤーの表示
        /// </summary>
        public async void DisplayLayers()
        {
            // フィーチャ サービスの URL を指定して、フィーチャ テーブル（ServiceFeatureTable）オブジェクトを作成する
            ServiceFeatureTable FeatureTable = new ServiceFeatureTable(new Uri(_featureLayerPath));

            // フィーチャ テーブルからフィーチャ レイヤー（FeatureLayer）オブジェクトを作成する
            myFeatureLayer = new FeatureLayer(FeatureTable);

            // フィーチャ レイヤーをロードする
            await myFeatureLayer.LoadAsync();

            // フィーチャ レイヤーがロードされたら、タッチ イベントを登録する
            if (myFeatureLayer.LoadStatus == LoadStatus.Loaded)
            {
                MyMapView.GeoViewTapped += OnMapViewTapped;
            }

            // マップ オブジェクトの操作レイヤー（OperationalLayers）にフィーチャ レイヤーを追加する
            MyMapView.Map.OperationalLayers.Add(myFeatureLayer);
            
            // フィーチャ レイヤーのエクステントにズームする
            await MyMapView.SetViewpointGeometryAsync(myFeatureLayer.FullExtent);

        }

        /// <summary>
        /// 個別属性表示の実行
        /// </summary>
        private async void OnMapViewTapped(object sender, GeoViewInputEventArgs e)
        {

            // 既にフィーチャが選択されている場合は、選択を解除する
            myFeatureLayer.UnselectFeatures(await myFeatureLayer.GetSelectedFeaturesAsync());

            // フィーチャを検索する画面上の地点（クリックされた地点を設定）
            Point screenPoint = e.Position;
            // クリックされた地点からの許容範囲（ピクセル）
            double tolerance = 10;
            // ポップアップ要素のみを返すかの指定
            bool onlyReturnPopups = false;

            // 個別属性表示を実行する
            IdentifyLayerResult result = await MyMapView.IdentifyLayerAsync(myFeatureLayer, screenPoint, tolerance, onlyReturnPopups);

            // 結果からフィーチャを取得する
            if (result.GeoElements.Count > 0) {

                // GeoElement から Feature へ変換する
                Feature feature = (Feature)result.GeoElements[0];
                // 検索結果のフィーチャを選択(ハイライト表示)する
                myFeatureLayer.SelectFeature(feature);

                // 検索結果のフィーチャの属性値（KEN" フィールド）を取得して。メッセージボックスで表示する
                string attribute = (String)feature.GetAttributeValue("KEN");
                MessageBox.Show(attribute + " のフィーチャが検索されました。", "検索結果");
            }

        }

    }
}
