﻿using Esri.ArcGISRuntime;
using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.Mapping;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;



namespace Exercise08_QueryLayer
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        #region データソース
        // 都道府県界のデータ
        private string _featureLayerPath = "https://<your service url>";
        #endregion

        ServiceFeatureTable myFeatureTable;

        public MainWindow()
        {
            InitializeComponent();

            Initialize();
        }

        /// <summary>
        /// マップの作成
        /// </summary>
        public void Initialize()
        {
            // クエリをかけた結果を地図に表示する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            // レイヤー表示
            DisplayLayers();
        }


        /// <summary>
        /// フィーチャ レイヤーの表示
        /// </summary>
        public async void DisplayLayers()
        {
            // フィーチャ サービスの URL を指定して、フィーチャ テーブル（ServiceFeatureTable）オブジェクトを作成する
            myFeatureTable = new ServiceFeatureTable(new Uri(_featureLayerPath));

            // フィーチャ テーブルをロードする
            await myFeatureTable.LoadAsync();

            // フィーチャ テーブルがロードされたら、検索ボタンを有効にする
            if (myFeatureTable.LoadStatus == LoadStatus.Loaded)
            {
                QueryButton.IsEnabled = true;
            }

            // フィーチャ テーブルからフィーチャ レイヤー（FeatureLayer）オブジェクトを作成する
            FeatureLayer featureLayer = new FeatureLayer(myFeatureTable);

            // マップ オブジェクトの操作レイヤー（OperationalLayers）にフィーチャ レイヤーを追加する
            MyMapView.Map.OperationalLayers.Add(featureLayer);

            // フィーチャ レイヤーのエクステントにズームする
            await MyMapView.SetViewpointGeometryAsync(featureLayer.FullExtent);

        }

        /// <summary>
        /// フィーチャのクエリ
        /// </summary>
        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            // 既にフィーチャが選択されている場合は、選択を解除する
            myFeatureTable.FeatureLayer.UnselectFeatures(await myFeatureTable.FeatureLayer.GetSelectedFeaturesAsync());

            // クエリを実行する条件を作成する
            QueryParameters param = new QueryParameters();

            // 属性条件を設定（"KEN" フィールドの値がテキストボックスの値に一致するフィーチャを検索）
            param.WhereClause = "KEN ='" + QueryTexBox.Text + "'";

            // クエリを実行する
            FeatureQueryResult featureResult = await myFeatureTable.QueryFeaturesAsync(param);

            // クエリの結果からフィーチャを取得する
            foreach (Feature feature in featureResult)
            {
                // 検索結果のフィーチャを選択(ハイライト表示)する
                myFeatureTable.FeatureLayer.SelectFeature(feature);

                // フィーチャのジオメトリにズームする
                await MyMapView.SetViewpointGeometryAsync(feature.Geometry.Extent);
            }

        }
    }
}
