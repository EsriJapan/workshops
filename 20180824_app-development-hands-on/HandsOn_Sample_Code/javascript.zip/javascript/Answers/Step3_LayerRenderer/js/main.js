require([
  "esri/Map",
  "esri/views/MapView",
  "esri/layers/FeatureLayer",
  "dojo/domReady!"
], function(Map, MapView, FeatureLayer) {

  /******************************************************************
   *
   * ステップ３：レイヤーのレンダラー
   *
   ******************************************************************/

  // 1. 空港の愛称を分類する個別値分類レンダラーを作成

  // デフォルト（その他）のマーカー シンボルの作成
  var defaultSymPoint = {
    type: "simple-marker",  // new SimpleMarkerSymbol() の autocast
    style: "circle",        // スタイル
    color: "red",           // 色
    size: 10                // 大きさ
  };

  // 個別値（羽田空港）のマーカー シンボルの作成
  var symbolPoint = {
    type: "simple-marker",
    style: "square",
    color: "aqua",
    size: 10
  };

  // 個別値分類レンダラーの作成
  var rendererPoint = {
    type: "unique-value",   // new UniqueValueRenderer() の autocast
    field: "NICKNAME",      // 個別値が含まれるフィールド
    defaultSymbol: defaultSymPoint, // デフォルト シンボル
    uniqueValueInfos: [{    // 個別値の設定
      value: "羽田空港",
      symbol: symbolPoint,
      label: "空港"
    }]
  };

  // 2. 都道府県（ポリゴン）の名称を分類する個別値分類レンダラーを作成
  // TODO：[KEN] フィールドに含まれる個別値を [神奈川県] とその他にレンダリングしてみよう

  // デフォルト（その他）のマーカー シンボルの作成
  var defaultSymPoly = {
    type: "simple-fill",  // new SimpleFillSymbol() の autocast
    color: "powderblue",
    style: "solid",
    outline: {            // new SimpleLineSymbol() の autocast
      color: "white",
      width: 0.7,
      style: "solid"
    }
  };

  // 個別値（神奈川県）のマーカー シンボルの作成
  var symbolPoly = {
    type: "simple-fill",
    color: "blue",
    style: "solid",
    outline: {
      color: "white",
      width: 0.7,
      style: "solid"
    }
  };

  // 個別値分類レンダラーの作成
  var rendererPoly = {
    type: "unique-value",
    field: "KEN",
    defaultSymbol: defaultSymPoly,
    uniqueValueInfos: [{
      value: "神奈川県",
      symbol: symbolPoly,
      label: "都道府県"
    }]
  };

  // 3. 作成したレンダラーをレイヤーに設定

  var airportPoint = new FeatureLayer({
    url: "https://<your service url>",
    renderer: rendererPoint
  });

  var airportPoly = new FeatureLayer({
    url: "https://<your service url>",
    renderer: rendererPoly,
    opacity: 0.8
  });

  var map = new Map({
    basemap: "gray-vector",
    layers: [airportPoly, airportPoint]
  });

  var view = new MapView({
    container: "viewDiv",
    map: map,
    center: [138.4603, 35.5165],
    zoom: 4
  });

});
