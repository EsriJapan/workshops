require([
  "esri/Map",
  "esri/views/MapView",
  "esri/layers/FeatureLayer",
  "esri/PopupTemplate",
  "dojo/domReady!"
], function(Map, MapView, FeatureLayer, PopupTemplate) {

  var defaultSymPoint = {
    type: "simple-marker",
    style: "circle",
    color: "red",
    size: 10
  };

  var symbolPoint = {
    type: "simple-marker",
    style: "square",
    color: "aqua",
    size: 10
  };

  var rendererPoint = {
    type: "unique-value",
    field: "NICKNAME",
    defaultSymbol: defaultSymPoint,
    uniqueValueInfos: [{
      value: "羽田空港",
      symbol: symbolPoint,
      label: "空港"
    }]
  };
 
  var defaultSymPoly = {
    type: "simple-fill",
    color: "powderblue",
    style: "solid",
    outline: {
      color: "white",
      width: 0.7,
      style: "solid"
    }
  };

  var symbolPoly = {
    type: "simple-fill",
    color: "blue",
    style: "solid",
    outline: {
      color: "white",
      width: 0.7,
      style: "solid"
    }
  };

  var rendererPoly = {
    type: "unique-value",
    field: "KEN",
    defaultSymbol: defaultSymPoly,
    uniqueValueInfos: [{
      value: "神奈川県",
      symbol: symbolPoly,
      label: "都道府県"
    }]
  };

  /******************************************************************
   *
   * ステップ４：ポップアップの作成
   *
   ******************************************************************/

  // テンプレートの作成
  // TODO: fieldInfos に以下のフィールドを追加してみよう
  // [NICKNAME]、[CLASS_1]、[CLASS_2]、[ESTAB_MANAGE]、[DOMESTIC_NUM]、[INTERNATIONAL__NUM]
  var popupTemplate = new PopupTemplate({
    title: "空港情報",
    content: [{
      type: "fields", // コンテンツのタイプを定義 - フィールド情報の表示
      fieldInfos: [{
        fieldName: "NAME",
        visible: true,
        label: "名称"
      }, {
        fieldName: "NICKNAME",
        visible: true,
        label: "愛称"
      }, {
        fieldName: "CLASS_1",
        visible: true,
        label: "種別1"
      }, {
        fieldName: "CLASS_2",
        visible: true,
        label: "種別2"
      }, {
        fieldName: "ESTAB_MANAGE",
        visible: true,
        label: "設置管理者"
      }, {
        fieldName: "DOMESTIC_NUM",
        visible: true,
        format: {
          places: 0,
          digitSeparator: true
        },
        label: "国内線乗降客数（平成25年度）"
      }, {
        fieldName: "INTERNATIONAL__NUM",
        visible: true,
        format: {
          places: 0,
          digitSeparator: true
        },
        label: "国際線乗降客数（平成25年度）"
      }]
    }, {
      type: "media", // メディア（チャートや画像）の表示
      mediaInfos: [{
        title: "国内線および国際線乗降客数",
        type: "bar-chart",
        value: {
          theme: "Julie",
          fields: ["DOMESTIC_NUM", "INTERNATIONAL__NUM"]
        }
      }]
    }]
  });

  var airportPoint = new FeatureLayer({
    url: "https://<your service url>",
    renderer: rendererPoint,
    popupTemplate: popupTemplate  // テンプレートの設定
  });

  var airportPoly = new FeatureLayer({
    url: "https://<your service url>",
    renderer: rendererPoly,
    opacity: 0.8
  });

  var map = new Map({
    basemap: "gray-vector",
    layers: [airportPoly, airportPoint]
  });

  var view = new MapView({
    container: "viewDiv",
    map: map,
    center: [138.4603, 35.5165],
    zoom: 4,
    // 表示位置の設定
    popup: {
      dockEnabled: true,
      dockOptions: {
        buttonEnabled: false,
        breakpoint: false
      }
    }
  });

});
