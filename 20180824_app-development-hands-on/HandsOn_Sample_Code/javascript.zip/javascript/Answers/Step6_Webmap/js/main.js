require([
  "esri/WebMap",
  "esri/views/MapView",
  "dojo/domReady!"
], function(WebMap, MapView) {

  /******************************************************************
   *
   * ステップ６：Web マップ
   *
   ******************************************************************/

  // Web マップの作成
  // TODO: 以下の Web マップを使用してマップを作成してみよう
  // https://www.arcgis.com/home/item.html?id=<your webmap id>
  var map = new WebMap({
    portalItem: { // portalItem の autocast
      id: "<your webmap id>"
    }
  });

  // View の作成
  var view = new MapView({
    container: "viewDiv",
    map: map
  });

});
