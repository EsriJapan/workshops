require([
  "esri/Map",
  "esri/views/MapView",
  "esri/layers/FeatureLayer",
  "dojo/domReady!"
], function(Map, MapView, FeatureLayer) {

  /******************************************************************
   *
   * ステップ２：レイヤーの追加
   *
   ******************************************************************/

  // 空港のポイント レイヤー
  // TODO: 以下のサービスからレイヤーを作成してみよう
  // https://<your service url>
  var airportPoint = new FeatureLayer({
    url: "https://<your service url>"
  });

  // 都道府県のポリゴン レイヤー
  // TODO: 以下のサービスからレイヤーを作成してみよう
  // https://<your service url>
  var airportPoly = new FeatureLayer({
    url: "https://<your service url>"
  });

  var map = new Map({
    basemap: "gray-vector",
    // TODO: 作成したレイヤーを追加してみよう
    layers: [airportPoly, airportPoint]
  });

  var view = new MapView({
    container: "viewDiv",
    map: map,
    center: [138.4603, 35.5165],
    zoom: 4
  });

});
