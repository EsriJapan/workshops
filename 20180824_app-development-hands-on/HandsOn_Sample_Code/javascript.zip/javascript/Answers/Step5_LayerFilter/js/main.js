require([
  "esri/Map",
  "esri/layers/FeatureLayer",
  "esri/views/MapView",
  "esri/PopupTemplate",
  "dojo/domReady!"
], function(Map, FeatureLayer, MapView, PopupTemplate) {

  var defaultSymPoint = {
    type: "simple-marker",
    style: "circle",
    color: "red",
    size: 10
  };

  var symbolPoint = {
    type: "simple-marker",
    style: "square",
    color: "aqua",
    size: 10
  };

  var rendererPoint = {
    type: "unique-value",
    field: "NICKNAME",
    defaultSymbol: defaultSymPoint,
    uniqueValueInfos: [{
      value: "羽田空港",
      symbol: symbolPoint,
      label: "空港"
    }]
  };

  var defaultSymPoly = {
    type: "simple-fill",
    color: "powderblue",
    style: "solid",
    outline: {
      color: "white",
      width: 0.7,
      style: "solid"
    }
  };

  var symbolPoly = {
    type: "simple-fill",
    color: "blue",
    style: "solid",
    outline: {
      color: "white",
      width: 0.7,
      style: "solid"
    }
  };

  var rendererPoly = {
    type: "unique-value",
    field: "KEN",
    defaultSymbol: defaultSymPoly,
    uniqueValueInfos: [{
      value: "神奈川県",
      symbol: symbolPoly,
      label: "都道府県"
    }]
  };

  var popupTemplate = new PopupTemplate({
    title: "空港情報",
    content: [{
      type: "fields",
      fieldInfos: [{
        fieldName: "NAME",
        visible: true,
        label: "名称"
      }, {
        fieldName: "NICKNAME",
        visible: true,
        label: "愛称"
      }, {
        fieldName: "CLASS_1",
        visible: true,
        label: "種別1"
      }, {
        fieldName: "CLASS_2",
        visible: true,
        label: "種別2"
      }, {
        fieldName: "ESTAB_MANAGE",
        visible: true,
        label: "設置管理者"
      }, {
        fieldName: "DOMESTIC_NUM",
        visible: true,
        format: {
          places: 0,
          digitSeparator: true
        },
        label: "国内線乗降客数（平成25年度）"
      }, {
        fieldName: "INTERNATIONAL__NUM",
        visible: true,
        format: {
          places: 0,
          digitSeparator: true
        },
        label: "国際線乗降客数（平成25年度）"
      }]
    }, {
      type: "media",
      mediaInfos: [{
        title: "国内線および国際線乗降客数",
        type: "bar-chart",
        value: {
          theme: "Julie",
          fields: ["DOMESTIC_NUM", "INTERNATIONAL__NUM"]
        }
      }]
    }]
  });

  var airportPoint = new FeatureLayer({
    url: "https://<your service url>",
    renderer: rendererPoint,
    popupTemplate: popupTemplate
  });

  var airportPoly = new FeatureLayer({
    url: "https://<your service url>",
    renderer: rendererPoly,
    opacity: 0.8
  });

  var map = new Map({
    basemap: "gray-vector",
    layers: [airportPoly, airportPoint]
  });

  var view = new MapView({
    container: "viewDiv",
    map: map,
    center: [138.4603, 35.5165],
    zoom: 4,
    popup: {
      dockOptions: {
        position: "bottom-right"
      }
    }
  });

  /******************************************************************
   *
   * ステップ５：フィーチャのクエリ
   *
   ******************************************************************/

  view.when(function() {
    // レイヤーの読み込みが完了したらクエリを実行
    airportPoint.watch("loaded", function() {
      var select = document.getElementById("selectManage");

      // 設置管理者の個別値を取得
      var query = airportPoint.createQuery();
      query.orderByFields = ["ESTAB_MANAGE"];
      query.outFields = ["ESTAB_MANAGE"];
      query.returnGeometry = false;
      query.returnDistinctValues = true;

      airportPoint.queryFeatures(query).then(function(results) {
        // 取得した個別値をもとにドロップダウンリストを作成
        results.features.forEach(function(feature) {
          var option = document.createElement("option");
          option.value = option.text = feature.attributes["ESTAB_MANAGE"];
          select.appendChild(option);
        });
      });

      // ドロップダウンリストの選択でクエリを実行
      select.addEventListener("change", function() {
        view.graphics.removeAll();  // グラフィックスを削除

        var uniqueVal = select.value;
        if (uniqueVal === "") {
          return;
        }

        // TODO: [ESTAB_MANAGE] フィールドに選択した値を持つフィーチャを検索
        var query = airportPoint.createQuery();
        query.where = "ESTAB_MANAGE = '" + uniqueVal + "'";

        airportPoint.queryFeatures(query).then(function(results) {
          // TODO: 検索結果をマップに表示
          var graphics = results.features.map(function(graphic) {   // グラフィックの作成
            graphic.symbol = {
              type: "simple-marker",
              color: null,
              size: 16,
              outline: {
                color: "yellow",
                width: 4
              }
            };
            return graphic;
          });

          view.graphics.addMany(graphics);    // グラフィックの追加

          view.goTo(graphics);    // グラフィックへ view を移動
        });
      });

      view.ui.add("container", "top-right");
    });
  });

});
