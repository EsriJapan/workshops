require([
  "esri/Map",
  "esri/views/MapView",
  "dojo/domReady!"
], function(Map, MapView) {

  /******************************************************************
   *
   * ステップ１：マップの作成
   *
   ******************************************************************/

  // TODO: Map の作成
  var map = new Map({
    basemap: "gray-vector"  // ベースマップ
  });

  // TODO: View の作成
  var view = new MapView({
    container: "viewDiv",   // view を描画する div 要素
    map: map,               // view に描画する Map オブジェクト
    center: [138.4603, 35.5165],  // 中心地点
    zoom: 4                 // ズームレベル
  });
});
