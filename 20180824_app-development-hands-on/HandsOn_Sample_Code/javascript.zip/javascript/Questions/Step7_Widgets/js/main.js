require([
  "esri/WebMap",
  "esri/views/MapView",
  "esri/widgets/Legend",
  "esri/widgets/Search",
  "dojo/domReady!"
], function(WebMap, MapView, Legend, Search) {
  var map = new WebMap({
    portalItem: {
      id: "<your webmap id>"
    }
  });

  var view = new MapView({
    container: "viewDiv",
    map: map
  });

  view.when(function() {
    var airportPoint = map.layers.getItemAt(0); // 空港のレイヤーを取得

    // 1. 検索ウィジェットの作成
    var searchWidget = new Search({
      // 2. ウィジェットのプロパティを設定
      view: view,
      sources: [{ // 検索ソースに空港のレイヤーを追加し、名称と愛称で検索できるように設定
        featureLayer: {
          url: airportPoint.url,
          popupTemplate: airportPoint.popupTemplate
        },
        searchFields: ["NAME", "NICKNAME"],
        displayField: "NAME",
        exactMatch: false,
        name: "空港検索",
        placeholder: "空港名",
        suggestionsEnabled: true
      }]
    });

    // 1. 凡例ウィジェットの作成
    // TODO: 凡例ウィジェットを作成して view に追加してみよう





    // 3. ウィジェットを view の UI へ追加
    view.ui.add(searchWidget, "top-right");
  });
});
