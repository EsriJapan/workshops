﻿using Esri.ArcGISRuntime;
using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Mapping.FeatureForms;
using Esri.ArcGISRuntime.Portal;
using Esri.ArcGISRuntime.UI.Controls;
using System.IO;
using System.Windows;
using System.Windows.Media;

namespace ArcGisNativeSdkHandsOn;

public partial class MainWindow : Window
{
    /*--手順3-3: ポータルとアイテム Id を設定する Start--*/
    private static readonly Uri PortalUri = new("https://www.arcgis.com");

    private const string WebMapItemId = "37cab848879c46c6aa364aed5ed8c967";
    /*--手順3-3: ポータルとアイテム Id を設定する End--*/

    /*--手順6-1: MMPK を読み込む Start--*/
    // 出力フォルダーへコピーされる MMPK の相対パス。
    private static readonly string MmpkPath = Path.Combine(AppContext.BaseDirectory,"Data","HandsonMap.mmpk");
    /*--手順6-1: MMPK を読み込む End--*/

    private MobileMapPackage? _mobileMapPackage;

    private ArcGISFeature? _selectedFeature;
    private FeatureLayer? _selectedFeatureLayer;

    private bool _isOnlineMode;
    private bool _isBusy;

    public MainWindow()
    {
        InitializeComponent();

        Loaded += MainWindow_Loaded;
        Closed += MainWindow_Closed;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        // Web Map を読み込む
        await OpenOnlineMapAsync();
    }

    /// <summary>
    /// Portal item からオンラインの Web マップを読み込みます。
    /// </summary>
    private async Task OpenOnlineMapAsync()
    {
        if (_isBusy)
        {
            return;
        }

        try
        {
            SetBusy(true, "オンライン地図を読み込んでいます...");

            ClearSelectedFeature();

            if (WebMapItemId == "YourWebMapItemId" || string.IsNullOrWhiteSpace(WebMapItemId))
            {
                throw new InvalidOperationException(
                    "MainWindow.xaml.cs の WebMapItemId を、" +
                    "使用する Web マップの Item ID に変更してください。");
            }

            /*--手順3-4: MapView コントローラーに Web マップを設定 Start--*/
            ArcGISPortal portal = await ArcGISPortal.CreateAsync(PortalUri);

            PortalItem portalItem = await PortalItem.CreateAsync(portal, WebMapItemId);

            Map onlineMap = new(portalItem);

            await onlineMap.LoadAsync();

            if (onlineMap.LoadStatus != LoadStatus.Loaded)
            {
                throw onlineMap.LoadError ??
                      new InvalidOperationException("Web マップを読み込めませんでした。");
            }

            MyMapView.Map = onlineMap;
            /*--手順3-4: MapView コントローラーに Web マップを設定 End--*/

            _isOnlineMode = true;

            SetMode( "オンライン", Color.FromRgb(22, 163, 74));

            FeatureHelpText.Text = "編集するフィーチャを地図上でクリックしてください。";

            StatusText.Text = $"オンライン Web マップを読み込みました: {onlineMap.Item?.Title}";
        }
        catch (Exception exception)
        {
            _isOnlineMode = false;

            SetMode(
                "オンライン地図の読み込み失敗",
                Color.FromRgb(220, 38, 38));

            ShowError(
                "オンライン地図を読み込めませんでした。",
                exception);
        }
        finally
        {
            SetBusy(false);
        }
    }

    /// <summary>
    /// 配布済みの MMPK をローカルファイルから読み込みます。
    /// </summary>
    private async Task OpenOfflineMapAsync()
    {
        if (_isBusy)
        {
            return;
        }

        try
        {
            SetBusy(true, "MMPK を読み込んでいます...");

            ClearSelectedFeature();

            if (!File.Exists(MmpkPath))
            {
                throw new FileNotFoundException(
                    "MMPK が見つかりません。" +
                    Environment.NewLine +
                    "次の場所へファイルを配置してください。" +
                    Environment.NewLine +
                    MmpkPath,
                    MmpkPath);
            }

            _mobileMapPackage?.Close();
            _mobileMapPackage = null;

            /*--手順6-2 モバイル マップ パッケージを表示する Start--*/
            _mobileMapPackage = await MobileMapPackage.OpenAsync(MmpkPath);
            await _mobileMapPackage.LoadAsync();

            // エラー表示
            if (_mobileMapPackage.LoadStatus != LoadStatus.Loaded)
            {
                throw _mobileMapPackage.LoadError ??
                      new InvalidOperationException("MMPK を読み込めませんでした。");
            }

            //mmpk に含まれるマップを取得
            Map? offlineMap = _mobileMapPackage.Maps.FirstOrDefault();

            // エラー表示
            if (offlineMap is null)
            {
                throw new InvalidOperationException(
                    "MMPK に表示可能なマップが含まれていません。");
            }

            //マップビューにオフライン マップを設定
            MyMapView.Map = offlineMap;
            /*--手順6-2 モバイル マップ パッケージを表示する End--*/

            _isOnlineMode = false;

            SetMode( "オフライン MMPK", Color.FromRgb(37, 99, 235));

            FeatureHelpText.Text =
                "オフライン地図を表示しています。" +
                "このサンプルでは MMPK の属性編集は行いません。";

            StatusText.Text =
                $"MMPK を読み込みました: {Path.GetFileName(MmpkPath)}";
        }
        catch (Exception exception)
        {
            _isOnlineMode = false;

            SetMode(
                "MMPK の読み込み失敗",
                Color.FromRgb(220, 38, 38));

            ShowError(
                "MMPK を読み込めませんでした。",
                exception);
        }
        finally
        {
            SetBusy(false);
        }
    }

    /// <summary>
    /// 地図上でクリックされたフィーチャを識別します。
    /// </summary>
    private async void MyMapView_GeoViewTapped(object sender, GeoViewInputEventArgs e)
    {
        if (_isBusy || MyMapView.Map is null)
        {
            return;
        }

        try
        {
            SetBusy(true, "フィーチャを検索しています...");

            ClearSelectedFeature();

            /*--手順4-2 クリックされたフィーチャを識別 Start--*/
            IReadOnlyList<IdentifyLayerResult> identifyResults =
                await MyMapView.IdentifyLayersAsync(
                    e.Position,
                    tolerance: 12, // 
                    returnPopupsOnly: false);

            (ArcGISFeature? feature, FeatureLayer? layer) =
                FindFirstFeature(identifyResults);

            if (feature is null || layer is null)
            {
                StatusText.Text =
                    "クリックした位置にフィーチャはありません。";

                FeatureHelpText.Text =
                    "別のフィーチャをクリックしてください。";

                return;
            }

            await feature.LoadAsync();

            _selectedFeature = feature;
            _selectedFeatureLayer = layer;

            _selectedFeatureLayer.SelectFeature(_selectedFeature);

            ShowFeatureForm(feature, layer, isEditable: _isOnlineMode);
            /*--手順4-2 クリックされたフィーチャを識別 End--*/
        }
        catch (Exception exception)
        {
            ShowError(
                "フィーチャの属性を取得できませんでした。",
                exception);
        }
        finally
        {
            SetBusy(false);
        }
    }

    private void ShowFeatureForm(ArcGISFeature feature, FeatureLayer layer, bool isEditable)
    {
        /*--手順4-3: FeatureForm を作成して、パネルに設定 Start--*/
        FeatureForm featureForm = new(feature);

        FeatureFormViewPanel.FeatureForm = featureForm;

        NoFeatureText.Visibility = Visibility.Collapsed;

        FeatureFormViewPanel.Visibility = Visibility.Visible;
        /*--手順4-3: FeatureForm を作成して、パネルに設定 End--*/
        /*--手順5-1: 編集可能なフィーチャを選択時にボタンを表示する Start--*/
        if (isEditable)
        {
            EditButtonsPanel.Visibility = Visibility.Visible;

            SaveButton.IsEnabled = true;
            DiscardButton.IsEnabled = true;

            FeatureHelpText.Text = $"「{GetLayerDisplayName(layer)}」の属性を編集中です。";

            StatusText.Text = $"オンライン フィーチャを選択しました: " + GetLayerDisplayName(layer);
        }
        /*--手順5-1: 編集可能なフィーチャを選択時にボタンを表示する End--*/
        /*--手順6-3: MMPK のフィーチャを選択した場合 Start--*/
        else
        {
            // MMPK では保存操作を提供しない
            EditButtonsPanel.Visibility = Visibility.Collapsed;

            SaveButton.IsEnabled = false;
            DiscardButton.IsEnabled = false;

            FeatureHelpText.Text =
                $"「{GetLayerDisplayName(layer)}」の属性を表示しています。" +
                "このフィーチャの編集内容を保存できません。";

            StatusText.Text =
                $"編集不可のフィーチャを選択しました: " +
                GetLayerDisplayName(layer);
        }
        /*--手順6-3: MMPK のフィーチャを選択した場合 End--*/
    }

    private static string GetLayerDisplayName(FeatureLayer layer)
    {
        return string.IsNullOrWhiteSpace(layer.Name)
        ? "名称未設定のレイヤー"
        : layer.Name;
    }

    /// <summary>
    /// Identify の結果を再帰的に調べ、
    /// 最初の ArcGISFeature と FeatureLayer を返します。
    /// </summary>
    private static (ArcGISFeature? Feature, FeatureLayer? Layer)FindFirstFeature
        (IEnumerable<IdentifyLayerResult> results)
    {
        foreach (IdentifyLayerResult result in results)
        {
            FeatureLayer? featureLayer = result.LayerContent as FeatureLayer;

            ArcGISFeature? feature = result.GeoElements.OfType<ArcGISFeature>().FirstOrDefault();

            if (feature is not null && featureLayer is not null)
            {
                return (feature, featureLayer);
            }

            (ArcGISFeature? sublayerFeature,FeatureLayer? sublayer) = FindFirstFeature(result.SublayerResults);

            if (sublayerFeature is not null && sublayer is not null)
            {
                return (sublayerFeature, sublayer);
            }
        }

        return (null, null);
    }

    /// <summary>
    /// FeatureForm の編集内容を確定し、
    /// Feature Service へ変更を反映します。
    /// </summary>
    private async void SaveButton_Click(object sender, RoutedEventArgs e)
    {
        if (_isBusy ||
            !_isOnlineMode ||
            _selectedFeature is null)
        {
            return;
        }

        try
        {
            SetBusy(true, "変更を保存しています...");

            /*--手順5-2: FeatureForm の編集内容を確定 Start--*/
            bool formSaved = await FeatureFormViewPanel.FinishEditingAsync(requireAllErrorsResolved: true);

            if (!formSaved)
            {
                StatusText.Text =
                    "入力内容にエラーがあります。表示された項目を修正してください。";

                return;
            }

            if (_selectedFeature.FeatureTable is not ServiceFeatureTable serviceFeatureTable)
            {
                throw new InvalidOperationException(
                    "選択したフィーチャは " +
                    "ServiceFeatureTable に属していません。");
            }

            ServiceGeodatabase? serviceGeodatabase = serviceFeatureTable.ServiceGeodatabase;

            if (serviceGeodatabase?.ServiceInfo?.CanUseServiceGeodatabaseApplyEdits == true)
            {
                await serviceGeodatabase.ApplyEditsAsync();
            }
            else
            {
                await serviceFeatureTable.ApplyEditsAsync();
            }

            StatusText.Text = "編集内容をオンラインサービスへ反映しました。";

            MessageBox.Show(
                "編集内容をオンラインサービスへ反映しました。",
                "保存完了",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            ClearSelectedFeature();
            /*--手順5-2: FeatureForm の編集内容を確定 End--*/
        }
        catch (Exception exception)
        {
            ShowError(
                "編集内容を保存できませんでした。",
                exception);
        }
        finally
        {
            SetBusy(false);
        }
    }

    /// <summary>
    /// FeatureForm 上の未確定編集を破棄します。
    ///
    /// FinishEditingAsync を実行する前の変更は FeatureForm 内に保持されているため、フォームを閉じることで破棄します。
    /// </summary>
    private void DiscardButton_Click( object sender, RoutedEventArgs e)
    {
        ClearSelectedFeature();

        StatusText.Text = "入力中の変更を破棄しました。";
    }

    private async void OpenOnlineMapButton_Click(object sender, RoutedEventArgs e)
    {
        await OpenOnlineMapAsync();
    }

    private async void OpenOfflineMapButton_Click(object sender, RoutedEventArgs e)
    {
        await OpenOfflineMapAsync();
    }

    /// <summary>
    /// 選択表示と編集フォームをクリア
    /// </summary>
    private void ClearSelectedFeature()
    {
        /*--手順4-4: 選択されたフィーチャをクリア Start--*/
        if (_selectedFeatureLayer is not null && _selectedFeature is not null)
        {
            _selectedFeatureLayer.UnselectFeature(_selectedFeature);
        }

        _selectedFeature = null;
        _selectedFeatureLayer = null;

        FeatureFormViewPanel.FeatureForm = null;

        FeatureFormViewPanel.Visibility = Visibility.Collapsed;

        NoFeatureText.Visibility = Visibility.Visible;

        EditButtonsPanel.Visibility = Visibility.Collapsed;
        /*--手順4-4: 選択されたフィーチャをクリア End--*/

        /*--手順5-3: 編集ボタンを無効化 Start--*/
        SaveButton.IsEnabled = false;
        DiscardButton.IsEnabled = false;
        /*--手順5-3: 編集ボタンを無効化 End--*/
    }


    private void SetBusy( bool isBusy, string? message = null)
    {
        _isBusy = isBusy;

        BusyPanel.Visibility =
            isBusy
                ? Visibility.Visible
                : Visibility.Collapsed;

        OpenOnlineMapButton.IsEnabled = !isBusy;
        OpenOfflineMapButton.IsEnabled = !isBusy;

        if (!string.IsNullOrWhiteSpace(message))
        {
            StatusText.Text = message;
        }
    }

    private void SetMode(
        string mode,
        Color indicatorColor)
    {
        ModeText.Text = mode;
        ModeIndicator.Fill =
            new SolidColorBrush(indicatorColor);
    }

    private void ShowError(
        string message,
        Exception exception)
    {
        StatusText.Text = message;

        MessageBox.Show(
            $"{message}\n\n{exception.Message}",
            "エラー",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
    }

    private void MainWindow_Closed(
        object? sender,
        EventArgs e)
    {
        _mobileMapPackage?.Close();
        _mobileMapPackage = null;
    }
}