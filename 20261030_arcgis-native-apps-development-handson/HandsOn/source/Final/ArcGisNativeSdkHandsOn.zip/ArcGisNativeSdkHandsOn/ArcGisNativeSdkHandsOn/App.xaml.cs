﻿using Esri.ArcGISRuntime;
using System.Windows;
 
namespace ArcGisNativeSdkHandsOn;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        try
        {
            ArcGISRuntimeEnvironment.Initialize();

            /*--手順2: API キーを入力--*/
            const string apiKey = "YourApiKey";

            if (!string.IsNullOrWhiteSpace(apiKey) &&
            apiKey != "YourApiKey")
            {
                ArcGISRuntimeEnvironment.ApiKey = apiKey;
            }
        }
        catch (Exception exception)
        {
            MessageBox.Show(
            $"ArcGIS Maps SDK の初期化に失敗しました。\n\n{exception.Message}",
            "初期化エラー",
            MessageBoxButton.OK,
            MessageBoxImage.Error);

            Shutdown();
        }
    }
}
