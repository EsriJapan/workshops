﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    internal class NewMapTool : MapTool
    {
        public NewMapTool()
        {
            IsSketchTool = true;
            // ポリゴンをスケッチする
            SketchType = SketchGeometryType.Polygon;
            SketchOutputMode = SketchOutputMode.Map;
        }

        protected override Task OnToolActivateAsync(bool active)
        {
            return base.OnToolActivateAsync(active);
        }

        protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
        {
            return QueuedTask.Run(() =>
            {
                // 現在のプロジェクトを取得
                var project = Project.Current;

                // アクティブなマップ ビューを取得
                var mapView = MapView.Active;

                // スケッチしたポリゴンと交差するフィーチャを取得
                var results = mapView.GetFeatures(geometry);

                // フィーチャを選択
                mapView.SelectFeatures(geometry);

                // 選択されたフィーチャに 3秒かけてズーム
                MapView.Active.ZoomToSelected(new TimeSpan(0, 0, 3), true);

                // プロジェクト、マップ、レイヤーの名称と取得したフィーチャの件数のメッセージを作成
                var sb = new StringBuilder();
                sb.AppendLine(String.Format("プロジェクト名:{0}", project.Name));
                sb.AppendLine(String.Format("マップ名:{0}", mapView.Map.Name));
                sb.AppendLine(String.Format("レイヤー名:{0}", String.Format(String.Join("\n", results.ToDictionary().Select(kvp => String.Format("{0}", kvp.Key.Name))))));
                sb.AppendLine(String.Format("フィーチャ数:{0}", String.Format(String.Join("\n", results.ToDictionary().Select(kvp => String.Format("{0}", kvp.Value.Count()))))));

                // メッセージを出力
                MessageBox.Show(sb.ToString(), "結果");

                // 取得したフィーチャをフラッシュ
                mapView.FlashFeature(results);

                return true;
            });
        }
    }
}
