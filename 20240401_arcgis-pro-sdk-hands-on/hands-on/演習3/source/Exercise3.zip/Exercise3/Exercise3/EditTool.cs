﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Exercise3
{
    internal class EditTool : MapTool
    {
        public EditTool()
        {
            IsSketchTool = true;
            UseSnapping = true;
            SketchType = SketchGeometryType.Polygon;
        }

        /// <summary>
        /// Called when the sketch finishes. This is where we will create the sketch operation and then execute it.
        /// </summary>
        /// <param name="geometry">The geometry created by the sketch.</param>
        /// <returns>A Task returning a Boolean indicating if the sketch complete event was successfully handled.</returns>
        protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
        {
            if (CurrentTemplate == null || geometry == null)
                return Task.FromResult(false);

            // バッファーの距離
            var BufferDistance = 0.03;

            return QueuedTask.Run(() =>
            {
                // 作図したジオメトリからバッファーを作成
                Geometry bufferedGeometry = GeometryEngine.Instance.Buffer(geometry, BufferDistance);

                // アクティブなマップを取得
                Map map = MapView.Active.Map;

                // 「Japan」レイヤーを取得
                FeatureLayer lyr = map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == "Japan");

                // フィーチャクラスの Shape フィールドを取得
                string shapeField = lyr.GetFeatureClass().GetDefinition().GetShapeField();

                // ジオメトリの属性値設定
                var attributes = new Dictionary<string, object>();
                attributes.Add(shapeField, bufferedGeometry);  // shape フィールドにジオメトリ設定
                attributes.Add("KEN", "TEST");                 // KEN フィールドに値を設定

                // エディット オペレーションを作成
                var createOperation = new EditOperation();

                // ジオメトリの作成
                createOperation.Create(lyr, attributes);

                // 作図完了
                return createOperation.ExecuteAsync();
            });
        }
    }
}
