﻿using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Mapping;
using System;

namespace Exercise1
{
    internal class TestAddinButton : Button
    {
        protected async override void OnClick()
        {
            // 属性検索 (ジオプロセシング ツール) を実行
            await Geoprocessing.ExecuteToolAsync("SelectLayerByAttribute_management",
                                                  new string[] { "Japan", "NEW_SELECTION", "KEN = '神奈川県'" });

            // 選択されたフィーチャに 3秒かけてズーム
            MapView.Active.ZoomToSelectedAsync(new TimeSpan(0, 0, 3), true);
        }
    }
}
