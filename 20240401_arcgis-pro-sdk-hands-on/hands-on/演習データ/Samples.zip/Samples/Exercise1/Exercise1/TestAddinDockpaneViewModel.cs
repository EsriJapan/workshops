﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Linq;
using System.Windows.Input;


namespace Exercise1
{
    internal class TestAddinDockpaneViewModel : DockPane
    {
        private const string _dockPaneID = "Exercise1_TestAddinDockpane";
        public ICommand HookTest { get; set; }

        protected TestAddinDockpaneViewModel() { HookTest = new RelayCommand(() => HookButtonClick(), () => true); }

        private void HookButtonClick()
        {
            QueuedTask.Run(() =>
            {
                // 「Japan」レイヤーを選択
                var layers = MapView.Active.Map.FindLayers("Japan").OfType<FeatureLayer>().ToList();
                layers[0].Select();

                // 選択されたフィーチャに 3秒かけてズーム
                MapView.Active.ZoomToSelected(new TimeSpan(0, 0, 3), true);
            });
        }

        /// <summary>
        /// Show the DockPane.
        /// </summary>
        internal static void Show()
        {
            DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
            if (pane == null)
                return;

            pane.Activate();
        }

        /// <summary>
        /// Text shown near the top of the DockPane.
        /// </summary>
        private string _heading = "My DockPane";
        public string Heading
        {
            get => _heading;
            set => SetProperty(ref _heading, value);
        }
    }

    /// <summary>
    /// Button implementation to show the DockPane.
    /// </summary>
    internal class TestAddinDockpane_ShowButton : Button
    {
        protected override void OnClick()
        {
            TestAddinDockpaneViewModel.Show();
        }
    }
}
