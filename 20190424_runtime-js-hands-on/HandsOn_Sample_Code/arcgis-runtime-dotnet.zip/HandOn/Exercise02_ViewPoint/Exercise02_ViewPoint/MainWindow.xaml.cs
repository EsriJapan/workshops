﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Geometry;


namespace Exercise02_ViewPoint
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        // 中心ポイント
        private MapPoint _point = new MapPoint(139.74543, 35.658581, SpatialReferences.Wgs84);

        // スケール
        private double _scale = 1000;

        // ポリゴン
        private Polygon _polygon = new Polygon(new List<MapPoint> {
            (new MapPoint(139.755904, 35.676466)),
            (new MapPoint(139.753243, 35.672283)),
            (new MapPoint(139.755947, 35.671063)),
            (new MapPoint(139.759123, 35.674932))
        }, SpatialReferences.Wgs84);


        public MainWindow()
        {
            InitializeComponent();
            Initialize();

        }

        /// <summary>
        /// マップの作成
        /// </summary>
        public void Initialize()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;
        }

        /// <summary>
        /// ビューポイントの設定ボタンのクリック時
        /// </summary>
        private async void OnButtonClick(object sender, RoutedEventArgs e)
        {
            // クリックしたボタンのタイトルを取得する
            Button myButton = sender as Button;
            string selectedButtonTitle = myButton.Content.ToString();

            switch (selectedButtonTitle)
            {
                // 「エクステント」を選択
                case "エクステント":

                    // ポリゴン(_polygon)のエクステントにズームする
                    await MyMapView.SetViewpointGeometryAsync(_polygon);
                    break;


                // 「中心点とスケール」を選択
                case "中心点とスケール":

                    // 中心の座標(_point)とスケール(_scale)を指定してズームする
                    await MyMapView.SetViewpointCenterAsync(_point, _scale);
                    break;


                // 「アニメーション」を選択
                case "アニメーション":

                    // ポリゴン(_polygon)を指定してビューポイントを作成する
                    Viewpoint myViewPoint = new Viewpoint(_polygon);
                    // ビューポイントとアニメーションのタイムスパンを設定してズームする
                    await MyMapView.SetViewpointAsync(myViewPoint, TimeSpan.FromSeconds(5));
                    break;

                default:
                    break;
            }
        }

    }
}
