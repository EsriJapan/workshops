﻿using System.Windows;
using Esri.ArcGISRuntime.Mapping;


namespace Exercise01_DisplayMap
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Initialize();

        }

        /// <summary>
        /// マップの作成
        /// </summary>
        public void Initialize()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;
        }
    }
}
