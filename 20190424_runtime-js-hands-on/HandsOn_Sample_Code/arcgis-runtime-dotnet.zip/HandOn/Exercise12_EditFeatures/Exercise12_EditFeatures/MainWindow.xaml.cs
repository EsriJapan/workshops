﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Windows;
using Esri.ArcGISRuntime;
using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.UI.Controls;
using Esri.ArcGISRuntime.Geometry;

namespace Exercise12_EditFeatures
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        #region データソース
        // 編集用のポイント データ（編集結果の確認用マップ：https://www.arcgis.com/home/webmap/viewer.html?layers=fa6aaec5dc394933953bfb88d0f2341d）
        private string _featureLayerPath = "https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/runtime_edit_handson/FeatureServer/0";
        // アタッチメントに追加する画像ファイルのパス
        private string _attachmentFilePath = @"\data\image.jpg";
        #endregion

        private ServiceFeatureTable myServiceFeatureTable;

        public MainWindow()
        {
            InitializeComponent();
            Initialize();
        }

        /// <summary>
        /// マップの作成
        /// </summary>
        public void Initialize()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            DisplayLayers();
        }

        /// <summary>
        /// フィーチャ レイヤーの表示
        /// </summary>
        private async void DisplayLayers()
        {
            // フィーチャ サービスの URL を指定して、フィーチャ テーブル（ServiceFeatureTable）オブジェクトを作成する
            myServiceFeatureTable = new ServiceFeatureTable(new Uri(_featureLayerPath));

            // フィーチャ テーブルをロードする
            await myServiceFeatureTable.LoadAsync();

            // フィーチャ テーブルがロードされたら、検索ボタンを有効にする
            if (myServiceFeatureTable.LoadStatus == LoadStatus.Loaded)
            {
                // マップ ビューのタッチ イベントを登録する
                MyMapView.GeoViewTapped += OnMapViewTapped;
            }

            // フィーチャ テーブルからフィーチャ レイヤー（FeatureLayer）オブジェクトを作成する
            FeatureLayer featureLayer = new FeatureLayer(myServiceFeatureTable);

            // マップ オブジェクトの操作レイヤー（OperationalLayers）にフィーチャ レイヤーを追加する
            MyMapView.Map.OperationalLayers.Add(featureLayer);

        }


        /// <summary>
        /// フィーチャの追加
        /// </summary>
        private async void OnMapViewTapped(object sender, GeoViewInputEventArgs e)
        {
            // クリックした地点にポイントを追加する
            MapPoint mapClickPoint = e.Location;

            // フィーチャの属性情報のディクショナリ（フィールド名と属性値のペア）を作成する
            var attributes = new Dictionary<string, object>();
            attributes.Add("name", "テスト");

            // ジオメトリと属性情報から ArcGISFeature オブジェクトを作成する
            ArcGISFeature addedFeature = (ArcGISFeature)myServiceFeatureTable.CreateFeature(attributes, mapClickPoint);

            // アタッチメントに追加する画像ファイルをパスから取得する
            String imagePath = Directory.GetCurrentDirectory() + _attachmentFilePath;
            var fileBytes = File.ReadAllBytes(imagePath);

            // 作成したフィーチャのアタッチメントにファイルを追加する
            await addedFeature.AddAttachmentAsync("MyImage.jpg", @"image/jpg", fileBytes);

            // フィーチャをフィーチャ テーブルに追加する
            await myServiceFeatureTable.AddFeatureAsync(addedFeature);

            // 編集項目をフィーチャ テーブルに適用する
            IReadOnlyList<EditResult> results = await myServiceFeatureTable.ApplyEditsAsync();

            if (results[0].Error == null)
            {
                MessageBox.Show("フィーチャを追加しました", "編集結果");
            } else
            {
                MessageBox.Show("フィーチャの追加に失敗しました: " + results[0].Error.Message, "編集結果");

            }

        }

    }
}
