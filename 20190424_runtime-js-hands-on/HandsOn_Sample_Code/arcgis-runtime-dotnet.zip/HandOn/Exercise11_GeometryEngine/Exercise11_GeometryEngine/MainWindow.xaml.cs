﻿using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.UI;
using Esri.ArcGISRuntime.UI.Controls;
using System.Drawing;
using System.Windows;

namespace Exercise11_GeometryEngine
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        GraphicsOverlay myGraphicsOverlay;

        public MainWindow()
        {
            InitializeComponent();
            Initialize();
        }

        /// <summary>
        /// マップの作成
        /// </summary>
        public void Initialize()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            // バッファを表示するためのグラフィックス オーバーレイを作成する
            myGraphicsOverlay = new GraphicsOverlay();

            // MapView オブジェクトにグラフィックス オーバーレイを追加する
            MyMapView.GraphicsOverlays.Add(myGraphicsOverlay);

            // MapView のタッチ イベントを登録する
            MyMapView.GeoViewTapped += MyMapView_GeoViewTapped;

        }



        /// <summary>
        /// バッファー/測地線バッファーの作成
        /// </summary>
        private void MyMapView_GeoViewTapped(object sender, GeoViewInputEventArgs e)
        {
            // 画面上をタップした地点からバッファーの中心点のポイントを作成
            // ポイントの空間参照は Web メルカトル投影座標系（マップの空間参照が引き継がれる）
            MapPoint mapPoint = MyMapView.ScreenToLocation(e.Position);


            // バッファーの中心点のポイントと半径（メートル単位）を設定して、GeometryEngine の Buffer/BufferGeodetic（測地線バッファー）メソッドを実行
            // 半径の単位は中心点に指定するポイントの空間参照が使用される
            Geometry bufferGeometry = GeometryEngine.Buffer(mapPoint, 1000000);
            Geometry bufferGeometry_geodetic = GeometryEngine.BufferGeodetic(mapPoint, 1000000, LinearUnits.Meters);


            // バッファー（ポリゴン）のアウトラインを表示するためのシンプル ライン シンボルを作成
            SimpleLineSymbol simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle.Solid, Color.Gray, 1);
            SimpleLineSymbol simpleLineSymbol_geodetic = new SimpleLineSymbol(SimpleLineSymbolStyle.Dash, Color.Gray, 1);


            // バッファーの塗りつぶしシンボルを作成
            SimpleFillSymbol simpleFillSymbol = new SimpleFillSymbol(SimpleFillSymbolStyle.Solid, Color.FromArgb(100, (Color.Blue)), simpleLineSymbol);
            SimpleFillSymbol simpleFillSymbol_geodetic = new SimpleFillSymbol(SimpleFillSymbolStyle.Solid, Color.FromArgb(100, (Color.Red)), simpleLineSymbol_geodetic);


            // ジオメトリとシンボルを設定してバッファーのグラフィックを作成
            Graphic bufferGraphic = new Graphic(bufferGeometry, simpleFillSymbol);
            Graphic bufferGraphic_geodetic = new Graphic(bufferGeometry_geodetic, simpleFillSymbol_geodetic);

            // グラフィックをグラフィックス オーバーレイに追加
            myGraphicsOverlay.Graphics.Add(bufferGraphic);
            myGraphicsOverlay.Graphics.Add(bufferGraphic_geodetic);

            // バッファーの中心点を表示するためのシンプル マーカー シンボルを作成
            SimpleMarkerSymbol simpleMarkerSymbol = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle.Cross, Color.Black, 5);

            // ジオメトリとシンボルを設定してバッファーの中心点のグラフィックを作成
            Graphic centerGraphic = new Graphic(mapPoint, simpleMarkerSymbol);

            // グラフィックをグラフィックス オーバーレイに追加
            myGraphicsOverlay.Graphics.Add(centerGraphic);
 
        }

     
        
    }
}
