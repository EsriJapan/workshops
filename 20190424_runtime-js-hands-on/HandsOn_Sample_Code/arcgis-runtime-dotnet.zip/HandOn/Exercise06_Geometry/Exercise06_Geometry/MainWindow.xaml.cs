﻿using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.UI;

using System;
using System.Drawing;
using System.Windows;

namespace Exercise06_Geometry
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        GraphicsOverlay myGraphicsOverlay;

        public MainWindow()
        {
            InitializeComponent();
            Initialize();

        }

        /// <summary>
        /// マップの作成
        /// </summary>
        public void Initialize()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する

            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Esri.ArcGISRuntime.Mapping.Basemap.CreateStreets());

            // 緯度、経度、スケールのパラメータを設定して、マップの初期表示位置を指定する
            Viewpoint initialViewpoint = new Viewpoint(35.673797, 139.756033, 10000);
            myMap.InitialViewpoint = initialViewpoint;

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            // グラフィックス オーバーレイ オブジェクトの作成
            myGraphicsOverlay = new GraphicsOverlay();

            // MapView オブジェクトにグラフィックス オーバーレイを追加する
            MyMapView.GraphicsOverlays.Add(myGraphicsOverlay);

            // ジオメトリの作成
            CreateGeometry_Polygon();
            CreateGeometry_Polyline();
            CreateGeometry_Point();
        }


        /// <summary>
        /// ポイントの作成
        /// </summary>
        public void CreateGeometry_Point()
        {

            // ポイント ジオメトリの作成
            MapPoint point = new MapPoint(139.756033, 35.673797, SpatialReferences.Wgs84);

            // シンボルの作成
            SimpleMarkerSymbol symbol = new SimpleMarkerSymbol()
            {
                Color = Color.Red,
                Size = 10,
                Style = SimpleMarkerSymbolStyle.Circle
            };

            // グラフィックの作成
            Graphic pointGraphic = new Graphic(point, symbol);

            // グラフィックス オーバーレイにグラフィックを追加
            myGraphicsOverlay.Graphics.Add(pointGraphic);

        }


        /// <summary>
        /// ポリラインの作成
        /// </summary>
        public void CreateGeometry_Polyline()
        {

            // ポリラインの作成
            PointCollection polylinePoints = new PointCollection(SpatialReferences.Wgs84)
            {
                new MapPoint(139.755904, 35.676466),
                new MapPoint(139.753243, 35.672283),
                new MapPoint(139.755947, 35.671063),
                new MapPoint(139.759123, 35.674932)
            };

            Polyline polyline = new Polyline(polylinePoints);

            // シンボルの作成
            SimpleLineSymbol symbol = new SimpleLineSymbol(
                SimpleLineSymbolStyle.Dash,
                Color.Red,
                4
            );

            // グラフィックの作成 
            Graphic polylineGraphic = new Graphic(polyline, symbol);

            // グラフィックス オーバーレイにグラフィックを追加
            myGraphicsOverlay.Graphics.Add(polylineGraphic);

        }

        /// <summary>
        /// ポリゴンの作成
        /// </summary>
        public void CreateGeometry_Polygon()
        {
      
            // ポリゴンの作成（GeometryBuilder を使用）
            PolygonBuilder builder = new PolygonBuilder(SpatialReferences.Wgs84);
            builder.AddPoint(new MapPoint(139.755904, 35.676466));
            builder.AddPoint(new MapPoint(139.753243, 35.672283));
            builder.AddPoint(new MapPoint(139.755947, 35.671063));
            builder.AddPoint(new MapPoint(139.759123, 35.674932));
            Polygon polygon = builder.ToGeometry();

            // シンボルの作成
            SimpleFillSymbol symbol = new SimpleFillSymbol(
                SimpleFillSymbolStyle.Solid,
                Color.FromArgb(100, (Color.Blue)),
                null);

            // グラフィックの作成
            Graphic polygonGraphic = new Graphic(polygon, symbol);

            // グラフィックス オーバーレイにグラフィックを追加
            myGraphicsOverlay.Graphics.Add(polygonGraphic);
        }

    }
}
