﻿using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.Mapping;
using System;
using System.IO;
using System.Windows;



namespace Exercise05_Label
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        #region データソース
        // 市区町村界のデータ（データの概要：https://www.arcgis.com/home/item.html?id=1b663a51d8684f90a7bbd2795baa2b53）
        private string _featureLayerPath = "https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/all_Japan_shikuchoson/FeatureServer/0";
        private string jsonFileName = @"label_string.json";
        #endregion

        public MainWindow()
        {
            InitializeComponent();
            Initialize();
        }

        /// <summary>
        /// マップの作成
        /// </summary>
        public void Initialize()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // 緯度、経度、スケールのパラメータを設定して、マップの初期表示位置を指定する
            Viewpoint initialViewpoint = new Viewpoint(35.65858, 139.745433, 1000000);
            myMap.InitialViewpoint = initialViewpoint;

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            DisplayLayers();
        }

        /// <summary>
        /// フィーチャ レイヤーの表示
        /// </summary>
        private void DisplayLayers()
        {

            // フィーチャ サービスの URL を指定して、フィーチャ テーブル（ServiceFeatureTable）オブジェクトを作成する
            ServiceFeatureTable serviceFeatureTable = new ServiceFeatureTable(new Uri(_featureLayerPath));

            // フィーチャ テーブルからフィーチャ レイヤー（FeatureLayer）オブジェクトを作成する
            FeatureLayer featureLayer = new FeatureLayer(serviceFeatureTable);

            // マップ オブジェクトの操作レイヤー（OperationalLayers）にフィーチャ レイヤーを追加する
            MyMapView.Map.OperationalLayers.Add(featureLayer);

            // JSON 文字列からラベル定義を作成してフィーチャ レイヤーに適用
            LabelDefinition definiton = createLabeldefinition();
            featureLayer.LabelDefinitions.Add(definiton);
            featureLayer.LabelsEnabled = true;

        }


        /// <summary>
        /// ラベル定義の作成
        /// </summary>
        public LabelDefinition createLabeldefinition()
        {
            string jsonString = "";

            // ラベル定義を記載した JSON ファイルから文字列を取得する
            using (StreamReader reader = new StreamReader(jsonFileName))
            {
                jsonString = reader.ReadToEnd();
            }

            // JSON 文字列からラベル定義オブジェクトを作成する
            LabelDefinition labelDefinition = LabelDefinition.FromJson(jsonString);

            return labelDefinition;
        }

    }
}
