﻿using Esri.ArcGISRuntime;
using Esri.ArcGISRuntime.Mapping;
using System.Threading;
using System.Windows;



namespace Exercise07_LoadablePattern
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Initialize();
        }


        /// <summary>
        /// マップの作成
        /// </summary>
        public void Initialize()
        {
            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            // マップのロード ステータスの変更イベントを登録する
            myMap.LoadStatusChanged += OnMapsLoadStatusChanged;

        }


        /// <summary>
        /// マップのロード ステータスのチェック
        /// </summary>
        private void OnMapsLoadStatusChanged(object sender, LoadStatusEventArgs e)
        {
            // マップのロード ステータスが変更される毎にラベルを更新する
            Dispatcher.BeginInvoke(
                new ThreadStart(() =>
                loadStatusLabel.Content = string.Format("マップのロード ステータス : {0}", e.Status.ToString())
            ));
        }
    }
}
