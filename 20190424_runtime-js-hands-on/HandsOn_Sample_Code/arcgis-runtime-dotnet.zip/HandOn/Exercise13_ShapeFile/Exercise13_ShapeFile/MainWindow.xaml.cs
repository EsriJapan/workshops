﻿using System.Windows;
using System.Collections.Generic;

using Esri.ArcGISRuntime;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.UI.Controls;
using Esri.ArcGISRuntime.Geometry;


namespace Exercise13_ShapeFile
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        #region データソース
        // シェープファイルのパス
        private string _shapfileFilePath = @"data\\point_layer.shp";
        #endregion

        private ShapefileFeatureTable myShapefileFeatureTable;

        public MainWindow()
        {
            InitializeComponent();
            Initialize();
        }

        private void Initialize()
        {

            // MainWindow.xaml に名前空間参照を追加し、MapView (MyMapView) を定義する
            // Map オブジェクトをベースマップ（ArcGIS Online の道路地図）を指定して作成する
            Map myMap = new Map(Basemap.CreateStreets());

            // Map オブジェクトを MapView にセットする
            MyMapView.Map = myMap;

            DisplayLayers();

        }

        /// <summary>
        /// フィーチャ レイヤー（シェープファイル）の表示
        /// </summary>
        private async void DisplayLayers()
        {
            // シェープファイルのパスを指定して、フィーチャ テーブル（ShapefileFeatureTable）オブジェクトを作成する
            myShapefileFeatureTable = await ShapefileFeatureTable.OpenAsync(_shapfileFilePath);

            // フィーチャ テーブルをロードする
            await myShapefileFeatureTable.LoadAsync();

            // フィーチャ テーブルがロードされたら、検索ボタンを有効にする
            if (myShapefileFeatureTable.LoadStatus == LoadStatus.Loaded)
            {
                // マップ ビューのタッチ イベントを登録する
                MyMapView.GeoViewTapped += OnMapViewTapped;
            }

            // フィーチャ テーブルからフィーチャ レイヤー（FeatureLayer）オブジェクトを作成する
            FeatureLayer featureLayer = new FeatureLayer(myShapefileFeatureTable);

            // マップ オブジェクトの操作レイヤー（OperationalLayers）にフィーチャ レイヤーを追加する
            MyMapView.Map.OperationalLayers.Add(featureLayer);

        }

        /// <summary>
        /// フィーチャの追加
        /// </summary>
        private async void OnMapViewTapped(object sender, GeoViewInputEventArgs e)
        {
            // クリックした地点にポイントを追加する
            MapPoint mapClickPoint = e.Location;

            // フィーチャの属性情報のディクショナリ（フィールド名と属性値のペア）を作成する
            var attributes = new Dictionary<string, object>();
            attributes.Add("name", "テスト");

            // ジオメトリと属性情報から Feature オブジェクトを作成する
            Feature addedFeature = myShapefileFeatureTable.CreateFeature(attributes, mapClickPoint);

            // フィーチャをフィーチャ テーブルに追加する
            await myShapefileFeatureTable.AddFeatureAsync(addedFeature);

            MessageBox.Show("フィーチャを追加しました", "編集結果");

        }
    }
}
