require([
  "esri/Map",
  "esri/views/MapView",
  "esri/tasks/QueryTask",
  "esri/tasks/support/Query",
  "esri/Graphic"
], function(Map, MapView, QueryTask, Query, Graphic) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.77, 35.68],
    zoom: 8
  });

  // ボタンのクリック イベントにクエリを実行する関数を登録
  document.getElementById("searcbtn").addEventListener("click", execQuery);

  /**
   *
   * ステップ２：クエリの実行
   *
   **/

  function execQuery() {
    // 既存のグラフィックを削除
    view.graphics.removeAll();

    // テキストボックスの入力値の取得
    const querystr = document.getElementById("searchtext").value;

    if (querystr.length > 0) {
      /**
       *
       * ステップ２－１：クエリ タスクの作成
       * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-QueryTask.html
       *
       **/

      // TODO: 以下のサービスに対してクエリを実行するタスクを作成
      const url = "https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/all_Japan_shikuchoson/FeatureServer/0";
      const queryTask = new QueryTask({
        url: url
      });

      /**
       *
       * ステップ２－２：クエリ パラメーターの作成
       * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-support-Query.html
       *
       **/

      // TODO: クエリ パラメーターの作成
      // [KEN] フィールドの値が入力値と一致するフィーチャをクエリするパラメーターを作成
      const query = new Query();
      query.where = "KEN = '" + querystr + "'"; // [KEN] フィールドの値をクエリする where 句
      query.returnGeometry = true;  // 結果を表示するのでジオメトリを返すオプションを設定

      /**
       *
       * ステップ２－３：クエリの実行
       *
       **/

      // TODO: クエリの実行
      // クエリを実行して結果を view に表示（showResult 関数を実行）
      queryTask.execute(query)
        .then(showResult)
        .catch(showErr);
    }
  }

  /**
   *
   * ステップ３：結果の表示
   *
   **/

  // クエリの結果を表示
  function showResult(featureSet) {
    // 取得したフィーチャからグラフィックを作成
    const graphics = featureSet.features.map(function(item) {
      return new Graphic({
        geometry: item.geometry,
        symbol: {
          type: "simple-fill",
          color: [77, 77, 255, 0.6],
          outline: {
            color: [255, 255, 255],
            width: 2
          }
        }
      });
    });
    // グラフィックを view に追加
    view.graphics.addMany(graphics);
    // グラフィックへズーム
    view.goTo(graphics);
  }

  // エラー
  function showErr(e) {
    console.log(e);
  }
});
