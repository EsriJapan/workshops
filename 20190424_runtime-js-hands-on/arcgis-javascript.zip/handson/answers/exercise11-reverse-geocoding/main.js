require([
  "esri/Map",
  "esri/views/MapView",
  "esri/tasks/Locator"
], function(Map, MapView, Locator) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.77, 35.68],
    zoom: 14
  });

  /**
   *
   * ステップ２：住所検索の実行（クリック地点の住所を取得）
   *
   **/

  /**
   *
   * ステップ２－１：ロケーターの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-Locator.html
   *
   **/

  // TODO: ロケーターの作成
  // 以下のサービスを使用して住所検索を行うロケーターを作成
  const url = "https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer";
  const locator = new Locator({
    url: url
  });

  // view のクリックで検索を実行
  view.on("click", location2address);

  function location2address(event) {
    /**
     *
     * ステップ２－２：検索の実行
     * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-Locator.html#locationToAddress
     *
     **/

    // クリック地点のジオメトリを取得
    const location = event.mapPoint;
    // 検索地点の許容値
    const distance = 5;

    // TODO: クリック地点の住所を取得
    // 住所検索を実行して結果をポップアップに表示（showResult 関数を実行）
    locator.locationToAddress(location, distance)
      .then(showResult)
      .catch(showErr);
  }

  /**
   *
   * ステップ２－３：結果の表示
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-support-AddressCandidate.html
   *
   **/

  // 結果の表示
  function showResult(result) {
    // 結果をポップアップに表示
    view.popup.open({
      title: "クリック地点の住所",
      content: result.address,
      location: result.location
    });
  }

  // エラー
  function showErr(e) {
    console.log(e);
  }  
});
