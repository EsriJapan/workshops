require([
  "esri/WebMap",
  "esri/views/MapView"
], function(WebMap, MapView) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  // Web マップの作成（最新の地震マップ (提供元: USGS)）
  // https://www.arcgis.com/home/item.html?id=890c0a4f1bd0434d8bad93e695b61042
  const webmap = new WebMap({
    portalItem: {
      id: "890c0a4f1bd0434d8bad93e695b61042"
    }
  });

  // View の作成
  const view = new MapView({
    container: "viewDiv",
    map: webmap
  });

  /**
   *
   * ステップ２：ロードステータスの監視
   * https://developers.arcgis.com/javascript/latest/guide/loadable/index.html
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-WebMap.html#loadStatus
   *
   **/

  // TODO: Web マップのロードステータス（loadStatus プロパティ）を監視
  // 変更された値を loadStatus 要素に表示
  webmap.watch("loadStatus", function(newValue) {
    // loadStatus 要素の更新
    const text = document.getElementById("loadStatus");
    text.textContent = newValue;
  });
});
