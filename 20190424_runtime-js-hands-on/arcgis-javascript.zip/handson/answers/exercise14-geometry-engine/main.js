require([
  "esri/Map",
  "esri/views/MapView",
  "esri/Graphic",
  "esri/geometry/geometryEngine"
], function(Map, MapView, Graphic, geometryEngine) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.77, 35.68],
    zoom: 14
  });

  /**
   *
   * ステップ２：ジオメトリ演算の実行（バッファーの作成）
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-geometry-geometryEngine.html#buffer
   *
   **/

  // クリック地点から任意の距離のバッファーを作成
  view.on("click", createBuffer);

  function createBuffer(event) {
    // 既存のグラフィックを削除
    view.graphics.removeAll();

    // TODO: バッファーの作成
    const buffer = geometryEngine.buffer(event.mapPoint, 500, "meters");

    // TODO: 結果の表示
    const graphic = new Graphic({
      geometry: buffer,
      symbol: {
        type: "simple-fill",
        color: [233, 163, 38, 0.5],
        outline: {
          color: [0, 0, 0, 0.5],
          width: 2
        }
      }
    });
    view.graphics.add(graphic);
  }
});
