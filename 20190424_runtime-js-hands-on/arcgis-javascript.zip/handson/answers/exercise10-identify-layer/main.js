require([
  "esri/Map",
  "esri/views/MapView",
  "esri/layers/TileLayer",
  "esri/tasks/IdentifyTask",
  "esri/tasks/support/IdentifyParameters"
], function(Map, MapView, TileLayer, IdentifyTask, IdentifyParameters) {
  /**
   *
   * ステップ１：マップの作成とレイヤーの表示
   *
   **/

  const tileLayer = new TileLayer({
    url: "https://services.arcgisonline.com/arcgis/rest/services/Specialty/Soil_Survey_Map/MapServer",
    opacity: 0.85
  });

  const map = new Map({
    basemap: "streets-vector",
    layers: [tileLayer]
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [-120.174, 47.255],
    zoom: 6
  });

  /**
   *
   * ステップ２：個別属性表示の実行
   *
   **/

  /**
   *
   * ステップ２－１：タスクの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-IdentifyTask.html
   *
   **/

  // TODO: タスクの作成
  // 以下のサービスに対して処理を実行するタスクを作成
  const url = "https://services.arcgisonline.com/arcgis/rest/services/Specialty/Soil_Survey_Map/MapServer";
  const identifyTask = new IdentifyTask({
    url: url
  });

  /**
   *
   * ステップ２－２：パラメーターの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-support-IdentifyParameters.html
   *
   **/

  // TODO: パラメーターの作成
  // 以下のオプションを使用して、タスクに設定するパラメーターを作成
  const options = {
    layerIds: [0, 1, 2],  // 対象のレイヤー ID
    tolerance: 3, // 検索地点の許容値
    width: view.width,  // view の幅
    height: view.height  // view の高さ
  };
  const params = new IdentifyParameters(options);

  // クリック地点の属性情報を取得
  view.on("click", executeIdentifyTask);

  function executeIdentifyTask(event) {
    // クリック地点のジオメトリをパラメーターに設定
    params.geometry = event.mapPoint;
    params.mapExtent = view.extent;

    /**
     *
     * ステップ２－３：タスクの実行
     *
     **/

    // TODO: タスクの実行
    // タスクを実行して取得した結果をポップアップに表示（showResult 関数を実行）
    identifyTask.execute(params)
      .then(showResult)
      .catch(showErr);
  }

  /**
   *
   * ステップ２－４：結果の表示
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-support-IdentifyResult.html
   *
   **/

  // 結果の表示
  function showResult(response) {
    // 結果のフィーチャにポップアップを定義
    const features = response.results.map(function(result) {
      const feature = result.feature;
      const layerName = result.layerName;
      feature.attributes.layerName = layerName;
      if (layerName === "Soil Survey Geographic") {
        feature.popupTemplate = {
          title: "{Map Unit Name}",
          content: "<b>Dominant order:</b> {Dominant Order} ({Dom. Cond. Order %}%)" +
            "<br><b>Dominant sub-order:</b> {Dominant Sub-Order} ({Dom. Cond. Suborder %}%)" +
            "<br><b>Dominant Drainage Class:</b> {Dom. Cond. Drainage Class} ({Dom. Cond. Drainage Class %}%)" +
            "<br><b>Farmland Class:</b> {Farmland Class}"
        };
      } else if (layerName === "State Soil Geographic") {
        feature.popupTemplate = {
          title: "{Map Unit Name}",
          content: "<b>Dominant order:</b> {Dominant Order} ({Dominant %}%)" +
            "<br><b>Dominant sub-order:</b> {Dominant Sub-Order} ({Dominant Sub-Order %}%)"
        };
      } else if (layerName === "Global Soil Regions") {
        feature.popupTemplate = {
          title: layerName,
          content: "<b>Dominant order:</b> {Dominant Order}" +
            "<br><b>Dominant sub-order:</b> {Dominant Sub-Order}"
        };
      }
      return feature;
    });

    // ポップアップの表示
    view.popup.open({
      features: features
    });
  }

  // エラー
  function showErr(err) {
    console.log(err);
  }
});
