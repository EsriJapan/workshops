require([
  /**
   *
   * ステップ１：モジュールの読み込み
   *
  **/
  // TODO: Map と MapView モジュールの読み込み
  "esri/Map",
  "esri/views/MapView"
], function(Map, MapView) {
  /**
   *
   * ステップ２：マップの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-Map.html
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-views-MapView.html
   *
   **/

  // TODO: Map の作成
  const map = new Map({
    basemap: "streets-vector"  // ベースマップ
  });

  // TODO: View の作成
  const view = new MapView({
    container: "viewDiv", // View を描画する要素
    map: map  // View に描画する Map オブジェクト
  });
});
