require([
  "esri/Map",
  "esri/views/MapView",
  "esri/layers/FeatureLayer"
], function(Map, MapView, FeatureLayer) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.77, 35.68],
    zoom: 8
  });

  /**
   *
   * ステップ２：フィーチャ レイヤーの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-layers-FeatureLayer.html
   *
   **/

  // TODO: 以下のサービスを参照するフィーチャ レイヤーを作成
  const url = "https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/all_Japan_shikuchoson/FeatureServer/0";
  const featureLayer = new FeatureLayer({
    url: url
  });

  // TODO: 作成したレイヤーを Map に追加
  map.add(featureLayer);

  /**
   *
   * ステップ３：Collection の利用
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-core-Collection.html
   *
   **/

  view.when(function() {
    // TODO: Map に含まれるレイヤーをコンソールに出力
    map.allLayers.forEach(function(layer) {
      console.log(layer.title);
    });
  });
});
