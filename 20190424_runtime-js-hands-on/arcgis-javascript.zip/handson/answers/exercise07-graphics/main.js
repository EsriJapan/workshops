require([
  "esri/Map",
  "esri/views/MapView",
  "esri/Graphic"
], function(Map, MapView, Graphic) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.756, 35.6738],
    zoom: 16
  });

  /**
   *
   * ステップ２：グラフィックの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-Graphic.html
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-geometry-Point.html
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-geometry-Polyline.html
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-geometry-Polygon.html
   *
   **/

  // ポイントの作成
  const point = {
    type: "point",  // Point の autocast
    x: 139.756033,
    y: 35.673797,
    spatialReferences: {wkid: 4326}
  };

  // ポイントのシンボルの作成
  const markerSymbol = {
    type: "simple-marker",  // SimpleMarkerSymbol の autocast
    color: [255, 0, 0]
  };

  // ポイントを表すグラフィックを作成
  const pointGraphic = new Graphic({
    geometry: point,
    symbol: markerSymbol
  });

  // TODO: ポリラインの作成
  // 以下の地点を通るポリラインを作成
  const paths = [
    [139.755904, 35.676466],
    [139.753243, 35.672283],
    [139.755947, 35.671063],
    [139.759123, 35.674932]
  ];

  const polyline = {
    type: "polyline", // Polyline の autocast
    paths: paths
  };

  // ポリラインのシンボルの作成
  const lineSymbol = {
    type: "simple-line",  // SimpleLineSymbol の autocast
    style: "dash",
    color: [255, 0, 0],
    width: 4
  };

  // ポリラインを表すグラフィックを作成
  const polylineGraphic = new Graphic({
    geometry: polyline,
    symbol: lineSymbol
  });

  // TODO: ポリゴンの作成
  // 以下の地点を囲むポリゴンを作成
  const rings = [
    [139.755904, 35.676466],
    [139.753243, 35.672283],
    [139.755947, 35.671063],
    [139.759123, 35.674932]
  ];

  const polygon = {
    type: "polygon", // Polygon のオートキャスト
    rings: rings
  };

  // ポリゴンのシンボルの作成
  const fillSymbol = {
    type: "simple-fill",  // SimpleFillSymbol のオートキャスト
    color: [0, 0, 255, 0.5],
    outline: {
      style: "none"
    }
  };

  // ポリゴンを表すグラフィックを作成
  const polygonGraphic = new Graphic({
    geometry: polygon,
    symbol: fillSymbol
  });

  // TODO: View にグラフィックを追加
  view.graphics.addMany([polygonGraphic, polylineGraphic, pointGraphic]);
});
