require([
  "esri/Map",
  "esri/views/MapView",
  "esri/tasks/Geoprocessor"
], function(Map, MapView, Geoprocessor) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "dark-gray-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [-122.81, 45.466],
    zoom: 12
  });

  // ボタンのクリック イベントにタスクを実行する関数を登録
  document.getElementById("hotspotBtn").addEventListener("click", findHotspot);

  /**
   *
   * ステップ２：ジオプロセシング タスクの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-Geoprocessor.html
   *
   **/

  // TODO: ジオプロセシング タスクの作成
  // 以下のサービスを使用して 911 通報が発生した地点からホットスポット解析を行うジオプロセシング タスクを作成
  const url = "https://sampleserver6.arcgisonline.com/arcgis/rest/services/911CallsHotspot/GPServer/911%20Calls%20Hotspot";










  /**
   *
   * ステップ３：ジオプロセシング タスクの実行
   *
   **/

  function findHotspot() {
    // 既存のレイヤーを削除
    map.layers.forEach(function(layer) {
      if (layer.id === "hotspot-result-layer") {
        map.layers.remove(layer);
      }
    });

    /**
     *
     * ステップ３－１：パラメーターの作成
     * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-support-ParameterValue.html
     *
     **/

    // 解析期間を定義
    const queryStr = buildDefinitionQuery();

    // TODO: パラメーターを作成
    // 解析期間をパラメーターに設定










    /**
     *
     * ステップ３－２：タスクの実行
     * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-Geoprocessor.html#submitJob
     *
     **/

    // TODO: タスクの実行
    // タスクを実行して結果を view に表示
    // 処理の成功（showResult）、失敗（showErr）ステータスの確認（showStatus）を行うコールバック関数を設定する










  }

  /**
   *
   * ステップ３－３：結果の表示
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-Geoprocessor.html#getResultMapImageLayer
   *
   **/

  function showResult(result) {
    // ジョブ ID を使用して、タスクの結果を取得
    const resultLayer = gp.getResultMapImageLayer(result.jobId);
    resultLayer.opacity = 0.7;
    resultLayer.id = "hotspot-result-layer";
    // 結果として取得したレイヤーをマップに追加
    map.layers.add(resultLayer);
  }

  // ステータスの確認
  function showStatus(jobInfo) {
    console.log(jobInfo.jobStatus);
  }

  // エラー
  function showErr(err) {
    console.log(err);
  }

  // 入力された日付の取得、整形
  function buildDefinitionQuery() {
    const fromDate = document.getElementById("fromDate");
    const toDate = document.getElementById("toDate");

    const startDate = formatDate(fromDate.value);
    const endDate = formatDate(toDate.value);

    const defDate = "(Date >= date '" + startDate + "' and Date <= date '" + endDate + "')";
    const defDay = "(Day = 'SUN' OR Day= 'SAT' OR Day = 'FRI' OR Day ='MON' OR Day='TUE' OR Day='WED' OR Day ='THU')";
    let defQuery = defDate + " AND " + defDay;
    return defQuery;
  }

  // 日付のフォーマット
  function formatDate(dateVal) {
    const d = new Date(dateVal);
    let year = d.getFullYear();
    let month = d.getMonth() + 1;
    let day = d.getDate();
    let hrs = d.getHours();
    let min = d.getMinutes();
    let sec = d.getSeconds();

    month = (month < 10) ? "0" + month : month;
    day = (day < 10) ? "0" + day : day;
    hrs = (hrs < 10) ? "0" + hrs : hrs;
    min = (min < 10) ? "0" + min : min;
    sec = (sec < 10) ? "0" + sec : sec;

    const formatDate = year + "-" + month + "-" + day;
    const formatTime = hrs + ":" + min + ":" + sec;

    return formatDate + " " + formatTime;
  }
});
