require([
  "esri/Map",
  "esri/views/MapView",
  "esri/layers/FeatureLayer"
], function(Map, MapView, FeatureLayer) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.77, 35.68],
    zoom: 10
  });

  /**
   *
   * ステップ２：ラベルの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-layers-support-LabelClass.html
   *
   **/

  // TODO: [SIKUCHOSON] フィールドの値を表示するラベルを作成










  /**
   *
   * ステップ３：フィーチャ レイヤーの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-layers-FeatureLayer.html#labelingInfo
   *
   **/

  const featureLayer = new FeatureLayer({
    url: "https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/all_Japan_shikuchoson/FeatureServer/0",
    // TODO: ラベルの設定





  });
  map.add(featureLayer);
});
