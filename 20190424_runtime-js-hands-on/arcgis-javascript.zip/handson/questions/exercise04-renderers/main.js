require([
  "esri/Map",
  "esri/views/MapView",
  "esri/layers/FeatureLayer"
], function(Map, MapView, FeatureLayer) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.77, 35.68],
    zoom: 8
  });

  /**
   *
   * ステップ２：個別値分類レンダラーの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-renderers-UniqueValueRenderer.html
   *
   **/

  // TODO: [KEN] フィールドの個別値を表現するレンダラーを作成
  // "東京都" の値を青、"千葉県" の値を赤で表示










  /**
   *
   * ステップ３：フィーチャ レイヤーの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-layers-FeatureLayer.html#renderer
   *
   **/

  const featureLayer = new FeatureLayer({
    url: "https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/all_Japan_shikuchoson/FeatureServer/0",
    // TODO: レンダラーの設定





  });
  map.add(featureLayer);
});
