require([
  "esri/Map",
  "esri/views/MapView",
  "esri/Graphic",
  "esri/tasks/Geoprocessor",
  "esri/tasks/support/FeatureSet",
  "esri/tasks/support/LinearUnit"
], function(Map, MapView, Graphic, Geoprocessor, FeatureSet, LinearUnit) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "satellite"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [138.7278, 35.3606],
    zoom: 10
  });

  /**
   *
   * ステップ２：ジオプロセシング タスクの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-Geoprocessor.html
   *
   **/

  // TODO: ジオプロセシング タスクの作成
  // 以下のサービスを使用して可視領域解析を行うジオプロセシング タスクを作成
  const url = "https://sampleserver6.arcgisonline.com/arcgis/rest/services/Elevation/ESRI_Elevation_World/GPServer/Viewshed";










  /**
   *
   * ステップ３：ジオプロセシング タスクの実行
   *
   **/

  // view のクリックでタスクを実行
  view.on("click", execViewshed);

  function execViewshed(event) {
    // 既存のグラフィックを削除
    view.graphics.removeAll();

    // クリック地点のグラフィックを作成、表示
    const inputGraphic = new Graphic({
      geometry: event.mapPoint,
      symbol: {
        type: "simple-marker",
        color: [255, 0, 0],
        outline: {
          color: [255, 255, 255],
          width: 2
        }
      }
    });
    view.graphics.add(inputGraphic);

    /**
     *
     * ステップ３－１：パラメーターの作成
     * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-support-ParameterValue.html
     *
     **/

    // 解析地点を定義（クリック地点を設定）
    const featureSet = new FeatureSet({
      features: [inputGraphic]
    });

    // 解析範囲を定義
    const viewShedDist = new LinearUnit({
      distance: 10, // 距離（サービスで解析できる最大距離は 20000 メートル）
      units: "kilometers" // 距離の単位
    });

    // TODO: パラメーターを作成
    // 解析地点と解析範囲をパラメーターに設定










    /**
     *
     * ステップ３－２：タスクの実行
     * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-Geoprocessor.html#execute
     *
     **/

    // TODO: タスクの実行
    // タスクを実行して結果を view に表示（showResult 関数を実行）










  }

  /**
   *
   * ステップ３－３：結果の表示
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-tasks-support-ParameterValue.html
   *
   **/

  // 結果の表示
  function showResult(result) {
    // 結果から可視領域のフィーチャを取得
    const resultFeatures = result.results[0].value.features;

    // フィーチャにシンボルを定義
    const viewshedGraphics = resultFeatures.map(function(feature) {
      feature.symbol = {
        type: "simple-fill",
        color: [226, 119, 40, 0.75],
        outline: {
          color: [255, 255, 255],
          width: 1
        }
      };
      return feature;
    });

    // フィーチャの表示
    view.graphics.addMany(viewshedGraphics);
  }

  // エラー
  function showErr(err) {
    console.log(err);
  }
});
