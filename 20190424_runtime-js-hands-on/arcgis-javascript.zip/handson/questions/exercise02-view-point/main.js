require([
  "esri/Map",
  "esri/views/MapView",
  "esri/geometry/Extent",
  "esri/geometry/SpatialReference"
], function(Map, MapView, Extent, SpatialReference) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map
  });

  // ボタンのクリック イベントに表示範囲を変更する関数を登録
  document.getElementById("extBtn").addEventListener("click", doExtent);
  document.getElementById("cenBtn").addEventListener("click", doCenterAndScale);
  document.getElementById("aniBtn").addEventListener("click", doAnimate);

  /**
   *
   * ステップ２：エクステントを使った表示範囲の変更
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-views-MapView.html#extent
   *
   **/

  function doExtent() {
    // エクステントの定義
    const ext = new Extent({
      xmin: 139.753243,
      ymin: 35.671063,
      xmax: 139.759123,
      ymax: 35.676466,
      spatialReference: new SpatialReference({wkid: 4326})
    });

    // TODO: View にエクステントを表示




  }

  /**
   *
   * ステップ３：中心地点とスケールを使った表示範囲の変更
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-views-MapView.html#center
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-views-MapView.html#scale
   *
   **/

  function doCenterAndScale() {
    // 中心地点とスケールの定義
    const center = [139.74543, 35.658581];
    const scale = 1000;

    // TODO: View に中心地点とスケールを表示





  }


  /**
   *
   * ステップ４：アニメーションを使った表示範囲の変更
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-views-MapView.html#goTo
   *
   **/

  function doAnimate() {
    // ターゲットの定義
    const target = {
      center: [139.7661, 35.6814],
      zoom: 16
    };
    // オプションの定義
    const opts = {
      duration: 5000  // アニメーションの時間を5秒に指定
    };

    // TODO: View にターゲットを表示





  }

  /**
   *
   * ステップ５：表示範囲の変更の監視
   * https://developers.arcgis.com/javascript/latest/guide/working-with-props/index.html
   *
   **/

  // TODO: 表示範囲の変更で、変更されたエクステントを表示
  // view.stationary プロパティを監視して、showExtent 関数を実行





  // エクステントの値をコンソールに出力
  function showExtent(newValue) {
    if (newValue) {
      const info = "エクステント：" +
                    "\nxmin:" + view.extent.xmin.toFixed(2) +
                    "\nxmax: " + view.extent.xmax.toFixed(2) +
                    "\nymin:" + view.extent.ymin.toFixed(2) +
                    "\nymax: " + view.extent.ymax.toFixed(2);
      console.log(info);
    }
  }
});
