require([
  "esri/Map",
  "esri/views/MapView",
  "esri/layers/FeatureLayer"
], function(Map, MapView, FeatureLayer) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.77, 35.68],
    zoom: 8
  });

  /**
   *
   * ステップ２：ポップアップ テンプレートの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-PopupTemplate.html
   *
   **/

  // TODO: 以下のフィールドを表示するポップアップ テンプレートを作成
  // 都道府県名：[KEN]、市区町村名：[SIKUCHOSON]、人口：[P_NUM]、世帯数：[H_NUM]










  /**
   *
   * ステップ３：フィーチャ レイヤーの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-layers-FeatureLayer.html#popupTemplate
   *
   **/

  const featureLayer = new FeatureLayer({
    url: "https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/all_Japan_shikuchoson/FeatureServer/0",
    // TODO: ポップアップの設定





  });
  map.add(featureLayer);
});
