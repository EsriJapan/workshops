require([
  "esri/Map",
  "esri/views/MapView",
  "esri/widgets/Search"
], function(Map, MapView, Search) {
  /**
   *
   * ステップ１：マップの作成
   *
   **/

  const map = new Map({
    basemap: "streets-vector"
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.77, 35.68],
    zoom: 14
  });

  /**
   *
   * ステップ２：ウィジェットの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-widgets-Search.html
   *
   **/

  // TODO: 検索ウィジェットを作成










  // TODO: view の UI にウィジェットを追加










});
