require([
  /**
   *
   * ステップ１：モジュールの読み込み
   *
  **/
  // TODO: Map と MapView モジュールの読み込み





], function(          ) {
  /**
   *
   * ステップ２：マップの作成
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-Map.html
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-views-MapView.html
   *
   **/

  // TODO: Map の作成










  // TODO: View の作成










});
