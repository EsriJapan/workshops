require([
  "esri/Map",
  "esri/views/MapView",
  "esri/layers/FeatureLayer",
  "esri/Graphic"
], function(Map, MapView, FeatureLayer, Graphic) {
  /**
   *
   * ステップ１：マップの作成とレイヤーの表示
   *
   **/

  const featureLayer = new FeatureLayer({
    url: "https://services.arcgis.com/wlVTGRSYTzAbjjiC/arcgis/rest/services/js_handson_edit_features/FeatureServer/0"
  });

  const map = new Map({
    basemap: "streets-vector",
    layers: [featureLayer]
  });

  const view = new MapView({
    container: "viewDiv",
    map: map,
    center: [139.77, 35.68],
    zoom: 13
  });

  /**
   *
   * ステップ２：フィーチャの編集
   * https://developers.arcgis.com/javascript/latest/api-reference/esri-layers-FeatureLayer.html#applyEdits
   *
   **/

  // クリック地点にフィーチャを追加
  view.on("click", addFeatures);

  function addFeatures(event) {
    // テキスト ボックスの入力値を取得
    const name = document.getElementById("nameTxt").value;

    if (name.length > 0) {
      /**
       *
       * ステップ２－１：パラメーターの作成
       *
       **/

      // TODO: 追加するフィーチャの作成
      // クリック地点のグラフィックを作成して、name フィールドに入力値を設定










      // TODO: パラメーターの作成
      // 追加するフィーチャをパラメーターに設定










      /**
       *
       * ステップ２－２：編集の実行
       *
       **/

      // TODO: 編集の実行
      // 編集を適用して結果を表示（showResult 関数を実行）










    }
  }

  /**
   *
   * ステップ２－３：編集の結果の表示
   *
   **/

  // 結果の表示
  function showResult(result) {
    // 追加したフィーチャのポップアップを表示
    if (result.addFeatureResults.length > 0) {
      const objectId = result.addFeatureResults[0].objectId;
      featureLayer.queryFeatures({
        objectIds: [objectId],
        outFields: ["name"],
        returnGeometry: true
      }).then(function(results) {
        if (results.features.length > 0) {
          const feature = results.features[0];
          view.popup.open({
            content: feature.attributes["name"] + "を追加しました",
            location: feature.geometry
          });
        }
      });
    }
  }

  // エラー
  function showErr(e) {
    console.log(e);
  }
});
