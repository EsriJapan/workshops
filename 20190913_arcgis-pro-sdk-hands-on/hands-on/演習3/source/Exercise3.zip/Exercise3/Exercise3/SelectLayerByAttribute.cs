﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace Exercise3
{
    internal class SelectLayerByAttribute : Button
    {
        protected override void OnClick()
        {
            //アクティブなマップを取得
            Map map = MapView.Active.Map;

            //Japan レイヤを取得
            FeatureLayer featureLayer = map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == "Japan");

            QueuedTask.Run(() =>
            {
                // データストアを取得
                using (Datastore datastore = featureLayer.GetFeatureClass().GetDatastore())
                {
                    Geodatabase geodatabase = datastore as Geodatabase;

                    using (Table table = geodatabase.OpenDataset<Table>("Japan"))
                    {
                        // 検索条件
                        QueryFilter queryFilter = new QueryFilter
                        {
                            // SQL Where 句によって条件を指定
                            WhereClause = "SIKUCHOSON = '横須賀市'",

                            // 取得するカラム
                            SubFields = "KEN, SIKUCHOSON, P_NUM"
                        };

                        // 検索条件と合致したフィーチャを取得
                        using (RowCursor rowCursor = table.Search(queryFilter, true))
                        {
                            while (rowCursor.MoveNext())
                            {
                                // レコードを取得
                                using (Row row = rowCursor.Current)
                                {
                                    // 検索結果をメッセージボックスに表示
                                    ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show(string.Format("県: {0} " + Environment.NewLine +
                                                                                                    "市町村: {1} " + Environment.NewLine +
                                                                                                    "人口: {2}",
                                                                                                    Convert.ToString(row["KEN"]),
                                                                                                    Convert.ToString(row["SIKUCHOSON"]),
                                                                                                    Convert.ToString(row["P_NUM"])), "検索結果");
                                }
                            }
                        }
                    }

                } 
            });   
        }
    }
}
