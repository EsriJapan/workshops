﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace Exercise2
{
    internal class NewAddinButton : Button
    {
        protected override void OnClick()
        {
            // 等級色設定
            List<CIMClassBreak> listClassBreaks = new List<CIMClassBreak>
            {
                new CIMClassBreak
                {
　　　             //0～1万人の場合はグレー
                   Symbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.GreyRGB).MakeSymbolReference(),
                   UpperBound = 10000,　//上限値
                   Label = "0～1万人"　//ラベル
                },
                new CIMClassBreak
                {
　　　             //1～10万人の場合は青
                   Symbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.BlueRGB).MakeSymbolReference(),
                   UpperBound = 100000,　//上限値
                   Label = "1～10万人"　//ラベル
                },
                new CIMClassBreak
                {
　　　             //10～50万人の場合は緑
                   Symbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.GreenRGB).MakeSymbolReference(),
                   UpperBound = 500000,　//上限値
                   Label = "10～50万人"　//ラベル
                },
                new CIMClassBreak
                {
　　　             //50万～100万人の場合は赤
                   Symbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.RedRGB).MakeSymbolReference(),
                   UpperBound = 1000000,　//上限値
                   Label = "50万～100万人"　//ラベル
                }
            };

            //等級色でレンダリング
            QueuedTask.Run(() =>
            {
                // プロジェクトにある"地図"というマップを取得
                var mpj = Project.Current.GetItems<MapProjectItem>().First(item => item.Name.Equals("地図"));
                var map = mpj.GetMap();

                // マップにあるポリゴンレイヤーを取得
                var lyr = map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(f => f.ShapeType == esriGeometryType.esriGeometryPolygon);

                //等級色の新規作成
                CIMClassBreaksRenderer cimClassBreakRenderer = new CIMClassBreaksRenderer
                {
                    Field = "P_NUM",                                     //フィールド
                    ClassificationMethod = ClassificationMethod.Manual,  //手法
                    Breaks = listClassBreaks.ToArray()                   //クラス
                };
                lyr.SetRenderer(cimClassBreakRenderer);
            });
        }
    }
}
