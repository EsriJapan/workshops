﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace Exercise1
{
    internal class TestAddinButton : Button
    {
        protected async override void OnClick()
        {
            // 属性検索を実行
            await Geoprocessing.ExecuteToolAsync("SelectLayerByAttribute_management", 
                                                 new string[] {"Japan", "NEW_SELECTION", "KEN = '神奈川県'"});

            //選択されたフィーチャに3秒かけてズーム
            MapView.Active.ZoomToSelectedAsync(new
            TimeSpan(0, 0, 3), true);

        }
    }
}
