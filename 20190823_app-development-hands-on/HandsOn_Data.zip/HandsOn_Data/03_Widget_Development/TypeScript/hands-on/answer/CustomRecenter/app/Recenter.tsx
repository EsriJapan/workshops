// モジュールのインポート
import {subclass, declared, property} from "esri/core/accessorSupport/decorators";
import Widget = require("esri/widgets/Widget");
import * as watchUtils from "esri/core/watchUtils";
import { renderable, tsx } from "esri/widgets/support/widget";
import Point = require("esri/geometry/Point");
import MapView = require("esri/views/MapView");

//　type alias とインターフェースの作成
type LatLon = Point | number[];

interface Center {
  lat: number;
  lon: number;
}

interface State extends Center {
  interacting: boolean;
  scale: number;
}

interface Style {
  textShadow: string;
}


// 定数 CSS の作成
const CSS = {
  base: "recenter-tool"
};


// Widget 基底クラスを継承した Recenter クラスの作成
@subclass("esri.widgets.Recenter")
class Recenter extends declared(Widget) {

　// コンストラクタ
  constructor() {
    super();
    this._onViewChange = this._onViewChange.bind(this);
  }


  // プロパティの作成
  //----------------------------------
  //  view
  //----------------------------------

  @property()
  @renderable()
  view: MapView;

  //----------------------------------
  //  initialCenter
  //----------------------------------

  @property()
  @renderable()
  initialCenter: LatLon;

  //----------------------------------
  //  state
  //----------------------------------

  @property()
  @renderable()
  state: State;


  // postInitialize メソッドの追加
  postInitialize() {
    watchUtils.init(this, "view.center, view.interacting, view.scale", () => this._onViewChange());
  }
  

  // render メソッドの追加
  render() {
    const {lat, lon, scale} = this.state;
    const styles: Style = {
      textShadow: this.state.interacting ? '-1px 0 red, 0 1px red, 1px 0 red, 0 -1px red' : ''
    };
    return (
      <div
       bind={this}
       class={CSS.base}
       styles={styles}
       onclick={this._defaultCenter}>
       <p>緯度: {Number(lat).toFixed(3)}</p>
       <p>経度: {Number(lon).toFixed(3)}</p>
       <p>縮尺: {Number(scale).toFixed(5)}</p>
      </div>
    );
  }

  private _onViewChange() {
    let { interacting, center, scale } = this.view;
    this.state = {
      lat: center.latitude,
      lon: center.longitude,
      interacting,
      scale
    };
  }
  
  private _defaultCenter() {
    this.view.goTo(this.initialCenter);
  }
}

// エクスポート
export = Recenter;

