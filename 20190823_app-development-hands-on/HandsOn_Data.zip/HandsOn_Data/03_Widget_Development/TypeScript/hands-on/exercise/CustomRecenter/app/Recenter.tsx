// モジュールのインポート


//　type alias とインターフェースの作成



// 定数 CSS の作成



// Widget 基底クラスを継承した Recenter クラスの作成
class Recenter {

　// コンストラクタ



  // プロパティの作成
  


  // postInitialize メソッドの追加

  

  // render メソッドの追加


}

// エクスポート


