/// <amd-dependency path="esri/core/tsSupport/declareExtendsHelper" name="__extends" />
/// <amd-dependency path="esri/core/tsSupport/decorateHelper" name="__decorate" />

import Widget = require("esri/widgets/Widget");
import { subclass, declared, property } from "esri/core/accessorSupport/decorators";

import { renderable, tsx } from "esri/widgets/support/widget";


@subclass("esri.widgets.HelloWorld")
class HelloWorld extends declared(Widget) {

  @property()
  @renderable()
  name: string;

  render() {   
    return (
      <div class = "helloWorld">Hello {this.name} !</div>
    );
  }

}

export = HelloWorld;