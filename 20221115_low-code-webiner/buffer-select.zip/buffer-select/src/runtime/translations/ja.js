define({
  _widgetLabel:"バッファー検索"
});