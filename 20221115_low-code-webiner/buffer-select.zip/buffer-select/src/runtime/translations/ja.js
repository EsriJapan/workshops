define({
    _widgetLabel:"バッファー選択"
  });